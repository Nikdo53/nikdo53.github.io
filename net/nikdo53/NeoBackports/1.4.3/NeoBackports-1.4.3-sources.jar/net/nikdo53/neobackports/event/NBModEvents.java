package net.nikdo53.neobackports.event;

import net.minecraft.server.packs.resources.ResourceProvider;
import net.minecraftforge.client.event.RegisterShadersEvent;
import net.minecraftforge.common.crafting.*;
import net.minecraftforge.common.crafting.conditions.IConditionSerializer;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.NewRegistryEvent;
import net.minecraftforge.registries.RegisterEvent;
import net.minecraftforge.registries.RegistryBuilder;
import net.nikdo53.neobackports.NeoBackports;
import net.nikdo53.neobackports.datagen.condition.neoforge.*;
import net.nikdo53.neobackports.datamaps.NeoForgeDataMaps;
import net.nikdo53.neobackports.registry.ForgeRegistryHelper;
import net.nikdo53.neobackports.registry.NeoForgeRegistries;
import net.nikdo53.neobackports.registry.RegistryBuilderNeo;
import net.nikdo53.neobackports.screen.BlurShaderLoader;
import net.nikdo53.neobackports.datamaps.DataMapsManager;
import net.nikdo53.neobackports.test.NBDataMaps;

import java.util.function.Consumer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, modid = NeoBackports.MOD_ID)
public class NBModEvents {

    @SubscribeEvent
    public static void registerDataMaps(RegisterDataMapTypesEvent event) {
        event.register(NBDataMaps.TEST_DATA_MAP);
        event.register(NeoForgeDataMaps.COMPOSTABLES);
        event.register(NeoForgeDataMaps.FURNACE_FUELS);

    }

    @SubscribeEvent
    public static void commonSetup(FMLCommonSetupEvent event) {
        DataMapsManager.initDataMaps();
        ModLoader.get().postEvent(new RegisterPayloadHandlersEvent());
    }

/*    @SubscribeEvent
    public static void registerPackets(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(NBNetworking.CHANNEL, NeoBackports.MOD_ID);

        registrar.playToClient(TestPacket.TYPE, TestPacket.STREAM_CODEC, TestPacket::handle);
    }*/

    @SubscribeEvent
    public static void onRegisterShaders(RegisterShadersEvent event) {
        ResourceProvider resourceProvider = event.getResourceProvider();
        BlurShaderLoader.INSTANCE.loadBlurEffect(resourceProvider);
    }
    @SubscribeEvent
    public static void addRegistry(NewRegistryEvent event) {
        RegistryBuilderNeo.REGISTRY_BUILDERS.forEach(builder -> builder.register(event));

    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onRegister(RegisterEvent event){
        Consumer<IConditionSerializer<?>> safeRegister = serializer -> {
            try {
                CraftingHelper.register(serializer);
            } catch (IllegalStateException e) {
                NeoBackports.LOGGER.info("Condition " + serializer.getID() + " already registered, skipping...");
            }
        };

        if (event.getRegistryKey().equals(ForgeRegistries.Keys.RECIPE_SERIALIZERS)) {
            safeRegister.accept(NeoAndCondition.Serializer.INSTANCE);
            safeRegister.accept(NeoFalseCondition.Serializer.INSTANCE);
            safeRegister.accept(NeoItemExistsCondition.Serializer.INSTANCE);
            safeRegister.accept(NeoModLoadedCondition.Serializer.INSTANCE);
            safeRegister.accept(NeoNotCondition.Serializer.INSTANCE);
            safeRegister.accept(NeoOrCondition.Serializer.INSTANCE);
            safeRegister.accept(NeoTrueCondition.Serializer.INSTANCE);
            safeRegister.accept(NeoTagEmptyCondition.Serializer.INSTANCE);
        }
    }

}
