package net.nikdo53.neobackports.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.core.Holder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.nikdo53.neobackports.datamaps.DataMapType;
import net.nikdo53.neobackports.extensions.IBlockBehaviourExtension;
import net.nikdo53.neobackports.extensions.IBlockStateExtension;
import net.nikdo53.neobackports.extensions.IDataMapHolderExtension;
import net.nikdo53.neobackports.extensions.IWithData;
import net.nikdo53.neobackports.utils.ItemInteractionResult;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.function.Supplier;

@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class BlockStateBaseMixin implements IBlockStateExtension {

    @Shadow
    public abstract Block getBlock();

    @Shadow
    protected abstract BlockState asState();

    @Shadow
    public abstract boolean is(Block block);

    @Shadow
    public abstract Holder<Block> getBlockHolder();

    @WrapMethod(method = "use")
    public InteractionResult useWrap(Level level, Player player, InteractionHand hand, BlockHitResult result, Operation<InteractionResult> original) {
        IBlockBehaviourExtension extension = getBlock();

        ItemInteractionResult itemInteractionResult;
        try {
            itemInteractionResult = extension.useItemOn(player.getItemInHand(hand), asState(), level, result.getBlockPos(), player, hand, result);
        } catch (IllegalAccessError e){
            return original.call(level, player, hand, result);
        }

        if (itemInteractionResult.consumesAction()) {
            return itemInteractionResult.result();
        }

        if (itemInteractionResult == ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION && hand == InteractionHand.MAIN_HAND) {
            InteractionResult interactionresult;

            try {
                interactionresult = extension.useWithoutItem(asState(), level, result.getBlockPos(), player, result);
            } catch (IllegalAccessError e){
                return original.call(level, player, hand, result);
            }

            if (interactionresult == InteractionResult.PASS) {
                return original.call(level, player, hand, result);
            } else {
                return interactionresult;
            }
        }

        return original.call(level, player, hand, result);
    }

    @Override
    public boolean is(Supplier<Block> supplier) {
        return is(supplier.get());
    }

    @Override
    public @Nullable <T> T getData(DataMapType<Block, T> type) {
        return getBlockHolder().getData(type);
    }
}

