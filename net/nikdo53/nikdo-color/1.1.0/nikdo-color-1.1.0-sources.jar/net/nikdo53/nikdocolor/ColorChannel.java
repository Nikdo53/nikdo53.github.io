package net.nikdo53.nikdocolor;

import org.jetbrains.annotations.Contract;

import java.awt.*;

public enum ColorChannel {
    RED("Red"),
    GREEN("Green"),
    BLUE("Blue"),

    HUE("Hue"),
    SATURATION("Saturation"),
    VALUE("Value"),
    LIGHTNESS("Lightness"),

    ALPHA("Alpha")

    ;

    private final String name;
    private final char character;

    ColorChannel(String name) {
        this.name = name;
        this.character = Character.toLowerCase(name.charAt(0));
    }

    @Contract(pure = true)
    public WithValue withValue(float value){
        return new WithValue(this, value);
    }

    public static ColorChannel match(char character, ColorChannel[] availableChannels) {
        char lowerCase = Character.toLowerCase(character);

        for (ColorChannel channel : values()) {
            if (channel.character == lowerCase) {
                return channel;
            }
        }

        throw new IllegalArgumentException("No ColorChannel found for character: " + character);
    }

    public static ColorChannel match(String name, ColorChannel[] availableChannels) {
        if (name.length() == 1) {
            return match(name.charAt(0), availableChannels);
        }

        for (ColorChannel channel : availableChannels) {
            if (channel.name.equalsIgnoreCase(name)) {
                return channel;
            }
        }

        throw new IllegalArgumentException("No ColorChannel found for name: " + name);
    }

    public String getSerializedName() {
        return name;
    }

    public static ColorChannel[] matchChannels(String first, String[] others, ColorChannel[] availableChannels){
        ColorChannel[] channelsForOperation = new ColorChannel[others.length + 1];
        channelsForOperation[0] = ColorChannel.match(first, availableChannels);
        for (int i = 0; i < others.length; i++) {
            channelsForOperation[i + 1] = ColorChannel.match(others[i], availableChannels);
        }
        return channelsForOperation;
    }

    public record WithValue(ColorChannel channel, float value) {
        public WithValue {
            if (value < 0.0f || value > 1.0f) {
                throw new IllegalArgumentException("Value must be between 0.0 and 1.0");
            }
        }

        @Override
        public String toString() {
            return "ColorChannel.WithValue{" +
                    "channel=" + channel +
                    ", value=" + value +
                    '}';
        }
    }
}
