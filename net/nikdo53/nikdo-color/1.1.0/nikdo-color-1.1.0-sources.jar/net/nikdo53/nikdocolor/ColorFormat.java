package net.nikdo53.nikdocolor;

import org.jetbrains.annotations.Nullable;

public abstract class ColorFormat {
    public static final ColorFormat RGB = new ColorFormat(ColorChannel.RED, ColorChannel.GREEN, ColorChannel.BLUE) {
        @Override
        protected float[] toRGB(float... values) {
            return values;
        }

        @Override
        protected float[] fromRGB(float... values) {
            return values;
        }
    };
    public static final ColorFormat HSV = new ColorFormat(ColorChannel.HUE, ColorChannel.SATURATION, ColorChannel.VALUE) {
        @Override
        protected float[] toRGB(float... values) {
            return ColorUtils.hsvToRgb(values[0], values[1], values[2]);
        }

        @Override
        protected float[] fromRGB(float... values) {
            return ColorUtils.rgbToHsv(values[0], values[1], values[2]);
        }
    };

    public static final ColorFormat HSL = new ColorFormat(ColorChannel.HUE, ColorChannel.SATURATION, ColorChannel.LIGHTNESS) {
        @Override
        protected float[] toRGB(float... values) {
            return ColorUtils.hslToRgb(values[0], values[1], values[2]);
        }

        @Override
        protected float[] fromRGB(float... values) {
            return ColorUtils.rgbToHsl(values[0], values[1], values[2]);
        }
    };


    private final ColorChannel[] channelNames;

    public ColorFormat(ColorChannel... channelNames) {
        this.channelNames = channelNames;
    }

    public ColorChannel[] requiredChannels() {
        return channelNames;
    }

    public float[] convertFrom(ColorFormat other, float... values){
        if (other == this){
            return values;
        }
        float[] overrides = convertOverrides(other, values);
        if (overrides != null){
            return overrides;
        }
        return fromRGB(other.toRGB(values));
    }

    /**
     * Skips the conversion from RGB and back for better performance.
     */
    protected float @Nullable [] convertOverrides(ColorFormat other, float... values){
        return null;
    }

    protected abstract float[] toRGB(float... values);
    protected abstract float[] fromRGB(float... values);

    @Override
    public String toString() { //ColorFormat[RED, GREEN, BLUE]
        return "ColorFormat[" +
                java.util.Arrays.toString(channelNames) +
                "]";
    }
}
