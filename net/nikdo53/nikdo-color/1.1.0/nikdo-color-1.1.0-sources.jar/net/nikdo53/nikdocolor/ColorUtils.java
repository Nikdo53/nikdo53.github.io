package net.nikdo53.nikdocolor;

public class ColorUtils {
    private static final float EPSILON = 1.0e-6f;

    public static float[] rgbToHsv(float r, float g, float b) {
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float delta = max - min;

        float h = 0.0f;
        float s = max < EPSILON ? 0.0f : delta / max;

        if (delta < EPSILON) {
            if (max == r) {
                h = ((g - b) / delta) % 6.0f;
            } else if (max == g) {
                h = (b - r) / delta + 2.0f;
            } else {
                h = (r - g) / delta + 4.0f;
            }

            h /= 6.0f;

            if (h < 0.0f) {
                h += 1.0f;
            }
        }

        return new float[] {h, s, max};
    }

    public static float[] hsvToRgb(float h, float s, float v) {
        float r, g, b;

        float c = v * s;
        float x = c * (1.0f - Math.abs((h * 6.0f) % 2.0f - 1.0f));
        float m = v - c;

        if (h < 1.0f / 6.0f) {
            r = c;
            g = x;
            b = 0;
        } else if (h < 2.0f / 6.0f) {
            r = x;
            g = c;
            b = 0;
        } else if (h < 3.0f / 6.0f) {
            r = 0;
            g = c;
            b = x;
        } else if (h < 4.0f / 6.0f) {
            r = 0;
            g = x;
            b = c;
        } else if (h < 5.0f / 6.0f) {
            r = x;
            g = 0;
            b = c;
        } else {
            r = c;
            g = 0;
            b = x;
        }

        return new float[] {r + m, g + m, b + m};
    }

    public static float[] hslToRgb(float h, float s, float l) {
        if (s < EPSILON) {
            // Achromatic
            return new float[] {l, l, l};
        }

        float q = l < 0.5f
                ? l * (1.0f + s)
                : l + s - l * s;

        float p = 2.0f * l - q;

        float r = hueToRgb(p, q, h + 1.0f / 3.0f);
        float g = hueToRgb(p, q, h);
        float b = hueToRgb(p, q, h - 1.0f / 3.0f);

        return new float[] {r, g, b};
    }


    private static float hueToRgb(float p, float q, float t) {
        t = t % 1.0f;

        if (t < 0.0f) {
            t += 1.0f;
        }

        if (t < 1.0f / 6.0f) {
            return p + (q - p) * 6.0f * t;
        }

        if (t < 1.0f / 2.0f) {
            return q;
        }

        if (t < 2.0f / 3.0f) {
            return p + (q - p) * (2.0f / 3.0f - t) * 6.0f;
        }

        return p;
    }

    public static float[] rgbToHsl(float r, float g, float b) {
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));

        float lightness = (max + min) * 0.5f;

        float delta = max - min;

        if (delta < EPSILON) {
            // Achromatic
            return new float[] {0.0f, 0.0f, lightness};
        }

        float saturation = delta /
                (1.0f - Math.abs(2.0f * lightness - 1.0f));

        float hue;

        if (max == r) {
            hue = ((g - b) / delta) % 6.0f;
        } else if (max == g) {
            hue = ((b - r) / delta) + 2.0f;
        } else {
            hue = ((r - g) / delta) + 4.0f;
        }

        hue /= 6.0f;

        if (hue < 0.0f) {
            hue += 1.0f;
        }

        return new float[]{hue, saturation, lightness};
    }


}
