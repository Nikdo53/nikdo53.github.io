package net.nikdo53.nikdocolor;

import org.jetbrains.annotations.Contract;

import java.util.function.BinaryOperator;
import java.util.function.UnaryOperator;

public abstract class NikdoColor<T extends NikdoColor<T>>{
    protected float[] channels;
    protected ChannelFormat<T> currentFormat;

    protected NikdoColor(ChannelFormat<T> format, float... values) {
        currentFormat = format;
        if (values.length < format.channelLookup().length)
            throw new IllegalArgumentException("Not enough values provided for the format " + format + ". Expected " + format.channelLookup().length + " but got " + values.length);

        channels = values;
    }

    @Contract(pure = true)
    public static RGB fromHex(int hex){
        return new RGB(ChannelFormat.ARGB,
                clamp((hex >> 24 & 0xFF) / 255f),
                clamp((hex >> 16 & 0xFF) / 255f),
                clamp((hex >> 8 & 0xFF) / 255f),
                clamp((hex & 0xFF) / 255f)
        );
    }

    @Contract(pure = true)
    public static RGB fromHexNoAlpha(int hex){
        return new RGB(ChannelFormat.RGB,
                clamp((hex >> 16 & 0xFF) / 255f),
                clamp((hex >> 8 & 0xFF) / 255f),
                clamp((hex & 0xFF) / 255f)
        );
    }

    // stops being dependent on mojang math class
    private static float clamp(float value) {
        return value < 0f ? 0f : Math.min(value, 1f);
    }

    @Contract(pure = true)
    public static RGB createRGB(ChannelFormat<RGB> format, float... values) {
        return new RGB(format, values);
    }

    @Contract(pure = true)
    public static HSV createHSV(ChannelFormat<HSV> format, float... values) {
        return new HSV(format, values);
    }

    @Contract(pure = true)
    public static HSL createHSL(ChannelFormat<HSL> format, float... values) {
        return new HSL(format, values);
    }

    @Contract(pure = true)
    public int[] getIntArray(){
        int[] result = new int[channels.length];
        for (int i = 0; i < result.length; i++) {
            result[i] = (int) (channels[i] * 255);
        }
        return result;
    }

    @Contract(pure = true)
    public int packed(){
        int[] intArray = getIntArray();
        int result = 0;

        for (int j : intArray) {
            result = (result << 8) | j & 0xFF;
        }

        return result;
    }

    /**
     * Creates a new color in the specified format, converting the values from the current format to the new format.
     * !!Does not change the current color's format, it creates a new color in the new format!!
     * @param format format of the new color
     * @return a new color in the specified format
     * @param <F> NikdoColor subclass type of the new color
     */
    public <F extends NikdoColor<?>> F reformatColor(ChannelFormat<F> format){
        return format.reformatColor(this);
    }

    /**
     * Reorders the channels of the current color to match the specified format. If a channel is not present in the current color, it has to be provided as an additional channel with a value.
     * @param formatNew format of the new color
     * @param additionalChannels channels with values to be used if the channel is not present in the current color (like alpha channel for RGB)
     */
    @Contract("_,_ -> this")
    public T reorder(ChannelFormat<T> formatNew, ColorChannel.WithValue... additionalChannels) {
        if (currentFormat == formatNew)
            return cast();

        float[] replace = new float[formatNew.channelLookup().length];
        for (int i = 0; i < replace.length; i++) {
            ColorChannel channel = formatNew.channelLookup()[i];
            if (this.hasChannel(channel)) {
                replace[i] = getChannel(channel);
            } else {
                boolean success = false;
                for (ColorChannel.WithValue additionalChannel : additionalChannels) {
                    if (additionalChannel.channel() == channel) {
                        replace[i] = additionalChannel.value();
                        success = true;
                        break;
                    }
                }
                if (!success) {
                    throw new IllegalArgumentException("Channel " + channel + " is not present in the current color and no additional value was provided");
                }
            }
        }

        channels = replace;
        currentFormat = formatNew;
        return cast();
    }

    /**
     * Reorders the channels of the current color to match the specified format. If a channel is not present in the current color, the default value is used.
     * @param formatNew format of the new color
     * @param defaultValue default value to be used if the channel is not present in the current color (like alpha channel for RGB)
     */
    @Contract("_,_ -> this")
    public T reorder(ChannelFormat<T> formatNew, float defaultValue) {
        if (currentFormat == formatNew)
            return cast();

        float[] replace = new float[formatNew.channelLookup().length];
        for (int i = 0; i < replace.length; i++) {
            ColorChannel channel = formatNew.channelLookup()[i];
            if (this.hasChannel(channel)) {
                replace[i] = getChannel(channel);
            } else {
                replace[i] = defaultValue;
            }
        }

        channels = replace;
        currentFormat = formatNew;
        return cast();
    }


    @Contract(pure = true)
    public boolean hasChannel(ColorChannel channel) {
        for (ColorChannel c : currentFormat.channelLookup()) {
            if (c == channel) {
                return true;
            }
        }
        return false;
    }

   @Contract(pure = true)
    public float getChannel(int index) {
        return channels[index];
    }

    @Contract("_,_ -> this")
    public T setChannel(int index, float value) {
        channels[index] = value;
        return cast();
    }

    @Contract(pure = true)
    public float getChannel(ColorChannel channel) {
        return channels[currentFormat.getChannelIndex(channel)];
    }

    @Contract("_,_ -> this")
    public T setChannel(ColorChannel channel, float value) {
        channels[currentFormat.getChannelIndex(channel)] = clamp(value);
        return cast();
    }

    @Contract(pure = true)
    public float getChannel(String channelName) {
        return getChannel(ColorChannel.match(channelName, currentFormat.channelLookup()));
    }

    @Contract("_,_ -> this")
    public T setChannel(String channelName, float value) {
        return setChannel(ColorChannel.match(channelName, currentFormat.channelLookup()), value);
    }

    /**
     * Runs an operation on all / specific channels of the current color.
     * @param operation the operation to be performed on the channels
     * @param channelsForOperation channels to be operated on. If empty, all channels are operated on.
     * @return this color for chaining
     */
    @Contract("_,_ -> this")
    public T operation(UnaryOperator<Float> operation, ColorChannel... channelsForOperation) {
        if (channelsForOperation.length == 0) {
            for (int i = 0; i < channels.length; i++) {
                channels[i] = operation.apply(channels[i]);
            }
        } else {
            for (ColorChannel channel : channelsForOperation) {
                setChannel(channel, operation.apply(getChannel(channel)));
            }
        }
        return cast();
    }

    /**
     * Runs an operation on all / specific channels of the current color. Slightly less performant
     * @param operation the operation to be performed on the channels
     * @param channelsForOperation1 channels to be operated on, but as a String (eg. "Red", "b" or "alpha")
     * @param channelsForOperationRest additional channels to be operated on.
     * @return this color for chaining
     */
    @Contract("_,_,_ -> this")
    public T operation(UnaryOperator<Float> operation, String channelsForOperation1, String... channelsForOperationRest) {
        return operation(operation, ColorChannel.matchChannels(channelsForOperation1, channelsForOperationRest, currentFormat.channelLookup()));
    }

    /**
     * Runs an operation on all / specific channels of the current color with the specified other color.
     * @param otherColor other color to be operated on
     * @param operation the operation to be performed on the channels
     * @param channelPairs pairs of channels to be operated on, alternating 1st and 2nd color. If empty, all channels are operated on one by one
     * @return this color for chaining
     */
    @Contract("_,_,_ -> this")
    public T operation(NikdoColor<?> otherColor,  BinaryOperator<Float> operation, ColorChannel... channelPairs) {
        if (channelPairs.length == 0) {
            for (int i = 0; i < channels.length; i++) {
                channels[i] = operation.apply(channels[i], otherColor.getChannel(i));
            }
        } else {
            if (channelPairs.length % 2 != 0) {
                throw new IllegalArgumentException("channelPairs must be in pairs, 1st of the 1st color, 2nd of the 2nd color");
            }
            for (int i = 0; i < channelPairs.length; i += 2) {
                ColorChannel first =  channelPairs[i];
                ColorChannel second = channelPairs[i + 1];
                setChannel(first, operation.apply(getChannel(first), otherColor.getChannel(second)));
            }
        }
        return cast();
    }

    /**
     * Runs an operation on all / specific channels of the current color with the specified other color. Slightly less performant
     * @param otherColor other color to be operated on
     * @param operation the operation to be performed on the channels
     * @param channelPairs1 pairs of channels to be operated on, alternating 1st and 2nd color. If empty, all channels are operated on one by one
     * @return this color for chaining
     */
    @Contract("_,_,_,_ -> this")
    public T operation(NikdoColor<?> otherColor,  BinaryOperator<Float> operation, String channelPairs1, String... channelPairsRest) {
        return operation(otherColor, operation,  ColorChannel.matchChannels(channelPairs1, channelPairsRest, currentFormat.channelLookup()));
    }

    /**
     * Swaps the values of two channels without changing the format.
     * @param channel1 the first channel
     * @param channel2 the second channel
     * @return this color for chaining
     */
    @Contract("_,_ -> this")
    public T swirl(ColorChannel channel1, ColorChannel channel2) {
        float temp = getChannel(channel1);
        setChannel(channel1, getChannel(channel2));
        setChannel(channel2, temp);
        return cast();
    }

    /**
     * Swaps the values of two channels without changing the format. Slightly less performant
     * @param channel1 the first channel
     * @param channel2 the second channel
     * @return this color for chaining
     */
    @Contract("_,_ -> this")
    public T swirl(String channel1, String channel2) {
        float temp = getChannel(channel1);
        setChannel(channel1, getChannel(channel2));
        setChannel(channel2, temp);
        return cast();
    }


    @SuppressWarnings("unchecked")
    private T cast(){
        return (T) this;
    }

    /**
     * @return a copy of the current color
     */
    @Contract(pure = true)
    public abstract T copy();

    @Contract(pure = true)
    public float getAlpha() {
        return getChannel(ColorChannel.ALPHA);
    }

    @Contract("_ -> this")
    public T setAlpha(float alpha) {
        return setChannel(ColorChannel.ALPHA, alpha);
    }

    @Override
    public String toString() { // Color:[Red:0.5, Green:0.5, Blue:0.5, Alpha:1.0]
        StringBuilder builder = new StringBuilder();
        builder.append("Color:[");
        int i = 0;
        for (ColorChannel channel : currentFormat.channelLookup()) {
            if (i != 0) {
                builder.append(", ");
            }

            builder.append(channel.getSerializedName()).append(":").append(channels[i]);
            i++;
        }
        builder.append("]");
        return builder.toString();
    }

    public static class RGB extends NikdoColor<RGB> implements IColorSupplier {
        public RGB(ChannelFormat<RGB> format, float... values) {
            super(format, values);
            if (format.colorFormat() != ColorFormat.RGB){
                throw new IllegalArgumentException("Invalid color format. Expected RGB.");
            }
        }

        @Override
        public RGB copy() {
            return new RGB(currentFormat, channels.clone());
        }

        @Override
        @Contract(pure = true)
        public float getRed() {
            return getChannel(ColorChannel.RED);
        }

        @Override
        @Contract(pure = true)
        public float getGreen() {
            return getChannel(ColorChannel.GREEN);
        }

        @Override
        @Contract(pure = true)
        public float getBlue() {
            return getChannel(ColorChannel.BLUE);
        }

        @Contract("_ -> this")
        public RGB setRed(float red) {
            return setChannel(ColorChannel.RED, red);
        }

        @Contract("_ -> this")
        public RGB setGreen(float green) {
            return setChannel(ColorChannel.GREEN, green);
        }

        @Contract("_ -> this")
        public RGB setBlue(float blue) {
            return setChannel(ColorChannel.BLUE, blue);
        }

        /**
         * Converts the color to grayscale.
         * @return this color for chaining
         */
        @Contract(" -> this")
        public RGB toGrayscale(){
            float luminance = 0.2126f * getRed() + 0.7152f * getGreen() + 0.0722f * getBlue();
            setRed(luminance);
            setGreen(luminance);
            setBlue(luminance);
            return this;
        }
    }

    public static class HSV extends NikdoColor<HSV> {
        public HSV(ChannelFormat<HSV> format, float... values) {
            super(format, values);
            if (format.colorFormat() != ColorFormat.HSV){
                throw new IllegalArgumentException("Invalid color format. Expected HSV.");
            }
        }

        @Override
        public HSV copy() {
            return new HSV(currentFormat, channels.clone());
        }

        @Contract(pure = true)
        public float getHue() {
            return getChannel(ColorChannel.HUE);
        }

        @Contract(pure = true)
        public float getSaturation() {
            return getChannel(ColorChannel.SATURATION);
        }

        @Contract(pure = true)
        public float getValue() {
            return getChannel(ColorChannel.VALUE);
        }

        @Contract("_ -> this")
        public HSV setHue(float hue) {
            return setChannel(ColorChannel.HUE, hue);
        }

        @Contract("_ -> this")
        public HSV setSaturation(float saturation) {
            return setChannel(ColorChannel.SATURATION, saturation);
        }

        @Contract("_ -> this")
        public HSV setValue(float value) {
            return setChannel(ColorChannel.VALUE, value);
        }
    }

    public static class HSL extends NikdoColor<HSL> {
        public HSL(ChannelFormat<HSL> format, float... values) {
            super(format, values);
            if (format.colorFormat() != ColorFormat.HSL){
                throw new IllegalArgumentException("Invalid color format. Expected HSL.");
            }
        }

        @Override
        public HSL copy() {
            return new HSL(currentFormat, channels.clone());
        }

        @Contract(pure = true)
        public float getHue() {
            return getChannel(ColorChannel.HUE);
        }

        @Contract(pure = true)
        public float getSaturation() {
            return getChannel(ColorChannel.SATURATION);
        }

        @Contract(pure = true)
        public float getLightness() {
            return getChannel(ColorChannel.LIGHTNESS);
        }

        @Contract("_ -> this")
        public HSL setHue(float hue) {
            return setChannel(ColorChannel.HUE, hue);
        }

        @Contract("_ -> this")
        public HSL setSaturation(float saturation) {
            return setChannel(ColorChannel.SATURATION, saturation);
        }

        @Contract("_ -> this")
        public HSL setLightness(float lightness) {
            return setChannel(ColorChannel.LIGHTNESS, lightness);
        }
    }

}
