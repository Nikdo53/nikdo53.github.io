@NotNullByDefault
package net.nikdo53.nikdocolor;

import org.jetbrains.annotations.NotNullByDefault;