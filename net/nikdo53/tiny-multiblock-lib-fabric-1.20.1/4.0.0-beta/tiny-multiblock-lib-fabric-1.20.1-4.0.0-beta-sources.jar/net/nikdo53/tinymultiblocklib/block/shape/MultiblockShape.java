package net.nikdo53.tinymultiblocklib.block.shape;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.nikdo53.tinymultiblocklib.block.AbstractMultiBlock;
import net.nikdo53.tinymultiblocklib.block.logic.DelegatingMultiblockLogic;
import net.nikdo53.tinymultiblocklib.block.logic.MultiblockLogic;
import net.nikdo53.tinymultiblocklib.util.TMBLUtils;
import net.nikdo53.tinymultiblocklib.util.VoxelShapeUtils;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

public class MultiblockShape {
    final Map<class_2338, Entry> shape;
    final class_2338 center;
    class_265 jointVoxelShape = class_259.method_1073();

    public MultiblockShape(Map<class_2338, Entry> shape, class_2338 center) {
        this.shape = shape;
        this.center = center;
    }

    public static MultiblockShape empty(){
        return new MultiblockShape(Collections.emptyMap(), class_2338.field_10980);
    }

    public Map<class_2338, Entry> getShape() {
        return shape;
    }

    public Entry getEntry(class_2338 offset){
        return shape.get(offset);
    }

    public Entry getEntryGlobal(class_2338 globalPos){
        return shape.get(getOffset(globalPos));
    }

    public class_2338 getOffset(class_2338 globalPos){
        return globalPos.method_10059(center);
    }

    public Set<class_2338> getGlobalPositions() {
        return shape.keySet().stream().map(pos -> pos.method_10081(center)).collect(Collectors.toSet());
    }

    public Entry getEntryForGlobalPos(class_2338 pos){
        return shape.get(pos.method_10059(center));
    }

    public class_265 getJointVoxelShape(class_1937 level, class_2680 state) {
        if (state.method_26204() instanceof AbstractMultiBlock){
            class_238 shape = state.method_26218(level, getCenter()).method_1107();
            class_238 block = class_238.method_29968(new class_243(0, 0, 0));
            // should cancel fancy outlines for blocks that already have them done manually
            if (TMBLUtils.isShapeBiggerThan(shape, block)) {
                return class_259.method_1073();
            }

        }
        if (jointVoxelShape.method_1110()) {
            shape.forEach((pos, entry) -> {
                //cut out only the block so it isn't huge
                class_265 shape1 = class_259.method_1072(state.method_26218(level, pos.method_10081(getCenter())), class_259.method_1077(), class_247.field_16896);

                jointVoxelShape = Builder.joinMoved(jointVoxelShape, shape1, class_247.field_1366, pos);
            });
        }
        return jointVoxelShape;
    }

    public record Entry(MultiblockLogic logic, Function<class_2680, class_2680> stateModifier, Map<ShapeDataKey<?>, Object> data) {
        public Entry(MultiblockLogic logic, UnaryOperator<class_2680> stateModifier) {
            this(logic, stateModifier, new HashMap<>());
        }

        public <T> T getData(ShapeDataKey<T> key) {
            @SuppressWarnings("unchecked")
            T value = (T) data.get(key);
            return value;
        }

        public <T> T getDataOrDefault(ShapeDataKey<T> key, T defaultValue) {
            @SuppressWarnings("unchecked")
            T value = (T) data.get(key);
            return value != null ? value : defaultValue;
        }

        public boolean hasData(ShapeDataKey<?> key) {
            return data.containsKey(key);
        }

        @ApiStatus.Internal
        public <T> void putData(ShapeDataKey<T> key, T value) {
            data.put(key, value);
        }
    }

    public class_2338 getCenter() {
        return center;
    }

    public static class Builder {
        final class_2338 center;
        Map<class_2338, Entry> map = new HashMap<>();
        List<Operation> operations = new ArrayList<>();
        List<SymbolShapeBuilder> symbolShapeBuilders = new ArrayList<>();
        class_265 jointVoxelShape = class_259.method_1073();

        public Builder(class_2338 center, MultiblockLogic centerLogic) {
            this.center = center;
            map.put(class_2338.field_10980, new Entry(centerLogic, UnaryOperator.identity()));
        }

        public Builder addGlobal(class_2338 pos, MultiblockLogic logic, UnaryOperator<class_2680> stateModifier, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(pos.method_10059(center), logic, stateModifier, extraData);
            return this;
        }

        /**
         * Creates a new symbol shape builder
         * @param fowardDirection direction where the builder is facing, each .nextAisle() moves the builder in that direction
         *                      ❗THIS IS NOT THE MULTIBLOCKS DIRECTION❗
         */
        public SymbolShapeBuilder toSymbolBuilder(class_2350 fowardDirection){
            SymbolShapeBuilder symbolShapeBuilder = new SymbolShapeBuilder(fowardDirection);
            symbolShapeBuilders.add(symbolShapeBuilder);
            return symbolShapeBuilder;
        }

        public Builder setJointVoxelShape(class_265 shape){
            jointVoxelShape = shape;
            return this;
        }

        // add() zone:

        public Builder add(class_2382 offset, MultiblockLogic logic, UnaryOperator<class_2680> stateModifier, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(offset, logic, stateModifier, extraData);
            return this;
        }

        public Builder add(int x, int y, int z, MultiblockLogic logic, UnaryOperator<class_2680> stateModifier, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(new class_2382(x, y, z), logic, stateModifier, extraData);
            return this;
        }

        public Builder add(class_2382 offset, MultiblockLogic logic, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(offset, logic, UnaryOperator.identity(), extraData);
            return this;
        }

        public Builder add(int x, int y, int z, MultiblockLogic logic, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(new class_2382(x, y, z), logic, UnaryOperator.identity(), extraData);
            return this;
        }



        public Builder addDelegating(class_2382 offset, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(offset, DelegatingMultiblockLogic.INSTANCE, UnaryOperator.identity(), extraData);
            return this;
        }

        public Builder addDelegating(int x, int y, int z, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(new class_2382(x, y, z), DelegatingMultiblockLogic.INSTANCE, UnaryOperator.identity(), extraData);
            return this;
        }

        public Builder addDelegating(class_2382 offset, UnaryOperator<class_2680> stateModifier, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(offset, DelegatingMultiblockLogic.INSTANCE, stateModifier, extraData);
            return this;
        }

        public Builder addDelegating(int x, int y, int z, UnaryOperator<class_2680> stateModifier, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(new class_2382(x, y, z), DelegatingMultiblockLogic.INSTANCE, stateModifier, extraData);
            return this;
        }



        public Builder addNoLogic(class_2382 offset, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(offset, MultiblockLogic.EMPTY, UnaryOperator.identity(), extraData);
            return this;
        }

        public Builder addNoLogic(int x, int y, int z, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(new class_2382(x, y, z), MultiblockLogic.EMPTY, UnaryOperator.identity(), extraData);
            return this;
        }

        public Builder addNoLogic(class_2382 offset, UnaryOperator<class_2680> stateModifier, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(offset, MultiblockLogic.EMPTY, stateModifier, extraData);
            return this;
        }

        public Builder addNoLogic(int x, int y, int z, UnaryOperator<class_2680> stateModifier, ShapeDataKey.Pair<?>... extraData) {
            putOrThrow(new class_2382(x, y, z), MultiblockLogic.EMPTY, stateModifier, extraData);
            return this;
        }




        protected void putOrThrow(class_2382 offset, MultiblockLogic logic, Function<class_2680, class_2680> stateModifier, ShapeDataKey.Pair<?>... extraData){
            if (localPosSuspiciouslyGlobalLooking(offset)){
                throw new IllegalArgumentException("Offset " + offset + " looks like a global position. If you want to add a global position, use addGlobal() instead");
            }
            Map<ShapeDataKey<?>, Object> dataMap = new HashMap<>();
            for (ShapeDataKey.Pair<?> pair : extraData) {
                dataMap.put(pair.key(), pair.value());
            }
            
            for (Operation operation : operations) {
                offset = operation.posModifier().apply(offset);
                logic = operation.logicModifier().apply(logic);
                stateModifier = stateModifier.andThen(operation.stateModifier()); // this doesnt work with unary operators

                dataMap.replaceAll((key, value) -> {
                    ShapeDataKey.Operation dataModifier = operation.getDataModifier(key);
                    if (dataModifier != null) {
                        return dataModifier.operation().apply(value);
                    }
                    return value;
                });
            }

            if (!offset.equals(class_2382.field_11176)) {
                map.put(new class_2338(offset), new Entry(logic, stateModifier, dataMap));
            } else {
                Entry centerEntry = map.get(class_2338.field_10980); // center always exists and uses its own logic
                map.put(class_2338.field_10980, new Entry(centerEntry.logic(), stateModifier, dataMap));
            }
        }

        public Builder pushOperation(UnaryOperator<class_2382> posModifier, UnaryOperator<MultiblockLogic> logicModifier,
                                     UnaryOperator<class_2680> stateModifier, ShapeDataKey.Operation<?>... dataModifiers) {
            operations.add(new Operation(posModifier, logicModifier, stateModifier, dataModifiers));
            return this;
        }

        public Builder pushDirectionalOperation(class_2350 direction, class_2382 pivotPoint) {
            return pushOperation(offset -> {
                        class_2382 rotatedOffset = rotateVector(direction, offset);
                        class_2382 rotatedPivotPoint = rotateVector(direction, pivotPoint);
                        return rotatedOffset.method_35853(rotatedPivotPoint);
                    },
                    UnaryOperator.identity(),
                    UnaryOperator.identity(),
                    new ShapeDataKey.Operation<>(ShapeDataKey.VOXEL_SHAPE, shape -> VoxelShapeUtils.rotateAll(direction, shape))
            );
        }

        public Builder pushDirectionalOperation(class_2350 direction) {
            return pushDirectionalOperation(direction, class_2382.field_11176);
        }

        protected static @NotNull class_2382 rotateVector(class_2350 direction, class_2382 offset) {
            return switch (direction) {
                case field_11043 -> new class_2382(offset.method_10263(), offset.method_10264(), offset.method_10260());
                case field_11035 -> new class_2382(-offset.method_10263(), offset.method_10264(), -offset.method_10260());

                case field_11034 -> new class_2382(-offset.method_10260(), offset.method_10264(), offset.method_10263());
                case field_11039 -> new class_2382(offset.method_10260(), offset.method_10264(), -offset.method_10263());

                case field_11036 -> new class_2382(-offset.method_10264(), -offset.method_10260(),  -offset.method_10263());
                case field_11033 -> new class_2382(offset.method_10264(), offset.method_10260(), -offset.method_10263());
            };
        }

        protected void buildVoxelShapes(){

            if (!jointVoxelShape.method_1110()) {
                map.forEach((pos, entry) -> {
                    if (!entry.hasData(ShapeDataKey.VOXEL_SHAPE)) {
                        // cut the joint shape into pieces and store them in the entry
                        entry.putData(ShapeDataKey.VOXEL_SHAPE, joinMoved(class_259.method_1077(), jointVoxelShape, class_247.field_16896, pos.method_35830(-1)));
                    }
                });

            }

        }

        static protected class_265 joinMoved(class_265 first, class_265 second, class_247 op, class_2338 pos){
            return class_259.method_1072(first, second.method_1096(pos.method_10263(), pos.method_10264(), pos.method_10260()), op);
        }

        public Builder popOperation() {
            operations.remove(operations.size() - 1);
            return this;
        }

        /**
         * Builds the multiblock shape. This method is called automatically
         * @return the built multiblock shape
         */
        @ApiStatus.Internal
        public MultiblockShape build(){
            for (SymbolShapeBuilder builder : symbolShapeBuilders) {
                builder.build(this);
            }
            buildVoxelShapes();
            return new MultiblockShape(map, center);
        }

        public boolean localPosSuspiciouslyGlobalLooking(class_2382 offset){
            boolean offsetCloseToGlobal = offset.method_19455(center) < 3;
            boolean centerFarFromLocal = center.method_19455(class_2338.field_10980) > 30;
            boolean offsetDetached = offset.method_19455(class_2338.field_10980) > 8 + map.size();
            return offsetCloseToGlobal && centerFarFromLocal && offsetDetached;
        }


        public record Operation(UnaryOperator<class_2382> posModifier, UnaryOperator<MultiblockLogic> logicModifier,
                                UnaryOperator<class_2680> stateModifier, ShapeDataKey.Operation<?>[] dataModifiers ) {
            @SuppressWarnings("unchecked")
            public <T> @Nullable ShapeDataKey.Operation<T> getDataModifier(ShapeDataKey<T> key) {
                for (ShapeDataKey.Operation<?> dataModifier : dataModifiers) {
                    return (ShapeDataKey.Operation<T>) dataModifier;
                }
                return null;
            }
        }
    }
}
