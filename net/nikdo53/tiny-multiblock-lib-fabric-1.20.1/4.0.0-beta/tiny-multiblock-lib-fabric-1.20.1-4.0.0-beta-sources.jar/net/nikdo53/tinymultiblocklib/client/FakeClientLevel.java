package net.nikdo53.tinymultiblocklib.client;

import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.nikdo53.tinymultiblocklib.components.BlockLive;
import net.nikdo53.tinymultiblocklib.mixin.ClientLevelAccessorMixin;
import net.nikdo53.tinymultiblocklib.mixin.LevelAccessorMixin;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BooleanSupplier;

public class FakeClientLevel extends class_638 {
    public static @Nullable FakeClientLevel INSTANCE = null;

    class_638 originalLevel;
    public Set<BlockLive> blockLiveSet = new HashSet<>();

    public FakeClientLevel(class_638 level) {
        super(((ClientLevelAccessorMixin) level).getConnection(),
                level.method_28104(),
                level.method_27983(),
                level.method_40134(),
                1,
                1,
                level.method_24367(),
                class_310.method_1551().field_1769,
                false,
                10
        );
        this.originalLevel = level;

        setClientSide(false);

    }

    public void setClientSide(boolean isClientSide) {
        ((LevelAccessorMixin) this).tmbl$setClientSide(isClientSide);
    }

    public static FakeClientLevel getOrThrow() {
        FakeClientLevel instance = INSTANCE;
        if (instance == null) {
            throw new IllegalStateException("Tried accessing FakeClientLevel before any ClientLevel was initialized.");
        }
        instance.originalLevel = class_310.method_1551().field_1687;
        instance.blockLiveSet.clear();

        return instance;
    }

    @Override
    public class_2680 method_8320(class_2338 pos) {
        class_2680 blockState = super.method_8320(pos);
        if(!blockState.method_26225()) {
            Optional<BlockLive> previewed = blockLiveSet.stream().filter(like -> like.pos.equals(pos)).findAny();

            if (previewed.isPresent()){
                return previewed.get().state;
            }
        }
        return blockState;
    }

    @Override
    public boolean method_30092(class_2338 pos, class_2680 state, int flags, int recursionLeft) {
        blockLiveSet.add(new BlockLive(pos, state));
        return false;
    }

    @Override
    public void method_8522(class_2596<?> packet) {

    }

    @Override
    public void method_41926(class_2338 pos, class_2680 state, class_243 playerPos) {
    }

    @Override
    public void method_38534() {
    }

    @Override
    public void method_38536(Runnable task) {
    }

    @Override
    public void method_41927(int sequence) {
    }

    @Override
    public void method_8435(long time) {
    }

    @Override
    public void method_29089(long time) {
    }

    @Override
    public void method_8441(BooleanSupplier hasTimeLeft) {
    }

    @Override
    public void method_18116() {
    }

    @Override
    public void method_18646(class_1297 p_entity) {
    }

    @Override
    public void method_18110(class_2818 chunk) {
    }

    @Override
    public void method_23782(class_1923 chunkPos) {
    }

    @Override
    public void method_23784() {
    }


    @Override
    public void method_18107(int playerId, class_742 playerEntity) {

    }

    @Override
    public boolean method_8649(class_1297 entity) {
        return false;
    }

    @Override
    public void method_8525() {
    }

    @Override
    public void method_2941(int posX, int posY, int posZ) {
    }

    @Override
    public void method_8413(class_2338 pos, class_2680 oldState, class_2680 newState, int flags) {
    }

    @Override
    public void method_18113(int sectionX, int sectionY, int sectionZ) {
    }

    @Override
    public void method_16109(class_2338 blockPos, class_2680 oldState, class_2680 newState) {
    }

    @Override
    public void method_8517(int breakerId, class_2338 pos, int progress) {
    }

    @Override
    public void method_8474(int id, class_2338 pos, int data) {
    }

    @Override
    public void method_8509(int timeFlash) {
    }

    @Override
    public void method_27873(class_2338 spawnPos, float spawnAngle) {
    }


    @Override
    public void method_39023(int serverSimulationDistance) {
    }

    @Override
    public void method_41928(class_2338 pos, class_2680 state, int flags) {
    }

    @Override
    public List<class_742> method_18456() {
        return new ArrayList<>();
    }

    @Override
    public void method_8519(float strength) {
    }

    @Override
    public void method_8496(float strength) {
    }

    @Override
    public void method_8424(boolean hostile, boolean peaceful) {
    }

    @Override
    public void method_8438(class_2586 blockEntity) {
    }
}
