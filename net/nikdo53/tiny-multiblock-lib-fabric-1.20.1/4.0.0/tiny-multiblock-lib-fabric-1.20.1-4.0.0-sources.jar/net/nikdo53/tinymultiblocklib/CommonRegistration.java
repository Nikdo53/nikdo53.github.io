package net.nikdo53.tinymultiblocklib;

import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_4970;
import net.nikdo53.tinymultiblocklib.blockentities.SimpleMultiBlockEntity;
import net.nikdo53.tinymultiblocklib.blockentities.SimpleStructureMultiBlockEntity;
import net.nikdo53.tinymultiblocklib.platform.Services;
import net.nikdo53.tinymultiblocklib.platform.services.IRegistrationUtils;
import net.nikdo53.tinymultiblocklib.test.DiamondStructureBlock;
import net.nikdo53.tinymultiblocklib.test.GhostBlockItem;
import net.nikdo53.tinymultiblocklib.test.SimpleMultiblock;
import net.nikdo53.tinymultiblocklib.test.TestBlock;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Supplier;

public interface CommonRegistration {
    IRegistrationUtils REGISTRATION = Services.PLATFORM.getRegistration();

    static void init(){
        BlockReg.init();
        BlockEntities.init();
        ItemReg.init();
    }

    interface BlockReg {
        Supplier<class_2248> TEST_BLOCK =
                REGISTRATION.registerBlockWithItem("test_block", TestBlock::new, () -> class_4970.class_2251.method_9630(class_2246.field_10566));

        Supplier<class_2248> DIAMOND_STRUCTURE_BLOCK =
                REGISTRATION.registerBlockWithItem("diamond_structure", DiamondStructureBlock::new, () -> class_4970.class_2251.method_9630(class_2246.field_10201));

        Supplier<class_2248> SIMPLE_MULTIBLOCK =
                REGISTRATION.registerBlockWithItem("simple_multiblock", SimpleMultiblock::new,() -> class_4970.class_2251.method_9630(class_2246.field_10566));

        static void init(){

        }
    }

    interface ItemReg{
        Supplier<class_1792> GHOST_BLOCK_ITEM = REGISTRATION.registerItem("ghost_block_item", GhostBlockItem::new);

        static void init(){}
    }

    interface BlockEntities{
         Set<class_2248> VALID_BLOCKS_SIMPLE = new HashSet<>();
         Set<class_2248> VALID_BLOCKS_STRUCTURE = new HashSet<>();

         Supplier<class_2591<SimpleMultiBlockEntity>> SIMPLE_MULTIBLOCK_ENTITY =
                REGISTRATION.registerBlockEntity("simple_multiblock_entity", SimpleMultiBlockEntity::new, CommonRegistration.BlockEntities.VALID_BLOCKS_SIMPLE);

         Supplier<class_2591<SimpleStructureMultiBlockEntity>> SIMPLE_STRUCTURE_MULTIBLOCK_ENTITY =
                REGISTRATION.registerBlockEntity("simple_structure_multiblock_entity", SimpleStructureMultiBlockEntity::new, CommonRegistration.BlockEntities.VALID_BLOCKS_STRUCTURE);

        static void init(){

        }
    }
}
