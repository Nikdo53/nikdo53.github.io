package net.nikdo53.tinymultiblocklib.block;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.world.level.*;
import net.nikdo53.tinymultiblocklib.Constants;
import net.nikdo53.tinymultiblocklib.block.logic.MultiblockLogic;
import net.nikdo53.tinymultiblocklib.block.shape.MultiblockShape;
import net.nikdo53.tinymultiblocklib.block.shape.ShapeContext;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.UnaryOperator;


/**
 * @deprecated Use {@link LogicMultiblock} or {@link BaseMultiblock} instead
 */
@Deprecated
public abstract class AbstractMultiBlock extends BaseMultiblock implements IMovableMultiblock, class_2343 {
    /**
     * The BlockState of the multiblocks center block, ideally you should forward all logic to this block
     * <p>
     * Note that even though it's called "CENTER", it isn't necessarily the actual center.
     * The center is just where the block would be placed if it were just a single block
     * @see #isCenter(BlockState)
     * @see #getCenter(BlockGetter, BlockPos)
     * */
    public static final class_2746 CENTER = BaseMultiblock.CENTER;

    public AbstractMultiBlock(class_2251 properties) {
        super(properties);
    }

    public abstract List<class_2338> makeFullBlockShape(class_1937 level, class_2338 center, class_2680 state, @Nullable class_2586 blockEntity, @Nullable class_2350 direction);

    @Override
    public void makeMultiblockShape(MultiblockShape.Builder builder, ShapeContext context) {
        class_2680 state = context.getBlockState();
        class_2754<class_2350> directionProperty = getDirectionProperty();
        List<class_2338> list = makeFullBlockShape(context.getLevel(), context.getCenterPos(), state, context.getBlockEntity(), directionProperty != null ? state.method_11654(directionProperty) : null);
        Set<class_2338> set = new HashSet<>(list);
        if (set.size() < list.size()) {
            Constants.LOGGER.error("Multiblock {} at {} has overlapping blocks in it's shape,"
                            + " this is likely caused by the BlockPos being mutable."
                            + " Either map them to BlockPos::immutable or use IMultiBlock.posStreamToList()",
                    state.toString(), context.getCenterPos());
        }

        list.forEach(pos -> builder.addGlobal(pos, getDefaultCenterLogic(context), UnaryOperator.identity()));

    }

    @Override
    public MultiblockLogic getDefaultCenterLogic(ShapeContext context) {
        return MultiblockLogic.EMPTY;
    }
}
