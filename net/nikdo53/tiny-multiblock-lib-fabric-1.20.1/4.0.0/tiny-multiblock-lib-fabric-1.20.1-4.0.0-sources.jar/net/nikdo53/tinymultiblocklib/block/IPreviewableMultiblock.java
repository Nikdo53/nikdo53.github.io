package net.nikdo53.tinymultiblocklib.block;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.nikdo53.tinymultiblocklib.components.PreviewMode;

public interface IPreviewableMultiblock extends IMultiBlock {
    /**
     * Returns the default BlockState that will be used for previews
     * */
    default class_2680 getDefaultStateForPreviews(class_2680 state, class_1750 blockPlaceContext) {
        return state;
    };

    private class_2248 self(){
        if (this instanceof class_2248 block){
            return block;
        } else {
            throw new RuntimeException(this.getClass().getSimpleName() + " is not implemented on a Block");
        }
    }
}
