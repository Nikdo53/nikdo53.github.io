package net.nikdo53.tinymultiblocklib.block.logic;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import net.nikdo53.tinymultiblocklib.components.BlockLive;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;

public class DelegatingMultiblockLogic extends MultiblockLogic{
    public static final DelegatingMultiblockLogic INSTANCE = new DelegatingMultiblockLogic();

    public static BlockLive getCenterBlock(class_1922 level, class_2338 pos) {
        class_2338 center = IMultiBlock.getCenter(level, pos);
        return new BlockLive(level, center);
    }

    @Override
    public void method_9517(class_2680 state, class_1936 level, class_2338 pos, int updateFlags, int updateLimit) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        centerBlock.state.method_26198(level, centerBlock.pos, updateFlags, updateLimit);
    }

    @Override
    public void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        centerBlock.state.method_26197(level, centerBlock.pos, newState, movedByPiston);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        return centerBlock.state.method_26174(level, player, hand, hit.method_29328(centerBlock.pos));
    }

    @Override
    public boolean method_9592(class_2680 state, class_1937 level, class_2338 pos, int b0, int b1) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        return centerBlock.state.method_26177(level, centerBlock.pos, b0, b1);
    }

    @Override
    public @Nullable class_3908 method_17454(class_2680 state, class_1937 level, class_2338 pos) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        return centerBlock.state.method_26196(level, centerBlock.pos);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        return centerBlock.state.method_26184(level, centerBlock.pos);
    }

    @Override
    public float method_9575(class_2680 state, class_1922 level, class_2338 pos) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        return centerBlock.state.method_26210(level, centerBlock.pos);
    }

    @Override
    public int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        return centerBlock.state.method_26176(level, centerBlock.pos);
    }

    @Override
    public void method_9565(class_2680 state, class_3218 level, class_2338 pos, class_1799 tool, boolean dropExperience) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        centerBlock.state.method_26180(level, centerBlock.pos, tool, dropExperience);
    }

    @Override
    public void method_9606(class_2680 state, class_1937 level, class_2338 pos, class_1657 player) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        centerBlock.state.method_26179(level, centerBlock.pos, player);
    }

    @Override
    public int method_9524(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        return centerBlock.state.method_26195(level, centerBlock.pos, direction);
    }

    @Override
    public void method_9548(class_2680 state, class_1937 level, class_2338 pos, class_1297 entity) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        centerBlock.state.method_26178(level, centerBlock.pos, entity);
    }

    @Override
    public int method_9603(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        BlockLive centerBlock = getCenterBlock(level, pos);
        return centerBlock.state.method_26203(level, centerBlock.pos, direction);
    }

    @Override
    public void method_19286(class_1937 level, class_2680 state, class_3965 blockHit, class_1676 projectile) {
        BlockLive centerBlock = getCenterBlock(level, blockHit.method_17777());
        centerBlock.state.method_26175(level, state, blockHit.method_29328(centerBlock.pos), projectile);
    }
}
