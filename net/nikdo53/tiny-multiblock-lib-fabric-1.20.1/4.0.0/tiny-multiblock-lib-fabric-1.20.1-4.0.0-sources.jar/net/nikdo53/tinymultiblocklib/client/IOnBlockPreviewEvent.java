package net.nikdo53.tinymultiblocklib.client;

import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.nikdo53.tinymultiblocklib.components.BlockLive;
import net.nikdo53.tinymultiblocklib.components.PreviewMode;
import net.nikdo53.tinymultiblocklib.platform.Services;
import org.jetbrains.annotations.Nullable;

import javax.annotation.Nonnull;
import java.util.Set;

public interface IOnBlockPreviewEvent {
    PreviewMode getPreviewMode();
    void setPreviewMode(PreviewMode result);

    boolean isCancelledInternal();
    void setCancelledInternal(boolean canceled);

    BlockLive getCenterBlockLive();
    @Nonnull
    Set<BlockLive> getBlocksForPreview();

    default class_2680 getCenterBlockState() {
        return getCenterBlockLive().state;
    }

    default class_2338 getCenter() {
        return getCenterBlockLive().pos;
    }

    @Nullable
    default class_2586 getCenterBlockEntity() {
        return getCenterBlockLive() instanceof BlockLive.Live live ? live.blockEntity : null;
    }


    static IOnBlockPreviewEvent firePreEvent(PreviewMode previewMode, boolean isCancelled, BlockLive center, Set<BlockLive> blockLiveSet) {
       return Services.PLATFORM.getEventPoster().onBlockPreviewPre(previewMode, isCancelled, center, blockLiveSet);
    }

    static void firePostEvent(PreviewMode previewMode, BlockLive center, Set<BlockLive> blockLiveSet, class_4587 poseStack, float partialTicks, class_4597.class_4598 bufferSource){
        Services.PLATFORM.getEventPoster().onBlockPreviewPost(previewMode, center, blockLiveSet, poseStack, partialTicks, bufferSource);
    }

}
