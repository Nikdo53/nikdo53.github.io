package net.nikdo53.tinymultiblocklib.client;

import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1841;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3726;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_6319;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_776;
import net.minecraft.class_827;
import net.minecraft.client.renderer.*;
import net.nikdo53.tinymultiblocklib.Constants;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import net.nikdo53.tinymultiblocklib.block.shape.MultiblockShape;
import net.nikdo53.tinymultiblocklib.blockentities.IMultiBlockEntity;
import net.nikdo53.tinymultiblocklib.block.IPreviewableMultiblock;
import net.nikdo53.tinymultiblocklib.compat.carryon.CarryOnPreviewHelper;
import net.nikdo53.tinymultiblocklib.components.BlockLive;
import net.nikdo53.tinymultiblocklib.components.PreviewMode;
import net.nikdo53.tinymultiblocklib.config.TMBLClientConfig;
import net.nikdo53.tinymultiblocklib.data.TMBLTags;
import net.nikdo53.tinymultiblocklib.mixin.BlockItemAccessor;
import net.nikdo53.tinymultiblocklib.mixin.ItemAccessor;
import net.nikdo53.tinymultiblocklib.platform.Services;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.annotation.Nonnull;
import java.util.HashSet;
import java.util.Set;

@class_6319
public class MultiblockPreviewRenderer {
    public static final Set<class_2248> PREVIEW_CRASHLIST = new HashSet<>();
    public static final Set<class_2248> SET_PLACED_BY_BLACKLIST = new HashSet<>();

    final class_310 minecraft;
    final class_746 player;
    final class_638 level;
    FakeClientLevel fakeLevel = FakeClientLevel.getOrThrow();

    class_1799 stack;
    class_1792 item;

    @Nullable class_2248 currentBlock = null;
    boolean placeOnWater = false;
    @Nullable class_3965 blockHitResult = null;

    @Nullable MultiblockShape multiblockShape = null;
    PreviewMode previewMode = PreviewMode.PREVIEW;

    public MultiblockPreviewRenderer(class_310 minecraft, class_746 player, class_638 level) {
        this.minecraft = minecraft;
        this.player = player;
        this.level = level;

        stack = player.method_6047();
        item = stack.method_7909();

        if (Services.PLATFORM.isModLoaded("carryon")) {
            if (CarryOnPreviewHelper.isValidMultiblock(player))
                item = CarryOnPreviewHelper.getMultiblockItem(player);
        }
    }


    public static void tryRenderMultiblockPreviews(float partialTick, class_4184 camera, class_4587 poseStack) {
        if (TMBLClientConfig.DISABLE_MULTIBLOCK_PREVIEWS.get()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        FakeClientLevel.getOrThrow().clear();


        MultiblockPreviewRenderer renderer = new MultiblockPreviewRenderer(mc, mc.field_1724, mc.field_1687);
        try {
            renderer.renderMultiblockPreviews(partialTick, camera, poseStack);
        } catch (Exception e) {
            class_2248 block = renderer.currentBlock;
            if (block != null) {
                PREVIEW_CRASHLIST.add(block);
                Constants.LOGGER.error("Error rendering multiblock preview: " + e.getMessage() + ". Adding " + block + " to blacklist to prevent further errors", e);
            } else {
                Constants.LOGGER.error("Error rendering multiblock preview: " + e.getMessage() + " this should never happen unless its carryons fault ig", e);
            }

        }
    }

    public void renderMultiblockPreviews(float partialTick, class_4184 camera, class_4587 poseStack) {
        if (!(item instanceof class_1747 blockItem)) return;
        if (!(minecraft.field_1765 instanceof class_3965)) return;

        blockHitResult = (class_3965) minecraft.field_1765;
        currentBlock = blockItem.method_7711();

        if (!canShowPreview(stack, currentBlock))
            return;

        checkPlaceOnWater();
        centerPos = getCenterPos(blockHitResult.method_17777());
        centerState = getCenterBlockState();
        centerBlockEntity = getCenterBlockEntity();
        multiblockShape = getMultiblockShape();

        fakeLevel.blockLiveSet = gatherBlockLives();
        IOnBlockPreviewEvent event = IOnBlockPreviewEvent.firePreEvent(checkPreviewMode(hasNullState), shouldHidePreview(), getCenterBlockLive(), gatherBlockLives());

        if (!event.isCancelledInternal()) {
            blockLiveSet = event.getBlocksForPreview();
            fakeLevel.blockLiveSet = blockLiveSet;
            previewMode = event.getPreviewMode();

            poseStack.method_22903();

            poseStack.method_22904(-camera.method_19326().field_1352, -camera.method_19326().field_1351, -camera.method_19326().field_1350
            );

            TintedBufferSource bufferSource = new TintedBufferSource(minecraft.method_22940().method_23000(), previewMode);

            for (BlockLive blockLive : blockLiveSet) {
                renderJsonModels(blockLive, poseStack, bufferSource);
            }

            for (BlockLive blockLive : blockLiveSet) {
                renderBlockEntity(blockLive, poseStack, partialTick, bufferSource);
            }

            IOnBlockPreviewEvent.firePostEvent(previewMode, getCenterBlockLive(), blockLiveSet, poseStack, partialTick, bufferSource);

            bufferSource.method_37104();

            poseStack.method_22909();
        }


    }

    private @NotNull BlockLive getCenterBlockLive() {
        return BlockLive.Live.optionalBE(centerPos, getCenterBlockState(), getCenterBlockEntity());
    }

    private void checkPlaceOnWater() {
        if (item instanceof class_1841) {
            blockHitResult = ItemAccessor.getPlayerPOVHitResult(level, player, class_3959.class_242.field_1345);
            placeOnWater = level.method_22351(blockHitResult.method_17777());
        }
    }

    private boolean shouldHidePreview() {
        return !(level.method_8320(centerPos).method_45474()
                && (!level.method_8320(blockHitResult.method_17777()).method_26215() || placeOnWater));
    }

    @Nullable class_2338 centerPos = null;
    private @NotNull class_2338 getCenterPos(class_2338 hitPos) {
        if (centerPos != null) {
            return centerPos;
        }

        assert blockHitResult != null;
        return !(level.method_8320(hitPos).method_45474() && !placeOnWater) ? hitPos.method_10093(blockHitResult.method_17780()) : hitPos;
    }

    private @Nullable MultiblockShape getMultiblockShape() {
        if (multiblockShape != null) {
            return multiblockShape;
        }

        assert centerPos != null;
        return currentBlock instanceof IMultiBlock multiBlock
                ? multiBlock.getMultiblockShapeNoCache(centerPos, getCenterBlockState(), level, getCenterBlockEntity())
                : null;
    }

    @Nullable class_2586 centerBlockEntity = null;
    private @Nullable class_2586 getCenterBlockEntity() {
        if (centerBlockEntity != null) {
            return centerBlockEntity;
        }

        assert centerPos != null;
        class_2586 centerBlockEntity = currentBlock instanceof class_2343 entityBlock
                ? entityBlock.method_10123(centerPos, getCenterBlockState())
                : null;
        if (centerBlockEntity != null) {
            centerBlockEntity.method_31662(level);
        }
        return centerBlockEntity;
    }

    @Nullable class_2680 centerState = null;
    boolean hasNullState = false;
    private @Nonnull class_2680 getCenterBlockState() {
        if (centerState != null) {
            return centerState;
        }

        assert blockHitResult != null;
        assert currentBlock != null;

        class_1750 blockPlaceContext = new class_1750(player, class_1268.field_5808, stack, blockHitResult);

        class_2680 centerState = ((BlockItemAccessor) item).tinyMultiblockLib$getPlacementState(blockPlaceContext);
        if (centerState == null) {
            centerState = currentBlock.method_9605(blockPlaceContext);
        }

        hasNullState = centerState == null;
        if (hasNullState){
            centerState = currentBlock.method_9564();

            if (currentBlock instanceof IMultiBlock multiBlock && multiBlock.makeDirectional() != null){
                IMultiBlock.DirectionContext directionContext = multiBlock.makeDirectional();
                assert directionContext != null;
                class_2350 dir = directionContext.directionExtractor().apply(blockPlaceContext);

                if (dir != null) {
                    centerState = centerState.method_11657(directionContext.property(), dir);
                }
            }
        }

        if (currentBlock instanceof IPreviewableMultiblock multiblock){
            centerState = multiblock.getDefaultStateForPreviews(centerState, blockPlaceContext);
        }
        return centerState;
    }

    public boolean canShowPreview(class_1799 stack, class_2248 block) {
        if (TMBLClientConfig.PREVIEWS_FOR_EVERYTHING.get())
            return true;
        if (PREVIEW_CRASHLIST.contains(block))
            return false;

        String registeredName = block.method_40142().method_40237().method_29177().toString();
        return (stack.method_31573(TMBLTags.ItemTags.SHOW_PREVIEW)
                || block instanceof IPreviewableMultiblock
                || TMBLClientConfig.PREVIEW_WHITELIST.get().contains(registeredName)
        ) && !TMBLClientConfig.PREVIEW_BLACKLIST.get().contains(registeredName);
    }

    private void renderBlockEntity(BlockLive blockLive, class_4587 poseStack, float partialTick, class_4597.class_4598 buffer) {
        class_2680 state = blockLive.state;
        class_2338 pos = blockLive.pos;

        if (state.method_26217() == class_2464.field_11455) {
            return;
        }

        if (state.method_26204() instanceof class_2343 entityBlock) {

            class_2586 entity = entityBlock.method_10123(pos, state);
            if (entity == null) return;
            entity.method_31662(fakeLevel);

            if (entity instanceof IMultiBlockEntity multiBlockEntity) {
                multiBlockEntity.setCenter(pos);
                multiBlockEntity.setPreviewMode(previewMode);
            }

            class_827<class_2586> entityRender = minecraft.method_31975().method_3550(entity);

            if (entityRender != null) {
                poseStack.method_22903();
                poseStack.method_22904(0.0001, 0.0001, 0.0001);

                poseStack.method_46416(blockLive.pos.method_10263(), blockLive.pos.method_10264(), blockLive.pos.method_10260());

                entityRender.method_3569(entity, partialTick, poseStack, buffer, 0xFFFFFF, class_4608.field_21444);

                poseStack.method_22909();

            }
        }
    }

    private PreviewMode checkPreviewMode(boolean hasNullState) {
        boolean canPlace = true;
        boolean entityUnobstructed = true;
        for (BlockLive blockLive : gatherBlockLives()) {
           if (canPlace) canPlace = canPlace(blockLive);
           if (entityUnobstructed) entityUnobstructed = isEntityUnobstructed(blockLive);
        }

        PreviewMode ret = canPlace ? (entityUnobstructed ? PreviewMode.PREVIEW : PreviewMode.ENTITY_BLOCKED) : PreviewMode.INVALID;
        if (ret == PreviewMode.PREVIEW && hasNullState){
            return PreviewMode.INVALID;
        }
        return ret;
    }

    private boolean isEntityUnobstructed(BlockLive blockLive) {
        class_2680 state = blockLive.state;
        class_2338 pos = blockLive.pos;
        if (state.method_26204() instanceof IMultiBlock multiBlock && multiblockShape != null) {
            return multiBlock.entityUnobstructed(level, pos, state, player, multiblockShape);
        }

        return level.method_8628(state, pos, class_3726.method_16195(player));
    }

    private boolean canPlace(BlockLive blockLive) {
        class_2680 state = blockLive.state;
        class_2338 pos = blockLive.pos;
        if (state.method_26204() instanceof IMultiBlock multiBlock && multiblockShape != null) {
            return multiBlock.canPlaceBlock(pos, level, pos, state, player, true, multiblockShape);
        };

        return state.method_26184(fakeLevel, pos);
    }

    private void renderJsonModels(BlockLive blockLive, class_4587 poseStack, TintedBufferSource bufferSource) {
        if (!blockLive.state.method_26217().equals(class_2464.field_11458)) return;
        assert centerPos != null;

        class_776 blockRenderer = minecraft.method_1541();
        poseStack.method_22903();
        poseStack.method_22904(0.0001, 0.0001, 0.0001);

        poseStack.method_46416(blockLive.pos.method_10263(), blockLive.pos.method_10264(), blockLive.pos.method_10260());

        RenderUtils.CHECK_SIDES_CONTEXT = new RenderUtils.CheckSidesContext(fakeLevel, blockLive.state, blockLive.pos);
        blockRenderer.method_3353(blockLive.state, poseStack, bufferSource, 0xFFFFFF, class_4608.field_21444);
        RenderUtils.CHECK_SIDES_CONTEXT = null;

        poseStack.method_22909();
    }

    @Nullable Set<BlockLive> blockLiveSet = null;
    private Set<BlockLive> gatherBlockLives() {
        if (blockLiveSet != null) {
            return blockLiveSet;
        }

        assert currentBlock != null;
        assert centerPos != null;
        assert centerState != null;

        Set<BlockLive> blockLiveSet = new HashSet<>();

        if (currentBlock instanceof IMultiBlock multiBlock) {
            blockLiveSet.addAll(multiBlock.prepareForPlace(multiBlock.getMultiblockShapeNoCache(centerPos, centerState, level, centerBlockEntity), level, centerPos, centerState));
        } else {
            blockLiveSet.add(BlockLive.Live.optionalBE(centerPos, centerState, centerBlockEntity));
        }

        if (!SET_PLACED_BY_BLACKLIST.contains(currentBlock)) {
            try {
                currentBlock.method_9567(fakeLevel, centerPos, centerState, player, stack);
            } catch (Exception ignored) {
                Constants.LOGGER.warn("setPlacedBy failed for block {} adding to ignore list...", currentBlock);
                SET_PLACED_BY_BLACKLIST.add(currentBlock);
            }
        }

        for (BlockLive toAdd : fakeLevel.blockLiveSet) {
            if (blockLiveSet.stream().map(b -> b.pos).noneMatch(p -> p.equals(toAdd.pos))) {
                blockLiveSet.add(toAdd);
            }
        }
        this.blockLiveSet = blockLiveSet;
        return blockLiveSet;
    }
}
