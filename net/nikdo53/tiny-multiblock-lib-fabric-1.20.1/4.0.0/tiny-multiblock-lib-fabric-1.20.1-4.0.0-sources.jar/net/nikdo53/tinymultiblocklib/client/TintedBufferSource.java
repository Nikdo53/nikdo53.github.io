package net.nikdo53.tinymultiblocklib.client;

import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.nikdo53.nikdocolor.IColorSupplier;
import net.nikdo53.tinymultiblocklib.mixin.BufferSourceAccessor;
import net.nikdo53.tinymultiblocklib.mixin.RenderStateShardAccessor;
import net.nikdo53.tinymultiblocklib.mixin.RenderTypeAccessor;
import net.nikdo53.tinymultiblocklib.platform.Services;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.UnaryOperator;

public class TintedBufferSource extends class_4597.class_4598{
    public IColorSupplier color;
    public class_4598 originalBuffer;
    public UnaryOperator<class_1921> renderTypeTransformer;

    public TintedBufferSource(class_4598 bufferSource, IColorSupplier color, UnaryOperator<class_1921> renderTypeTransformer) {
        super(((BufferSourceAccessor)bufferSource).getSharedBuffer(), ((BufferSourceAccessor)bufferSource).getFixedBuffers());
        this.color = color;
        this.originalBuffer = bufferSource;
        this.renderTypeTransformer = renderTypeTransformer;
    }

    public TintedBufferSource(class_4598 bufferSource, IColorSupplier color) {
        this(bufferSource, color, TintedBufferSource::getTranslucent);
    }


    @Override
    public void method_37104() {
        originalBuffer.method_37104();
    }

    @Override
    public void method_22993() {
        originalBuffer.method_22993();
    }

    @Override
    public void method_22994(class_1921 renderType) {
        originalBuffer.method_22994(renderType);
    }

    @Override
    public class_4588 getBuffer(class_1921 renderType) {
        class_1921 transformedRenderType = renderTypeTransformer.apply(renderType);
        class_4588 original = originalBuffer.getBuffer(transformedRenderType);

        return new TintedVertexConsumer(original, color);
    }

    public static final List<Pair<String, Function<Optional<class_2960>, class_1921>>> VALID_TYPES = getExtraTypes();

    private static @NotNull List<Pair<String, Function<Optional<class_2960>, class_1921>>> getExtraTypes() {
        List<Pair<String, Function<Optional<class_2960>, class_1921>>> list = new ArrayList<>();
        list.add(new Pair<>("entity_cutout_no_cull",
                loc -> renderTypeOrNull(loc, class_1921::method_23580)));
        list.add(new Pair<>("entity_cutout_no_cull_z_offset",
                loc -> renderTypeOrNull(loc, class_1921::method_23580)));
        list.add(new Pair<>("armor_cutout_no_cull",
                loc -> renderTypeOrNull(loc, class_1921::method_23580)));

        return list;
    }

    public static class_1921 getTranslucent(class_1921 renderType) {
        Optional<Pair<String, Function<Optional<class_2960>, class_1921>>> any = VALID_TYPES.stream()
                .filter(pair -> pair.getFirst().equals(getName(renderType)))
                .findAny();

        if (any.isPresent()) {
            class_1921 translucent = getRenderTypeFromFunction(renderType, any.get().getSecond());
            if (translucent != null)
                return translucent;
        }

        class_293.class_5596 mode = ((RenderTypeAccessor) renderType).getMode();
        class_293 format = ((RenderTypeAccessor) renderType).getFormat();
        if (mode == class_293.class_5596.field_27382){
            if (format == class_290.field_1590){
                return class_1921.method_29380();
            } else if (format == class_290.field_1580){
                Optional<class_2960> resourceLocation = Services.PLATFORM.getUtils().locFromRenderType(renderType);
                if (resourceLocation.isPresent()){
                    return class_1921.method_23689(resourceLocation.get());
                }
            }
        }

        return renderType;
    }

    private static @Nullable class_1921 getRenderTypeFromFunction(class_1921 renderType, Function<Optional<class_2960>, class_1921> func) {
        Optional<class_2960> loc = Services.PLATFORM.getUtils().locFromRenderType(renderType);

        return func.apply(loc);
    }

    public static class_1921 renderTypeOrNull(Optional<class_2960> location, Function<class_2960, class_1921> function){
        return location.map(function).orElse(null);
    }

    public static String getName(class_1921 renderType) {
        return ((RenderStateShardAccessor) renderType).getName();
    }
}
