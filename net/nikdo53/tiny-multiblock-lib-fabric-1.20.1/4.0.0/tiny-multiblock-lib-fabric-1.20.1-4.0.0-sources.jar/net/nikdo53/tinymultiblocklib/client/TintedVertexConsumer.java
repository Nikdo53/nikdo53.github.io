package net.nikdo53.tinymultiblocklib.client;

import net.minecraft.class_4588;
import net.nikdo53.nikdocolor.IColorSupplier;

public class TintedVertexConsumer extends VertexConsumerWrapper {
    public IColorSupplier colorSupplier;

    public TintedVertexConsumer(class_4588 parent, IColorSupplier colorSupplier) {
        super(parent);
        this.colorSupplier = colorSupplier;
    }


    @Override
    public void method_23919(float x, float y, float z, float red, float green, float blue, float alpha, float texU, float texV, int overlayUV, int lightmapUV, float normalX, float normalY, float normalZ) {
        float[] colors = colorSupplier.applyColorsFloat(red, green, blue, alpha);
        super.method_23919(x, y, z, colors[0], colors[1], colors[2], colors[3], texU, texV, overlayUV, lightmapUV, normalX, normalY, normalZ);
    }

    @Override
    public class_4588 method_1336(int r, int g, int b, int a) {
        float[] colors = colorSupplier.applyColorsFloat(r, g, b, a);
        return super.method_1336(((int) colors[0]), (int) colors[1], (int) colors[2], (int) colors[3]);
    }

    @Override
    public class_4588 method_22915(float red, float green, float blue, float alpha) {
        float[] colors = colorSupplier.applyColorsFloat(red, green, blue, alpha);
        return super.method_22915(colors[0], colors[1], colors[2], colors[3]);
    }

    @Override
    public class_4588 method_39415(int colorARGB) {
        return super.method_39415(colorSupplier.applyColors(colorARGB));
    }
}
