package net.nikdo53.tinymultiblocklib.client;

import net.minecraft.class_4588;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public abstract class VertexConsumerWrapper implements class_4588{
    protected final class_4588 parent;

    public VertexConsumerWrapper(class_4588 parent) {
        this.parent = parent;
    }

    @Override
    public class_4588 method_22912(double x, double y, double z)
    {
        parent.method_22912(x, y, z);
        return this;
    }

    @Override
    public class_4588 method_1336(int r, int g, int b, int a)
    {
        parent.method_1336(r, g, b, a);
        return this;
    }

    @Override
    public class_4588 method_22913(float u, float v)
    {
        parent.method_22913(u, v);
        return this;
    }

    @Override
    public class_4588 method_22917(int u, int v)
    {
        parent.method_22917(u, v);
        return this;
    }

    @Override
    public class_4588 method_22921(int u, int v)
    {
        parent.method_22921(u, v);
        return this;
    }

    @Override
    public class_4588 method_22914(float x, float y, float z)
    {
        parent.method_22914(x, y, z);
        return this;
    }

    @Override
    public void method_23919(float x, float y, float z, float red, float green, float blue, float alpha, float texU, float texV, int overlayUV, int lightmapUV, float normalX, float normalY, float normalZ) {
        parent.method_23919(x, y, z, red, green, blue, alpha, texU, texV, overlayUV, lightmapUV, normalX, normalY, normalZ);
    }

    @Override
    public class_4588 method_22915(float red, float green, float blue, float alpha) {
        parent.method_22915(red, green, blue, alpha);
        return this;
    }

    @Override
    public class_4588 method_39415(int colorARGB) {
        parent.method_39415(colorARGB);
        return this;

    }

    @Override
    public class_4588 method_22916(int lightmapUV) {
        parent.method_22916(lightmapUV);
        return this;

    }

    @Override
    public class_4588 method_22922(int overlayUV) {
        parent.method_22922(overlayUV);
        return this;
    }

    @Override
    public class_4588 method_22918(Matrix4f matrix, float x, float y, float z) {
        parent.method_22918(matrix, x, y, z);
        return this;

    }

    @Override
    public class_4588 method_23763(Matrix3f matrix, float x, float y, float z) {
        parent.method_23763(matrix, x, y, z);
        return this;
    }

    @Override
    public void method_1344()
    {
        parent.method_1344();
    }

    @Override
    public void method_22901(int r, int g, int b, int a)
    {
        parent.method_22901(r, g, b, a);
    }

    @Override
    public void method_35666()
    {
        parent.method_35666();
    }
}
