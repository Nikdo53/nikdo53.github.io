package net.nikdo53.tinymultiblocklib.client.ghost;

import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_638;

public class GhostBlockEntityRenderer extends GhostRenderer<GhostBlockEntityRenderer>{
    class_2586 blockEntity;
    protected int packedOverlay = class_4608.field_21444;

    public GhostBlockEntityRenderer(class_2338 pos, int ticksRemaining, class_2586 blockEntity) {
        super(pos, ticksRemaining);
        this.blockEntity = blockEntity;
    }

    @Override
    protected void render(float partialTick, class_4184 camera, class_638 level, class_4587 poseStack, class_4597.class_4598 buffer) {
        var entityRender = class_310.method_1551().method_31975().method_3550(blockEntity);

        if (entityRender != null) {
            entityRender.method_3569(blockEntity, partialTick, poseStack, buffer, getLight(), packedOverlay);

        }
    }


    public GhostBlockEntityRenderer setOverlay(int packedOverlay){
        this.packedOverlay = packedOverlay;
        return this;
    }
}
