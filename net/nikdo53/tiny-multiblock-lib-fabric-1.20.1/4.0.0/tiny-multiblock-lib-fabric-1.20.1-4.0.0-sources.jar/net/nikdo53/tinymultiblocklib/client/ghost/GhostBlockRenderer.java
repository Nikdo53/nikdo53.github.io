package net.nikdo53.tinymultiblocklib.client.ghost;

import net.minecraft.class_1921;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.nikdo53.tinymultiblocklib.client.FakeClientLevel;
import net.nikdo53.tinymultiblocklib.client.RenderUtils;
import org.jetbrains.annotations.Nullable;

public class GhostBlockRenderer extends GhostRenderer<GhostBlockRenderer>{
    protected class_2680 state;
    protected class_1921 renderType = class_4722.method_24076();
    protected boolean checkSides = true;
    protected @Nullable class_6880<class_1959> biome = null;
    protected int packedOverlay = class_4608.field_21444;

    public GhostBlockRenderer(class_2338 pos, int ticksRemaining, class_2680 state){
        super(pos, ticksRemaining);
        this.state = state;
    }

    @Override
    protected void render(float partialTick, class_4184 camera, class_638 level, class_4587 poseStack, class_4597.class_4598 buffer) {
        class_310.method_1551().method_1541().method_3353(
                state,
                poseStack,
                buffer,
                getLight(),
                packedOverlay
        );
    }

/* // these would require a custom renderer over renderSingleBlock()
    public GhostBlockRenderer setRenderType(RenderType renderType) {
        this.renderType = renderType;
        return this;
    }

    public GhostBlockRenderer setCheckSided(boolean checkSides) {
        this.checkSides = checkSides;
        return this;
    }

    public GhostBlockRenderer setBiome(@Nullable Holder<Biome> biome) {
        this.biome = biome;
        return this;
    }
*/

    public GhostBlockRenderer setOverlay(int packedOverlay){
        this.packedOverlay = packedOverlay;
        return this;
    }

}
