package net.nikdo53.tinymultiblocklib.client.ghost;

import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4730;
import net.minecraft.class_630;
import net.minecraft.class_638;
import net.minecraft.class_7833;
import net.nikdo53.tinymultiblocklib.client.RenderUtils;
import org.intellij.lang.annotations.Identifier;

import java.util.function.Function;

public class GhostModelRenderer extends GhostRenderer<GhostModelRenderer>{
    protected final class_630 MODEL_PART;
    protected final class_4730 MATERIAL;
    protected Function<class_2960, class_1921> renderTypeFunction = class_1921::method_23580;
    protected int packedOverlay = class_4608.field_21444;

    public GhostModelRenderer(class_2338 pos, int ticksRemaining, class_630 modelPart, class_4730 material) {
        super(pos, ticksRemaining);
        this.MODEL_PART = modelPart;
        this.MATERIAL = material;
    }

    @Override
    protected void render(float partialTick, class_4184 camera, class_638 level, class_4587 poseStack, class_4597.class_4598 buffer) {
        poseStack.method_46416(0.5f, 1.5f, 0.5f);
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(180f));
        MODEL_PART.method_22698(poseStack,
                MATERIAL.method_24145(buffer, renderTypeFunction),
                RenderUtils.getPackedLight(level, getBlockPos()), packedOverlay
        );
    }

    public GhostModelRenderer setRenderType(Function<class_2960, class_1921> renderTypeFunction){
        this.renderTypeFunction = renderTypeFunction;
        return this;
    }

    public GhostModelRenderer setOverlay(int packedOverlay){
        this.packedOverlay = packedOverlay;
        return this;
    }
}
