package net.nikdo53.tinymultiblocklib.client.ghost;

import com.mojang.datafixers.util.Either;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import net.nikdo53.nikdocolor.IColorSupplier;
import net.nikdo53.tinymultiblocklib.Constants;
import net.nikdo53.tinymultiblocklib.client.*;
import net.nikdo53.tinymultiblocklib.components.BlockLive;
import net.nikdo53.tinymultiblocklib.components.RenderOffsetType;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public abstract class GhostRenderer<T extends GhostRenderer<T>> {
    public static List<GhostRenderer<?>> RENDERERS = new ArrayList<>();

    protected Either<class_243, class_2338> posEither;
    protected int ticksRemaining;
    protected final int maxTicksRemaining;
    protected RenderOffsetType renderOffsetType = RenderOffsetType.SCALED;
    protected IColorSupplier colorStatic = new IColorSupplier.Simple(1, 1, 1, 1);
    protected @Nullable Integer packedLight = null;
    protected boolean shouldRender = true;

    protected float maxAlpha = 1;
    protected Integer fadeOutTicks = null;
    protected Pair<Double, Double> fadeDistanceAndStart = null;
    protected Consumer<class_4587> poseStackConsumer = p -> {};

    public GhostRenderer(class_243 position, int ticksRemaining) {
        this.posEither = Either.left(position);
        this.ticksRemaining = ticksRemaining;
        this.maxTicksRemaining = ticksRemaining;
    }

    public GhostRenderer(class_2338 blockPos, int ticksRemaining) {
        this.posEither = Either.right(blockPos);
        this.ticksRemaining = ticksRemaining;
        this.maxTicksRemaining = ticksRemaining;
    }

    protected class_243 getPosition() {
        if (posEither.left().isPresent())
            return posEither.left().get();
        return class_243.method_24954(posEither.right().orElseThrow());
    }

    protected class_2338 getBlockPos() {
        if (posEither.right().isPresent())
            return posEither.right().get();

        class_243 pos = posEither.left().orElseThrow();
        return class_2338.method_49637(pos.method_10216(), pos.method_10214(), pos.method_10215());
    }

    public void addToRenderList() {
        RENDERERS.add(this);
    }

    public static void renderAll(float partialTick, class_4184 camera, class_4587 poseStack){
        class_310 minecraft = class_310.method_1551();
        class_4597.class_4598 buffer = minecraft.method_22940().method_23000();
        class_638 level = minecraft.field_1687;
        if (level == null) return;

        double camX = camera.method_19326().field_1352;
        double camY = camera.method_19326().field_1351;
        double camZ = camera.method_19326().field_1350;

        poseStack.method_22903();
        poseStack.method_22904(-camX, -camY, -camZ);

        List<GhostRenderer<?>> renderers = new ArrayList<>(RENDERERS);
        renderers.forEach(renderer -> renderer.prepareAndRender(partialTick, camera, level, poseStack, buffer));
        buffer.method_37104();

        poseStack.method_22909();
    }

    public static void tickAll(){
        RENDERERS.removeIf(renderer -> {
            renderer.ticksRemaining--;
            return renderer.ticksRemaining < 0;
        });
    }

    protected void prepareAndRender(float partialTick, class_4184 camera, class_638 level, class_4587 poseStack, class_4597.class_4598 buffer){
        IColorSupplier.Mutable currentColor = new IColorSupplier.Mutable(1, 1, 1, 1);
        shouldRender = true;
        currentColor.copy(this.colorStatic);
        class_4597.class_4598 tintedBuffer = new TintedBufferSource(buffer, currentColor);

        if (fadeOutTicks != null) doTimeFade(partialTick, currentColor);
        if (fadeDistanceAndStart != null) doDistanceFade(fadeDistanceAndStart.getFirst(), fadeDistanceAndStart.getSecond(), camera.method_19326(), currentColor);

        if (!shouldRender)
            return;

        poseStack.method_22903();
        class_243 position = getPosition();
        poseStack.method_22904(position.method_10216(), position.method_10214(), position.method_10215());
        renderOffsetType.applyTransforms(poseStack);
        poseStackConsumer.accept(poseStack);

        render(partialTick, camera, level, poseStack, tintedBuffer);

        poseStack.method_22909();
    }

    private void doTimeFade(float partialTick, IColorSupplier.Mutable currentColor) {
        if (ticksRemaining <= fadeOutTicks){
            float smoothTicks = (ticksRemaining - partialTick) /  fadeOutTicks;
            if (smoothTicks < 0) smoothTicks = 0;

            currentColor.setAlpha(smoothTicks * currentColor.getAlpha());
        }
    }

    private void doDistanceFade(double maxDistance, double fadeStart, class_243 cameraPos, IColorSupplier.Mutable currentColor) {
        double camDistance = cameraPos.method_1022(getPosition());
        if (camDistance >= maxDistance) {
             shouldRender = false;
            return;
        }
        if (camDistance > fadeStart){
            double fullRange = maxDistance - fadeStart; // 3
            double positionInRange = maxDistance - camDistance; // 2
            double alphaFactor =  positionInRange / fullRange; // 0.66

            currentColor.setAlpha((float) alphaFactor * currentColor.getAlpha());
        }
    }

    protected abstract void render(float partialTick, class_4184 camera, class_638 level, class_4587 poseStack, class_4597.class_4598 buffer);

    protected int getLight(){
        class_310 minecraft = class_310.method_1551();
        return packedLight != null ? packedLight : minecraft.field_1769.method_23794(minecraft.field_1687, getBlockPos());
    }
    public T setRenderOffsetType(RenderOffsetType renderOffsetType) {
        this.renderOffsetType = renderOffsetType;
        return cast();
    }

    public T setARGB(float red, float green, float blue, float alpha) {
        colorStatic = new IColorSupplier.Simple(red, green, blue, alpha);
        return cast();
    }

    public T setARGB(IColorSupplier color) {
        colorStatic = color;
        return cast();
    }


    public T setLight(int packedLight){
        this.packedLight = packedLight;
        return cast();
    }


    public T transform(Consumer<class_4587> poseStackConsumer){
        this.poseStackConsumer = poseStackConsumer;
        return cast();
    }

    public T enableTimeFade(int fadeOutTicks) {
        if (fadeOutTicks <= ticksRemaining){
            this.fadeOutTicks = fadeOutTicks;
        } else {
            Constants.LOGGER.error("{} fadeOutTicks can't be larger than remaining ticks", this);
        }
        return cast();
    }

    public T enableDistanceFade(double maxDistance, double fadeStart) {
        if (maxDistance >= fadeStart){
            this.fadeDistanceAndStart = new Pair<>(maxDistance, fadeStart);
        } else {
            Constants.LOGGER.error("{} Fade cant start further from max maxDistance", this);
        }
        return cast();
    }

    @SuppressWarnings("unchecked")
    public T cast(){
        return (T) this;
    }
}
