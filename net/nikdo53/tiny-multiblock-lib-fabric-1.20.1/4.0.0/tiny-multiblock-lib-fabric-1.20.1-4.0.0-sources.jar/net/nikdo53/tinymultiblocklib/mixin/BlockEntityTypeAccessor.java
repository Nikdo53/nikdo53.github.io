package net.nikdo53.tinymultiblocklib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_2248;
import net.minecraft.class_2591;

@Mixin(class_2591.class)
public interface BlockEntityTypeAccessor {
    @Mutable
    @Accessor("validBlocks")
    void tinymultiblocklib$setValidBlocks(Set<class_2248> validBlocks);

    @Accessor("validBlocks")
    Set<class_2248> tinymultiblocklib$getValidBlocks();

}
