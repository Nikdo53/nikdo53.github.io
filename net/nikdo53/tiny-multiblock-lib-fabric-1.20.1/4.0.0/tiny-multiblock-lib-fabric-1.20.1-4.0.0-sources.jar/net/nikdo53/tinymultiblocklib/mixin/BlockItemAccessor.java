package net.nikdo53.tinymultiblocklib.mixin;

import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1747.class)
public interface BlockItemAccessor {
    @Invoker(value = "getPlacementState")
    @Nullable class_2680 tinyMultiblockLib$getPlacementState(final class_1750 context);
}
