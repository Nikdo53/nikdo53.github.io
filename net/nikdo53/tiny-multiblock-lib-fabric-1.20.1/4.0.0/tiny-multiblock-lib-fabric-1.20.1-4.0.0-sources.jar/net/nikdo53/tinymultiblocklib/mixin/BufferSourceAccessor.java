package net.nikdo53.tinymultiblocklib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_4597;

@Mixin(class_4597.class_4598.class)
public interface BufferSourceAccessor {

    @Accessor(value = "fixedBuffers")
    Map<class_1921, class_287> getFixedBuffers();

    @Accessor(value = "builder")
    class_287 getSharedBuffer();

}
