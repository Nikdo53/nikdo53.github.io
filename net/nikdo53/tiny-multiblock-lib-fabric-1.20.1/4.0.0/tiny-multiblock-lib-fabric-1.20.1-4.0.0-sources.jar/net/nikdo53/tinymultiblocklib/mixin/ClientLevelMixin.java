package net.nikdo53.tinymultiblocklib.mixin;

import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_761;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import net.nikdo53.tinymultiblocklib.client.FakeClientLevel;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Supplier;

@Mixin(class_638.class)
public class ClientLevelMixin {

    /**
     * Transfers destroyProgress to the center block
     * */
    @Inject(method = "destroyBlockProgress", at = @At(value = "HEAD"), cancellable = true)
    public void destroyBlockProgress(int breakerId, class_2338 pos, int progress, CallbackInfo ci) {
        class_638 level = tinyMultiblockLib$self();
        class_2680 blockState = level.method_8320(pos);

        if (IMultiBlock.isMultiblock(blockState) && !blockState.method_26217().equals(class_2464.field_11458)) {
            class_310.method_1551().field_1769.method_8569(breakerId, IMultiBlock.getCenter(level, pos), progress);
            ci.cancel();
        }
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void afterLoad(class_634 connection, class_638.class_5271 clientLevelData, class_5321 dimension, class_6880 dimensionType, int viewDistance, int serverSimulationDistance, Supplier profiler, class_761 levelRenderer, boolean isDebug, long biomeZoomSeed, CallbackInfo ci){
        if (!(tinyMultiblockLib$self() instanceof FakeClientLevel)) {
            FakeClientLevel.INSTANCE = new FakeClientLevel(tinyMultiblockLib$self());
        }
    }

    @Unique
    private @NotNull class_638 tinyMultiblockLib$self() {
        return (class_638) (Object) this;
    }
}
