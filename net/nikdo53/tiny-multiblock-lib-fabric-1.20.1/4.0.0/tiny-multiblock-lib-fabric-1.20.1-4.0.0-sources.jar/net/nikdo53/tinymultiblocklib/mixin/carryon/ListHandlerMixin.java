package net.nikdo53.tinymultiblocklib.mixin.carryon;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import tschipp.carryon.common.config.ListHandler;

import java.util.List;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

@Mixin(ListHandler.class)
public abstract class ListHandlerMixin {

    @Shadow(remap = false)
    private static List<class_6862<class_2248>> FORBIDDEN_TILES_TAGS;

    /**
     * Their Blacklist tags just don't work on certain versions, this hardcodes it to get at least 1 working
     * */
    @Inject(method = "initConfigLists", at = @At(value = "TAIL"), remap = false, require = 0)
    private static void initConfigLists(CallbackInfo ci) {
        class_6862<class_2248> tagKey = class_6862.method_40092(class_7923.field_41175.method_30517(), new class_2960("carryon:block_blacklist"));
        FORBIDDEN_TILES_TAGS.add(tagKey);
    }

}
