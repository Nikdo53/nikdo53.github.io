package net.nikdo53.tinymultiblocklib.platform.services;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import net.nikdo53.tinymultiblocklib.test.TestBlockItem;

import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public interface IRegistrationUtils {
    <T extends class_2586> Supplier<class_2591<T>> registerBlockEntity(String name, BiFunction<class_2338, class_2680, T> function, Set<class_2248> blocks);

    <T extends class_2248> Supplier<T> registerBlock(String name, Function<class_4970.class_2251, ? extends T> func, Supplier<class_4970.class_2251> properties);

    default <T extends class_2248> Supplier<T> registerBlockWithItem(String name, Function<class_4970.class_2251, ? extends T> func, Supplier<class_4970.class_2251> properties){
        Supplier<T> block = registerBlock(name, func, properties);
        registerBlockItem(name, block);
        return block;
    }

    default <T extends class_2248> void registerBlockItem(String name, Supplier<T> block){
        registerItem(name, (props) -> new TestBlockItem(block.get(), props), UnaryOperator.identity());
    }

    <T extends class_1792> Supplier<T> registerItem(String name, Function<class_1792.class_1793, T> func, UnaryOperator<class_1792.class_1793> properties);

    default <T extends class_1792> Supplier<T> registerItem(String name, Function<class_1792.class_1793, T> func){
       return registerItem(name, func, UnaryOperator.identity());
    }


    <T extends class_2586> void addSupportedBEBlock(Supplier<class_2591<T>> blockEntityType, class_2248 block);}
