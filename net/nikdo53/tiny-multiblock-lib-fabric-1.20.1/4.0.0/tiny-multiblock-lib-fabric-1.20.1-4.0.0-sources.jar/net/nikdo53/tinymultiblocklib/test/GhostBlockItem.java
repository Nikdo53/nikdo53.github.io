package net.nikdo53.tinymultiblocklib.test;

import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.nikdo53.nikdocolor.IColorSupplier;
import net.nikdo53.nikdocolor.NikdoColor;
import net.nikdo53.tinymultiblocklib.client.ghost.GhostBlockRenderer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;

public class GhostBlockItem extends class_1792 {
    public GhostBlockItem(class_1793 properties) {
        super(properties);
    }


    @Override
    public class_1269 method_7884(class_1838 context) {
        class_2338 pos = context.method_8037().method_10093(context.method_8038());

        new GhostBlockRenderer(pos, 100, class_2246.field_41072.method_9564())
                .setARGB(NikdoColor.fromHex(0x88FF11FF))
                .enableTimeFade(20)
                .addToRenderList();
        return class_1269.field_5812;
    }

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 level, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        tooltipComponents.add(class_2561.method_43470("This is an example item from TinyMultiblockLib").method_10862(class_2583.field_24360.method_10977(class_124.field_1061)));
        tooltipComponents.add(class_2561.method_43470("Some of its functions may be disabled outside dev env").method_10862(class_2583.field_24360.method_10977(class_124.field_1061)));

        super.method_7851(stack, level, tooltipComponents, tooltipFlag);
    }
}