package net.nikdo53.tinymultiblocklib.test;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2464;
import net.minecraft.class_247;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_7833;
import net.nikdo53.tinymultiblocklib.block.AbstractMultiBlock;
import net.nikdo53.tinymultiblocklib.block.IExpandingMultiblock;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import net.nikdo53.tinymultiblocklib.block.IPreviewableMultiblock;
import net.nikdo53.tinymultiblocklib.client.ghost.GhostBlockRenderer;
import net.nikdo53.tinymultiblocklib.components.SharedStatePropertiesBuilder;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import java.util.List;

public class TestBlock extends AbstractMultiBlock implements IPreviewableMultiblock, IExpandingMultiblock {
    public TestBlock(class_2251 properties) {
        super(properties);
    }
    public static final class_265 SHAPE = makeShape();

    @Override
    public @Nullable class_2753 getDirectionProperty() {
        return class_2383.field_11177;
    }

    @Override
    public void createSharedBlockStates(SharedStatePropertiesBuilder builder) {
        super.createSharedBlockStates(builder);
        builder.add(class_2741.field_12497);
    }

    @Override
    public List<class_2338> makeFullBlockShape(@NotNull class_1937 level, @NotNull class_2338 center, @NotNull class_2680 state, @org.jetbrains.annotations.Nullable class_2586 blockEntity, @org.jetbrains.annotations.Nullable class_2350 direction) {
        int size = 1;

        List<class_2338> list = IMultiBlock.posStreamToList(
                class_2338.method_20437(center.method_10079(class_2350.field_11043, size).method_10079(class_2350.field_11034, size), center.method_10086(size))
        );
        list.add(center.method_10076(3).method_10084());
        return list;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(class_2741.field_12497);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        int value = state.method_11654(class_2741.field_12497) + 1;
        if (value > 3) {
            value = 0;
        }

        new GhostBlockRenderer(pos.method_10084(), 100, class_2246.field_10219.method_9564())
                .enableDistanceFade(10, 5)
                .transform(poseStack -> poseStack.method_22907(class_7833.field_40714.rotationDegrees(45)))
                .addToRenderList();

        class_2350 direction = state.method_11654(class_2383.field_11177);

        moveMultiblock(level, pos, state, direction);

        return class_1269.field_5812;
    }

    @Override
    public class_2464 getMultiblockRenderShape(class_2680 state, boolean isCenter) {
        return class_2464.field_11458;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return class_259.method_1077();
       // return voxelShapeHelper(state, level, posEither, SHAPE, 0 , 0, 0, true);
    }

    public static class_265 makeShape(){
        class_265 shape = class_259.method_1073();
        shape = class_259.method_1072(shape, class_259.method_1081(-1, 0, 0, 1, 2, 2), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(-1.5, 0.75, 0.75, 1.5, 1.25, 1.25), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(-1, 0.75, 0.75, 2, 1.25, 1.25), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(-2, 0.75, 0.75, 1, 1.25, 1.25), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(-1.5, 0.75, 0.75, 1.5, 1.25, 1.25), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(-1.5, 1.5, 0.75, 1.5, 2, 1.25), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(-1.5, 0, 0.75, 1.5, 0.5, 1.25), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(-1.5, 0.75, 1.5, 1.5, 1.25, 2), class_247.field_1366);
        shape = class_259.method_1072(shape, class_259.method_1081(-1.5, 0.75, 0, 1.5, 1.25, 0.5), class_247.field_1366);

        return shape;
    }
}
