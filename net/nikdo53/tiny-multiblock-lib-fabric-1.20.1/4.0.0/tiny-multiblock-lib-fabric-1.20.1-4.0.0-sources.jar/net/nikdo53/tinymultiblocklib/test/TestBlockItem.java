package net.nikdo53.tinymultiblocklib.test;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2583;

public class TestBlockItem extends class_1747 {
    public TestBlockItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 level, List<class_2561> tooltipComponents, class_1836 flag) {
        tooltipComponents.add(class_2561.method_43470("This is an example block from TinyMultiblockLib").method_10862(class_2583.field_24360.method_10977(class_124.field_1061)));
        tooltipComponents.add(class_2561.method_43470("Some of its functions may be disabled outside dev env").method_10862(class_2583.field_24360.method_10977(class_124.field_1061)));
        super.method_7851(stack, level, tooltipComponents, flag);
    }
}
