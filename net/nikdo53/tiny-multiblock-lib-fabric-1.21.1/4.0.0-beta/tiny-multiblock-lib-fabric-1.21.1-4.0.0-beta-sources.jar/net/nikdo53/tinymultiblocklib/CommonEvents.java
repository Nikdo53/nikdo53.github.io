package net.nikdo53.tinymultiblocklib;

import net.nikdo53.tinymultiblocklib.util.BlockPatternUtils;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.nikdo53.tinymultiblocklib.components.Corner;
import net.nikdo53.tinymultiblocklib.test.DiamondStructureBlock;

public class CommonEvents {

    /**
     * Made as an example implementation of the diamond structure block, only runs in dev env!
     * <p>
     * Places a Diamond structure when right-clicking on a 2x2x2 cube of diamond blocks
     */
    public static void testRightClickBlock(class_1937 level, class_2338 pos, class_1657 player) {
        if (!level.method_8320(pos).method_27852(class_2246.field_10201)) return;

        BlockPatternUtils.findAndPlace(
                DiamondStructureBlock.getBlockPattern(),
                level,
                pos,
                CommonRegistration.BlockReg.DIAMOND_STRUCTURE_BLOCK.get().method_9564(),
                class_2338.field_10980,
                Corner.FORWARD_LOWER_LEFT);
    }
}
