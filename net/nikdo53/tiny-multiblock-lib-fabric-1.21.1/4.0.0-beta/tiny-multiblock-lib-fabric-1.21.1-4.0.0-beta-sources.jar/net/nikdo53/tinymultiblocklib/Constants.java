package net.nikdo53.tinymultiblocklib;

import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Constants {

	public static final String MOD_ID = "tinymultiblocklib";
	public static final String MOD_NAME = "Tiny MultiBlock Lib";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    public static class_2960 loc(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
}