package net.nikdo53.tinymultiblocklib;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3965;

public class FabricEvents {
    public static void register(){
        UseBlockCallback.EVENT.register(FabricEvents::testRightClickEvent);
    }

    public static class_1269 testRightClickEvent(class_1657 player, class_1937 level, class_1268 hand, class_3965 hitResult){
        CommonEvents.testRightClickBlock(level, hitResult.method_17777(), player);
        return class_1269.field_5811;
    }
}
