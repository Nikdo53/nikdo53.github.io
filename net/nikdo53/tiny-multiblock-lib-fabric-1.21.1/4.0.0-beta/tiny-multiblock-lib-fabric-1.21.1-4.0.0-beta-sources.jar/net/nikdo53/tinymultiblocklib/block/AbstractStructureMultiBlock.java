package net.nikdo53.tinymultiblocklib.block;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.nikdo53.tinymultiblocklib.CommonRegistration;
import net.nikdo53.tinymultiblocklib.blockentities.IStructureMultiBlockEntity;
import net.nikdo53.tinymultiblocklib.platform.Services;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractStructureMultiBlock extends AbstractMultiBlock {
    public AbstractStructureMultiBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    public void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        super.method_9615(state, level, pos, oldState, movedByPiston);

        if (!state.method_26204().equals(oldState.method_26204()) && level.method_8321(pos) instanceof IStructureMultiBlockEntity structureMBEntity) {
            structureMBEntity.setOldBlockState(oldState);
        }
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        if (!(level.method_8321(pos) instanceof IStructureMultiBlockEntity structureMBEntity)) {
            super.method_9536(state, level, pos, newState, movedByPiston);

            return;
        }

        class_2680 oldState = structureMBEntity.getOldBlockState();
        super.method_9536(state, level, pos, newState, movedByPiston);

        level.method_8501(pos, oldState);
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return CommonRegistration.BlockEntities.SIMPLE_STRUCTURE_MULTIBLOCK_ENTITY.get().method_11032(pos, state);
    }

    @Override
    protected void addToValidBEBlocks() {
        CommonRegistration.BlockEntities.VALID_BLOCKS_STRUCTURE.add(this);
        Services.PLATFORM.getRegistration().addSupportedBEBlock(CommonRegistration.BlockEntities.SIMPLE_STRUCTURE_MULTIBLOCK_ENTITY, this);

    }
}
