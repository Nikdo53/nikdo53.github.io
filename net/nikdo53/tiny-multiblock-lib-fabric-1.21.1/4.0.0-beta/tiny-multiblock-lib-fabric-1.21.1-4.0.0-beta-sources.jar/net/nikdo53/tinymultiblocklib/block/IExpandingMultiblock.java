package net.nikdo53.tinymultiblocklib.block;

import net.nikdo53.tinymultiblocklib.blockentities.IMultiBlockEntity;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.nikdo53.tinymultiblocklib.block.shape.MultiblockShape;
import org.jetbrains.annotations.Nullable;

import java.util.Set;

public interface IExpandingMultiblock extends IMultiBlock {

    @Override
    default void onPlaceHelper(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState) {
        boolean willChangeShape = IMultiBlock.isCenter(state) && IMultiBlock.isMultiblock(oldState) && hasShapeChanged(state, level, pos, oldState);
        if (tryChangeShape(state, level, pos, oldState, willChangeShape)) return;

        IMultiBlock.super.onPlaceHelper(state, level, pos, oldState);
    }

    default boolean tryChangeShape(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean willChangeShape) {
        if (willChangeShape) {
            if (canChangeShape(state, level, pos)) {

                changeShape(state, level, pos, oldState);
                postChangeShape(state, level, pos, oldState);

            } else {
                cancelChangeShape(state, level, pos, oldState);
            }
            return true;
        }
        return false;
    }


    @Override
    default class_2680 updateShapeHelper(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {

        if (!IMultiBlock.isMultiblock(neighborState) // avoid being activated by itself
                && level instanceof class_1937 level1
                && hasShapeChanged(state, level1, pos, state)) {
            if (!IMultiBlock.isCenter(state)) {

                // fakes the update shape even though the neighbors haven't updated
                class_2338 center = IMultiBlock.getCenter(level, pos);
                if (center.equals(pos)){
                    destroy(center, level, state, true);
                    return class_2246.field_10124.method_9564(); // The block has a broken state
                }

                class_2338 relative = center.method_10093(class_2350.field_11043);
                level.method_8320(center).method_26191(class_2350.field_11043, class_2246.field_10124.method_9564() ,level, center, relative);
            } else {
               if (tryChangeShape(state, level1, pos, state, true))
                   return state;
            }
        }

        return IMultiBlock.super.updateShapeHelper(state, direction, neighborState, level, pos, neighborPos);
    }


    //TODO: should the builder state change while placed?
    default boolean hasShapeChanged(class_2680 state, @Nullable class_1937 level, class_2338 pos, class_2680 oldState) {
        if (level == null) return false;

        class_2338 center = IMultiBlock.getCenter(level, pos);
        Set<class_2338> fullBlockShape = getFullBlockShape(level, center, oldState).getGlobalPositions();
        Set<class_2338> fullBlockShapeNoCache = getFullBlockShapeNoCache(level, level.method_8321(center), center, state).getGlobalPositions();
        return !fullBlockShape.equals(fullBlockShapeNoCache);
    }

    default void changeShape(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState) {
        if (level.method_8608()) return;
        class_2338 center = IMultiBlock.getCenter(level, pos);

        Set<class_2338> oldShape = getFullBlockShape(level, pos, oldState).getGlobalPositions();

        IMultiBlock.invalidateCaches(level, pos);

        Set<class_2338> shapeNew = getFullBlockShape(level, pos, state).getGlobalPositions();


        oldShape.forEach(posOld -> {
            IMultiBlockEntity.setPlaced(level, posOld, false);

            if (!shapeNew.contains(posOld)) {
                level.method_8544(posOld);
                level.method_8652(posOld, class_2246.field_10124.method_9564(), 2);
            }

        });

        place(level, center, state);
    }

    default boolean canChangeShape(class_2680 state, class_1937 level, class_2338 pos) {
        class_2338 center = IMultiBlock.getCenter(level, pos);

        MultiblockShape shape = getFullBlockShapeNoCache(level, level.method_8321(center), center, state);
        return shape.getGlobalPositions().stream().allMatch(posNew -> {
            class_2680 stateNew = level.method_8320(posNew);

            return (stateNew.method_45474() || IMultiBlock.isSameMultiblock(level, state, stateNew, center, posNew ))
                    && extraSurviveRequirements(level, posNew, state, posNew.method_10059(center), shape)
                    && (entityUnobstructed(level, posNew, state, null, shape));
        });
    }

    default void postChangeShape(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState) {
        getFullBlockShape(level, pos, state).getGlobalPositions().forEach(posNew -> IMultiBlockEntity.setPlaced(level, posNew, true));
    }

    default void cancelChangeShape(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState){
        level.method_8652(pos, oldState, 2);
    }

    private class_2248 self(){
        if (this instanceof class_2248 block){
            return block;
        } else {
            throw new RuntimeException(this.getClass().getSimpleName() + " is not implemented on a Block");
        }
    }

}
