package net.nikdo53.tinymultiblocklib.block;

import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.nikdo53.tinymultiblocklib.blockentities.IMultiBlockEntity;
import net.nikdo53.tinymultiblocklib.components.BlockLive;

import java.util.HashSet;
import java.util.Set;

public interface IMovableMultiblock extends IExpandingMultiblock {

    default void moveMultiblock(class_1937 level, class_2338 pos, class_2680 state, class_2350 direction){
        class_2338 center = IMultiBlock.getCenter(level, pos);
        class_2338 centerMoved = center.method_10093(direction);

        Set<class_2338> fullBlockShape = getFullBlockShape(level, center, state).getGlobalPositions();
        fullBlockShape.forEach(pos1 -> IMultiBlockEntity.setPlaced(level, pos1, false));

        Set<BlockLive> originalBlocks = new HashSet<>();
        fullBlockShape.forEach(pos1 -> originalBlocks.add(new BlockLive.Tag(level, pos1)));

        fullBlockShape.forEach(pos1 -> level.method_8652(pos1, class_2246.field_10124.method_9564(), 66));

        originalBlocks.forEach(blockLike -> blockLike.move(level, class_2338.field_10980.method_10093(direction)));


        getFullBlockShape(level, centerMoved, state).getGlobalPositions().forEach(pos1 -> IMultiBlockEntity.setPlaced(level, pos1, true));
    }

}
