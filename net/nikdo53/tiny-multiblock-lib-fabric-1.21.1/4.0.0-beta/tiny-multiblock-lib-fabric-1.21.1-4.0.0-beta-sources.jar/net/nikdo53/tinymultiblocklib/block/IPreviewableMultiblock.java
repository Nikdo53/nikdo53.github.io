package net.nikdo53.tinymultiblocklib.block;

import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.nikdo53.tinymultiblocklib.components.PreviewMode;

public interface IPreviewableMultiblock extends IMultiBlock {
    /**
     * Returns the default BlockState that will be used for previews
     * */
    default class_2680 getDefaultStateForPreviews(class_2350 direction) {
        class_2680 blockState = self().method_9564().method_11657(BaseMultiblock.CENTER, true);

        if (getDirectionProperty() == null) return blockState;
        return blockState.method_47968(getDirectionProperty(), direction);
    };

    private class_2248 self(){
        if (this instanceof class_2248 block){
            return block;
        } else {
            throw new RuntimeException(this.getClass().getSimpleName() + " is not implemented on a Block");
        }
    }
}
