package net.nikdo53.tinymultiblocklib.block;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_1941;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_9062;
import net.minecraft.world.level.*;
import net.nikdo53.tinymultiblocklib.CommonRegistration;
import net.nikdo53.tinymultiblocklib.block.logic.MultiblockLogic;
import net.nikdo53.tinymultiblocklib.block.shape.ShapeContext;
import net.nikdo53.tinymultiblocklib.blockentities.AbstractMultiBlockEntity;
import net.nikdo53.tinymultiblocklib.block.shape.MultiblockShape;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;

public abstract class LogicMultiblock extends BaseMultiblock implements IMovableMultiblock {
    public LogicMultiblock(class_2251 properties) {
        super(properties);
    }

    public MultiblockLogic getLogicForPos(class_1922 level, class_2338 pos, class_2680 state, @Nullable MultiblockShape shape){
        if (shape == null) {
            shape = getFullBlockShape(level, pos, state);
        }
        MultiblockShape.Entry entry = shape.getEntryForGlobalPos(pos);
        if (entry == null) {
            return MultiblockLogic.EMPTY;
        }
        return entry.logic();
    }

    public abstract MultiblockLogic getCenterLogic(ShapeContext context);


    @Override
    public MultiblockLogic getDefaultCenterLogic(ShapeContext context) {
        return getCenterLogic(context);
    }

    public MultiblockLogic getLogicForPos(class_1922 level, class_2338 pos, class_2680 state){
        return getLogicForPos(level, pos, state, null);
    }

    @Override
    public @Nullable AbstractMultiBlockEntity method_10123(class_2338 pos, class_2680 state) {
        return CommonRegistration.BlockEntities.SIMPLE_MULTIBLOCK_ENTITY.get().method_11032(pos, state);
    }

    //TMBL delegations (these do not use super since that's already a part of the logic)
    @Override
    public boolean canReplaceBlock(class_4538 level, class_2338 blockPos, class_2680 state, MultiblockShape shape) {
        return getLogicForPos(level, blockPos, state, shape).canReplaceBlock(level, blockPos, state, shape);
    }

    @Override
    public boolean entityUnobstructed(class_1941 level, class_2338 pos, class_2680 state, @Nullable class_1297 player, MultiblockShape shape) {
        return getLogicForPos(level, pos, state, shape).entityUnobstructed(level, pos, state, player, shape);
    }

    @Override
    public boolean extraSurviveRequirements(class_4538 level, class_2338 pos, class_2680 state, class_2338 centerOffset, MultiblockShape shape) {
        return getLogicForPos(level, pos, state, shape).extraSurviveRequirements(level, pos, state, centerOffset, shape);
    }


    //vanilla logic delegations:
    @Override
    protected void method_9517(class_2680 state, class_1936 level, class_2338 pos, int updateFlags, int updateLimit) {
        getLogicForPos(level, pos, state).method_9517(state, level, pos, updateFlags, updateLimit);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        class_2680 logicState = getLogicForPos(level, pos, state).method_9559(state, direction, neighborState, level, pos, neighborPos);
        return super.method_9559(logicState, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        super.method_9615(state, level, pos, oldState, movedByPiston);
        getLogicForPos(level, pos, state).method_9615(state, level, pos, oldState, movedByPiston);
    }

    @Override
    protected void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 neighborBlock, class_2338 neighborPos, boolean movedByPiston) {
        getLogicForPos(level, pos, state).method_9612(state, level, pos, neighborBlock, neighborPos, movedByPiston);
    }

    @Override
    protected void method_55124(class_2680 state, class_1937 level, class_2338 pos, class_1927 explosion, BiConsumer<class_1799, class_2338> dropConsumer) {
        getLogicForPos(level, pos, state).method_55124(state, level, pos, explosion, dropConsumer);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        return getLogicForPos(level, pos, state).method_55766(state, level, pos, player, hitResult);
    }

    @Override
    protected class_9062 method_55765(class_1799 itemStack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        return getLogicForPos(level, pos, state).method_55765(itemStack, state, level, pos, player, hand, hitResult);
    }

    @Override
    protected boolean method_9592(class_2680 state, class_1937 level, class_2338 pos, int b0, int b1) {
        return getLogicForPos(level, pos, state).method_9592(state, level, pos, b0, b1);
    }

    @Override
    protected @Nullable class_3908 method_17454(class_2680 state, class_1937 level, class_2338 pos) {
        return getLogicForPos(level, pos, state).method_17454(state, level, pos);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        return super.method_9558(state, level, pos) && getLogicForPos(level, pos, state).method_9558(state, level, pos);
    }

    @Override
    protected int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        return getLogicForPos(level, pos, state).method_9572(state, level, pos);
    }

    @Override
    protected void method_9565(class_2680 state, class_3218 level, class_2338 pos, class_1799 tool, boolean dropExperience) {
        getLogicForPos(level, pos, state).method_9565(state, level, pos, tool, dropExperience);
    }

    @Override
    protected void method_9606(class_2680 state, class_1937 level, class_2338 pos, class_1657 player) {
        getLogicForPos(level, pos, state).method_9606(state, level, pos, player);
    }

    @Override
    protected int method_9524(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return getLogicForPos(level, pos, state).method_9524(state, level, pos, direction);
    }

    @Override
    protected void method_9548(class_2680 state, class_1937 level, class_2338 pos, class_1297 entity) {
        getLogicForPos(level, pos, state).method_9548(state, level, pos, entity);
    }

    @Override
    protected int method_9603(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return getLogicForPos(level, pos, state).method_9603(state, level, pos, direction);
    }

    @Override
    protected void method_19286(class_1937 level, class_2680 state, class_3965 blockHit, class_1676 projectile) {
        getLogicForPos(level, blockHit.method_17777(), state).method_19286(level, state, blockHit, projectile);
    }
}

