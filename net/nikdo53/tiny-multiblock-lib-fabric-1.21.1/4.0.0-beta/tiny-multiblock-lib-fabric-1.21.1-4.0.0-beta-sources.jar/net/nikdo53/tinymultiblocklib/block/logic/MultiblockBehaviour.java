package net.nikdo53.tinymultiblocklib.block.logic;

import net.minecraft.class_1297;
import net.minecraft.class_1941;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.nikdo53.tinymultiblocklib.block.shape.MultiblockShape;
import org.jetbrains.annotations.Nullable;

public interface MultiblockBehaviour {
    /**
     * Extra requirements for the block to survive or be placed, runs for every single block in the multiblock
     * */
    default boolean extraSurviveRequirements(class_4538 level, class_2338 pos, class_2680 state, class_2338 centerOffset, MultiblockShape shape){
        return extraSurviveRequirements(level, pos, state, centerOffset);
    }

    @Deprecated
    default boolean extraSurviveRequirements(class_4538 level, class_2338 pos, class_2680 state, class_2338 centerOffset){
        return true;
    }

    default boolean entityUnobstructed(class_1941 level, class_2338 pos, class_2680 state, @Nullable class_1297 player, MultiblockShape shape) {
        class_3726 context = player == null ? class_3726.method_16194() : class_3726.method_16195(player);

        return level.method_8628(state, pos, context);
    }

    /**
     * Returns true if multiblock can replace this original block, runs for the whole multiblock shape
     * */
    default boolean canReplaceBlock(class_4538 level, class_2338 blockPos, class_2680 state, MultiblockShape shape) {
        return state.method_45474();
    }

}
