package net.nikdo53.tinymultiblocklib.block.logic;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import net.minecraft.class_9062;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.nikdo53.tinymultiblocklib.Constants;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.function.BiConsumer;

public class MultiblockLogic extends class_4970 implements MultiblockBehaviour {
    public static final MultiblockLogic EMPTY = new MultiblockLogic();

    public MultiblockLogic() {
        super(MultiblockLogic.Properties.method_9637());
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return null;
    }

    @Override
    public class_1792 method_8389() {
        return this.method_26160().method_8389();
    }

    @Override
    protected class_2248 method_26160() {
        Constants.LOGGER.warn("as block was called on a logic block, this is not supported, returning air instead");
        return class_2246.field_10124;
    }


    //Public land:
    @Override
    public void method_9517(class_2680 state, class_1936 level, class_2338 pos, int updateFlags, int updateLimit) {
        super.method_9517(state, level, pos, updateFlags, updateLimit);
    }

    @Override
    public void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        super.method_9536(state, level, pos, newState, movedByPiston);
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        super.method_9615(state, level, pos, oldState, movedByPiston);
    }

    @Override
    public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 neighborBlock, class_2338 neighborPos, boolean movedByPiston) {
        super.method_9612(state, level, pos, neighborBlock, neighborPos, movedByPiston);
    }

    @Override
    public void method_55124(class_2680 state, class_1937 level, class_2338 pos, class_1927 explosion, BiConsumer<class_1799, class_2338> dropConsumer) {
        super.method_55124(state, level, pos, explosion, dropConsumer);
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        return super.method_55766(state, level, pos, player, hitResult);
    }

    @Override
    public class_9062 method_55765(class_1799 itemStack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        return super.method_55765(itemStack, state, level, pos, player, hand, hitResult);
    }

    @Override
    public boolean method_9592(class_2680 state, class_1937 level, class_2338 pos, int b0, int b1) {
        return super.method_9592(state, level, pos, b0, b1);
    }

    @Override
    public boolean method_9616(class_2680 state, class_1750 context) {
        return super.method_9616(state, context);
    }

    @Override
    public @Nullable class_3908 method_17454(class_2680 state, class_1937 level, class_2338 pos) {
        return super.method_17454(state, level, pos);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        return super.method_9558(state, level, pos);
    }

    @Override
    public float method_9575(class_2680 state, class_1922 level, class_2338 pos) {
        return super.method_9575(state, level, pos);
    }

    @Override
    public int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        return super.method_9572(state, level, pos);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return super.method_9530(state, level, pos, context);
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return super.method_9549(state, level, pos, context);
    }

    @Override
    public void method_9548(class_2680 state, class_1937 level, class_2338 pos, class_1297 entity) {
        super.method_9548(state, level, pos, entity);
    }

    @Override
    public boolean method_37403(class_2680 state, class_1922 level, class_2338 pos) {
        return super.method_37403(state, level, pos);
    }

    @Override
    public class_265 method_26159(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return super.method_26159(state, level, pos, context);
    }

    @Override
    public void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        super.method_9514(state, level, pos, random);
    }

    @Override
    public void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        super.method_9588(state, level, pos, random);
    }

    @Override
    public float method_9594(class_2680 state, class_1657 player, class_1922 level, class_2338 pos) {
        return super.method_9594(state, player, level, pos);
    }

    @Override
    public void method_9565(class_2680 state, class_3218 level, class_2338 pos, class_1799 tool, boolean dropExperience) {
        super.method_9565(state, level, pos, tool, dropExperience);
    }

    @Override
    public void method_9606(class_2680 state, class_1937 level, class_2338 pos, class_1657 player) {
        super.method_9606(state, level, pos, player);
    }

    @Override
    public int method_9524(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return super.method_9524(state, level, pos, direction);
    }

    @Override
    public int method_9603(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return super.method_9603(state, level, pos, direction);
    }

    @Override
    public void method_19286(class_1937 level, class_2680 state, class_3965 blockHit, class_1676 projectile) {
        super.method_19286(level, state, blockHit, projectile);
    }

    @Override
    public int method_9505(class_2680 state, class_1922 level, class_2338 pos) {
        return super.method_9505(state, level, pos);
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 level, class_2338 pos) {
        return super.method_9579(state, level, pos);
    }


    public static class Properties extends class_4970.class_2251 {
        public Properties() {
            super();
        }

        public static Properties method_9637() {
            return new Properties();
        }
    }
}
