package net.nikdo53.tinymultiblocklib.block.shape;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_6328;
import net.nikdo53.tinymultiblocklib.Constants;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;


@class_6328
public class ShapeContext {
    protected final class_1937 level;
    protected final @Nullable class_2586 blockEntity;
    protected final class_2680 blockState;
    protected final class_2338 centerPos;
    protected final IMultiBlock multiBlock;

    // these might be used for performance optimization later on
    boolean usesStateContext = false;
    boolean usesLevelContext = false;

    public ShapeContext(@Nullable class_1937 level, class_2338 centerPos, class_2680 blockState, @Nullable class_2586 blockEntity, IMultiBlock multiBlock) {
        this.level = level;
        this.blockEntity = blockEntity;
        this.blockState = blockState;
        this.centerPos = centerPos;
        this.multiBlock = multiBlock;
    }

    public class_1937 getLevel() {
        if (getOldProperties() != null && !getOldProperties().usesLevelContext){
            logPropertiesChange();
        }
        usesLevelContext = true;
        return level;
    }

    private static void logPropertiesChange() {
        Constants.LOGGER.error("Shape properties changed unexpectedly, please include any getters from the context at the top of the makeMultiblockShape method. This might throw in future versions");
    }

    public @Nullable class_2586 getBlockEntity() {
        if (getOldProperties() != null && !getOldProperties().usesLevelContext){
            logPropertiesChange();
        }
        usesLevelContext = true;
        return blockEntity;
    }

    public class_2680 getBlockState() {
        if (getOldProperties() != null && !getOldProperties().usesStateContext){
            logPropertiesChange();
        }
        usesStateContext = true;
        return blockState;
    }

    public class_2338 getCenterPos() {
        return centerPos;
    }

    public class_2350 getDirection() {
        if (multiBlock.getDirectionProperty() == null) {
            throw new IllegalStateException("Multiblock does not have a direction property");
        }
        return Objects.requireNonNull(multiBlock.getDirection(getBlockState()));
    }

    protected ShapeContext.@Nullable Properties getOldProperties(){
        return multiBlock.getShapeProperties();
    }

    @ApiStatus.Internal
    public Properties getProperties() {
        return new Properties(usesStateContext, usesLevelContext);
    }


    public record Properties(boolean usesStateContext, boolean usesLevelContext){

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof Properties that)) return false;
            return usesStateContext == that.usesStateContext && usesLevelContext == that.usesLevelContext;
        }
    }
}
