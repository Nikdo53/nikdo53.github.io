package net.nikdo53.tinymultiblocklib.block.shape;

import java.util.function.UnaryOperator;
import net.minecraft.class_265;
import net.minecraft.class_2680;

public record ShapeDataKey<T>(String key) {
    public static final ShapeDataKey<class_2680> BLOCK_STATE = new ShapeDataKey<>("block_state");
    public static final ShapeDataKey<class_265> VOXEL_SHAPE = new ShapeDataKey<>("voxel_shape");
    public static final ShapeDataKey<Boolean> STANDALONE_VOXEL_SHAPE = new ShapeDataKey<>("standalone_voxel_shape");

    public record Pair<T>(ShapeDataKey<T> key, T value) { }

    public record Operation<T>(ShapeDataKey<T> key, UnaryOperator<T> operation) { }
}
