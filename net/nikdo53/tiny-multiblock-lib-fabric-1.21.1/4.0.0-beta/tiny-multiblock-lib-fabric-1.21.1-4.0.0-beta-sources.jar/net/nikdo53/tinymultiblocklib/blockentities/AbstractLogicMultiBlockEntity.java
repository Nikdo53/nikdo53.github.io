package net.nikdo53.tinymultiblocklib.blockentities;

import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.nikdo53.tinymultiblocklib.block.logic.MultiblockLogic;

import java.util.Map;

public class AbstractLogicMultiBlockEntity extends AbstractMultiBlockEntity{
    public AbstractLogicMultiBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }
    private Map<class_2338, MultiblockLogic> logicShapeCache = Map.of();

    @Override
    public void invalidateCaches() {
        super.invalidateCaches();
        logicShapeCache.clear();
    }

    public Map<class_2338, MultiblockLogic> getLogicShapeCache() {
        return logicShapeCache;
    }

    public void setLogicShapeCache(Map<class_2338, MultiblockLogic> logicShapeCache) {
        this.logicShapeCache = logicShapeCache;
    }
}
