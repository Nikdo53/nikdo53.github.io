package net.nikdo53.tinymultiblocklib.blockentities;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import net.nikdo53.tinymultiblocklib.components.BlockLive;

public class AbstractStructureMultiBlockEntity extends AbstractMultiBlockEntity implements IStructureMultiBlockEntity{
    private class_2680 oldBlockState = class_2246.field_10124.method_9564();

    public AbstractStructureMultiBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    @Override
    public class_2680 getOldBlockState() {
        return oldBlockState;
    }

    @Override
    public void setOldBlockState(class_2680 blockState) {
        oldBlockState = blockState;
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        if (oldBlockState != null) tag.method_10566("blockState", class_2512.method_10686(oldBlockState));
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        oldBlockState = class_2512.method_10681(BlockLive.getBlockGetter(method_10997()), tag.method_10562("blockState"));
    }
}
