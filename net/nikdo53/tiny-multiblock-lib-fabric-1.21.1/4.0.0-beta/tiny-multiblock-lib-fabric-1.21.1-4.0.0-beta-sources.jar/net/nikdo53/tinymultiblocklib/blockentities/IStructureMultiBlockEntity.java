package net.nikdo53.tinymultiblocklib.blockentities;

import net.minecraft.class_2680;

public interface IStructureMultiBlockEntity extends IMultiBlockEntity {
    class_2680 getOldBlockState();
    void setOldBlockState(class_2680 blockState);
}
