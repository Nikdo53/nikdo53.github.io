package net.nikdo53.tinymultiblocklib.blockentities;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.nikdo53.tinymultiblocklib.CommonRegistration;

public class SimpleMultiBlockEntity extends AbstractMultiBlockEntity {
    public SimpleMultiBlockEntity(class_2338 pos, class_2680 state) {
        super(CommonRegistration.BlockEntities.SIMPLE_MULTIBLOCK_ENTITY.get(), pos, state);
    }
}
