package net.nikdo53.tinymultiblocklib.blockentities;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.nikdo53.tinymultiblocklib.CommonRegistration;

public class SimpleStructureMultiBlockEntity extends AbstractStructureMultiBlockEntity{
    public SimpleStructureMultiBlockEntity(class_2338 pos, class_2680 state) {
        super(CommonRegistration.BlockEntities.SIMPLE_STRUCTURE_MULTIBLOCK_ENTITY.get(), pos, state);
    }
}
