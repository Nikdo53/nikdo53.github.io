package net.nikdo53.tinymultiblocklib.client;

import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1841;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3726;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_776;
import net.minecraft.class_827;
import net.minecraft.client.renderer.*;
import net.nikdo53.tinymultiblocklib.Constants;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import net.nikdo53.tinymultiblocklib.blockentities.IMultiBlockEntity;
import net.nikdo53.tinymultiblocklib.block.IPreviewableMultiblock;
import net.nikdo53.tinymultiblocklib.compat.carryon.CarryOnPreviewHelper;
import net.nikdo53.tinymultiblocklib.components.BlockLive;
import net.nikdo53.tinymultiblocklib.components.PreviewMode;
import net.nikdo53.tinymultiblocklib.block.shape.MultiblockShape;
import net.nikdo53.tinymultiblocklib.data.TMBLTags;
import net.nikdo53.tinymultiblocklib.mixin.ItemAccessor;
import net.nikdo53.tinymultiblocklib.platform.Services;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

public class MultiblockPreviewRenderer {
    public static final Set<class_2248> PREVIEW_BLACKLIST = new HashSet<>();
    public static final Set<class_2248> SET_PLACED_BY_BLACKLIST = new HashSet<>();

    public static void tryRenderMultiblockPreviews(float partialTick, class_4184 camera, class_4587 poseStack) {
        //funny passthrough cuz im not restructuring this whole thing
        AtomicReference<@Nullable class_2248> blockReference = new AtomicReference<>();

        try {
            renderMultiblockPreviews(partialTick, camera, poseStack, blockReference);
        } catch (Exception e) {
            class_2248 block = blockReference.get();
            if (block != null) {
                PREVIEW_BLACKLIST.add(block);
                Constants.LOGGER.error("Error rendering multiblock preview: " + e.getMessage() + " adding " + block + " to blacklist to prevent further errors", e);
            } else {
                Constants.LOGGER.error("Error rendering multiblock preview: " + e.getMessage() + " this should never happen unless its carryons fault ig", e);
            }

        }
    }

    public static void renderMultiblockPreviews(float partialTick, class_4184 camera, class_4587 poseStack, AtomicReference<@Nullable class_2248> blockReference) {
        class_310 minecraft = class_310.method_1551();
        class_746 player = minecraft.field_1724;
        class_638 level = minecraft.field_1687;

        if (player == null || level == null) return;

        class_1799 stack = player.method_6047();
        class_1792 item = stack.method_7909();

        double camX = camera.method_19326().field_1352;
        double camY = camera.method_19326().field_1351;
        double camZ = camera.method_19326().field_1350;

        if (Services.PLATFORM.isModLoaded("carryon")) {
           if (CarryOnPreviewHelper.isValidMultiblock(player)) item = CarryOnPreviewHelper.getMultiblockItem(player);
        }

        if (item instanceof class_1747 blockItem) {

            if (!(minecraft.field_1765 instanceof class_3965 blockHitResult)) return;

            boolean placeOnWater = false;

            if (blockItem instanceof class_1841) {
                blockHitResult = ItemAccessor.getPlayerPOVHitResult(level, player, class_3959.class_242.field_1345);
                placeOnWater = level.method_22351(blockHitResult.method_17777());
            }

            class_2350 hitDirection = blockHitResult.method_17780();
            class_2248 block = blockItem.method_7711();

            blockReference.set(block);
            class_2338 hitPos = blockHitResult.method_17777();
            class_2338 pos = hitPos.method_10093(hitDirection);

            // ⬇️⬇️ the line that disables previewing of everything
             if (!(stack.method_31573(TMBLTags.ItemTags.SHOW_PREVIEW) || block instanceof IPreviewableMultiblock) || PREVIEW_BLACKLIST.contains(block)) return;

            class_2680 state = block.method_9605(new class_1750(player, class_1268.field_5808, stack, blockHitResult));
            boolean hasNullState = false;

            if (state == null){
                hasNullState = true;
                state = block.method_9564();

                if (block instanceof IPreviewableMultiblock multiblock){
                    state = multiblock.getDefaultStateForPreviews(player.method_5735());
                }

                if (block instanceof IMultiBlock multiBlock && multiBlock.makeDirectional() != null){
                    IMultiBlock.DirectionContext directionContext = multiBlock.makeDirectional();
                    assert directionContext != null;
                    class_2350 dir = directionContext.directionExtractor().apply(new class_1750(player, class_1268.field_5808, stack, blockHitResult));

                    if (dir != null) {
                        state = state.method_11657(directionContext.property(), dir);
                    }
                }
            }

            class_2586 blockEntity = block instanceof class_2343 entityBlock ? entityBlock.method_10123(pos, state) : null;
            if (blockEntity != null) {
                blockEntity.method_31662(level);
            }

            PreviewMode previewMode = getPreviewMode(level, pos, state, player, blockEntity, hasNullState);

            boolean shouldShowPreview = level.method_8320(pos).method_45474()
                    && (!level.method_8320(hitPos).method_26215() || placeOnWater);

            if (level.method_8320(hitPos).method_45474() && !placeOnWater)
                pos = pos.method_10093(hitDirection.method_10153());

            poseStack.method_22903();

            poseStack.method_22904(pos.method_10263() - camX, pos.method_10264() - camY, pos.method_10260() - camZ);

            FakeClientLevel fakeLevel = FakeClientLevel.getOrThrow();
            Set<BlockLive> blockLiveSet = gatherBlockLives(fakeLevel, level, blockEntity, pos, state, minecraft.field_1724, stack);

            BlockLive centerLive = BlockLive.Live.optionalBE(pos, state, blockEntity);
            IOnBlockPreviewEvent event = IOnBlockPreviewEvent.firePreEvent(previewMode, !shouldShowPreview, centerLive, blockLiveSet);

            if (!event.isCancelledInternal()) {
                blockLiveSet = event.getBlocksForPreview();
                fakeLevel.blockLiveSet = blockLiveSet;
                previewMode = event.getPreviewMode();

                TintedBufferSource bufferSource = new TintedBufferSource(minecraft.method_22940().method_23000(), previewMode);

                for (BlockLive blockLive : blockLiveSet) {
                    renderJsonModels(blockLive, pos, poseStack, fakeLevel, minecraft, bufferSource);
                }

                for (BlockLive blockLive : blockLiveSet) {
                    renderBlockEntity(blockLive, pos, poseStack, partialTick, bufferSource, minecraft, fakeLevel);
                }

                IOnBlockPreviewEvent.firePostEvent(previewMode, centerLive, blockLiveSet, poseStack, partialTick, bufferSource);

            }

            poseStack.method_22909();

        }
    }

    private static void renderBlockEntity(BlockLive blockLive, class_2338 originalPos, class_4587 poseStack, float partialTick, class_4597.class_4598 buffer, class_310 minecraft, FakeClientLevel fakeClientLevel) {
        class_2680 state = blockLive.state;
        class_2338 pos = blockLive.pos;

        if (state.method_26204() instanceof class_2343 entityBlock) {

            class_2586 entity = entityBlock.method_10123(pos, state);
            if (entity == null) return;
            entity.method_31662(fakeClientLevel);

            if (entity instanceof IMultiBlockEntity multiBlockEntity) {
                multiBlockEntity.setCenter(originalPos);
            }

            class_827<class_2586> entityRender = minecraft.method_31975().method_3550(entity);

            if (entityRender != null) {
                poseStack.method_22903();
                poseStack.method_22904(0.0001, 0.0001, 0.0001);

                class_2338 offset = blockLive.pos.method_10059(originalPos).method_10062();
                poseStack.method_46416(offset.method_10263(), offset.method_10264(), offset.method_10260());

                entityRender.method_3569(entity, partialTick, poseStack, buffer, 0xFFFFFF, class_4608.field_21444);

                poseStack.method_22909();

            }
        }
    }

    private static PreviewMode getPreviewMode(class_1937 level, class_2338 pos, class_2680 state, class_746 player, @Nullable class_2586 blockEntity, boolean hasNullState) {
        if (hasNullState) return PreviewMode.INVALID;

        IMultiBlock multiBlock = null;
        MultiblockShape shape = null;
        if (state.method_26204() instanceof IMultiBlock mb) {
            multiBlock = mb;
            shape = mb.getFullBlockShapeNoCache(level, blockEntity, pos, state);
        }


        boolean multiBlockCanPlace = canPlace(level, pos, state, player, shape, multiBlock);
        boolean entityUnobstructed = isEntityUnobstructed(level, pos, state, player, shape, multiBlock);

        return multiBlockCanPlace ? (entityUnobstructed ? PreviewMode.PREVIEW : PreviewMode.ENTITY_BLOCKED) : PreviewMode.INVALID;
    }

    private static boolean isEntityUnobstructed(class_1937 level, class_2338 pos, class_2680 state, class_746 player, @Nullable MultiblockShape shape, @Nullable IMultiBlock multiBlock) {
        if (shape != null && multiBlock != null)
            return multiBlock.entityUnobstructed(level, pos, state, player, shape);

        return level.method_8628(state, pos, class_3726.method_16195(player));
    }

    private static boolean canPlace(class_1937 level, class_2338 pos, class_2680 state, class_746 player, @Nullable MultiblockShape shape, @Nullable IMultiBlock multiBlock) {
        if (shape != null && multiBlock != null)
            return multiBlock.canPlaceBlock(pos, level, pos, state,player, true, shape);

        return state.method_26184(level, pos);
    }

    public static void renderJsonModels(BlockLive blockLive, class_2338 originalPos, class_4587 poseStack, class_1937 fakeLevel, class_310 minecraft, TintedBufferSource bufferSource) {

        if (!blockLive.state.method_26217().equals(class_2464.field_11458)) return;

        class_776 blockRenderer = minecraft.method_1541();
        poseStack.method_22903();
        poseStack.method_22904(0.0001, 0.0001, 0.0001);

        class_2338 offset = blockLive.pos.method_10059(originalPos).method_10062();
        poseStack.method_46416(offset.method_10263(), offset.method_10264(), offset.method_10260());

        RenderUtils.CHECK_SIDES_CONTEXT = new RenderUtils.CheckSidesContext(fakeLevel, blockLive.state, blockLive.pos);
        blockRenderer.method_3353(blockLive.state, poseStack, bufferSource, 0xFFFFFF, class_4608.field_21444);
        RenderUtils.CHECK_SIDES_CONTEXT = null;

        poseStack.method_22909();
    }

    public static Set<BlockLive> gatherBlockLives(FakeClientLevel fakeLevel, class_1937 level, class_2586 blockEntity, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack) {
        Set<BlockLive> blockLiveSet = new HashSet<>();
        class_2248 block = state.method_26204();

        if (block instanceof IMultiBlock multiBlock) {
            blockLiveSet.addAll(multiBlock.prepareForPlace(multiBlock.getFullBlockShapeNoCache(level, blockEntity, pos, state), level, pos, state));
        } else {
            blockLiveSet.add(new BlockLive.Live(pos, state, blockEntity));
        }

        if (!SET_PLACED_BY_BLACKLIST.contains(block)) {
            try {
                block.method_9567(fakeLevel, pos, state, placer, stack);
            } catch (Exception ignored) {
                Constants.LOGGER.warn("setPlacedBy failed for block " + block + "adding to ignore list.");
                SET_PLACED_BY_BLACKLIST.add(block);
            }
        }

        blockLiveSet.addAll(fakeLevel.blockLiveSet);

        return blockLiveSet;
    }
}
