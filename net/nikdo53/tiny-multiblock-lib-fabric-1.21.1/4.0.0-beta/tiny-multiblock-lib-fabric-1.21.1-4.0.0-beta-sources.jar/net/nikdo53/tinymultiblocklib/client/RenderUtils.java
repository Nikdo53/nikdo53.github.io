package net.nikdo53.tinymultiblocklib.client;

import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_765;
import org.jetbrains.annotations.Nullable;

public class RenderUtils {
    /**
     * Used to pass side checking (like in BlockRenderDispatcher#renderBatched) into renderSingleBlock,
     * as the former doesn't work with iris for some reason
     */
    public static @Nullable CheckSidesContext CHECK_SIDES_CONTEXT = null;

    public static int getPackedLight(class_1937 level, class_2338 blockPos) {
        return class_765.method_23687(level.method_8314(class_1944.field_9282, blockPos), level.method_8314(class_1944.field_9284, blockPos));
    }


    public record CheckSidesContext(class_1937 level, class_2680 state, class_2338 pos) {
    }
}
