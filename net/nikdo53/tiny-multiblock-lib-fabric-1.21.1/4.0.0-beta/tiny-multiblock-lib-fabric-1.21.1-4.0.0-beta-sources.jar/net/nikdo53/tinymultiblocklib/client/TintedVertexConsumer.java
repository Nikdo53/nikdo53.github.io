package net.nikdo53.tinymultiblocklib.client;

import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_777;
import net.nikdo53.nikdocolor.IColorSupplier;

public class TintedVertexConsumer extends VertexConsumerWrapper {
    public IColorSupplier colorSupplier;

    public TintedVertexConsumer(class_4588 parent, IColorSupplier colorSupplier) {
        super(parent);
        this.colorSupplier = colorSupplier;
    }


    @Override
    public void method_22920(class_4587.class_4665 pose, class_777 quad, float[] brightness, float red, float green, float blue, float alpha, int[] lightmap, int packedOverlay, boolean readAlpha) {
        parent.method_22920(pose, quad, brightness, red * colorSupplier.getRed(), green * colorSupplier.getGreen(), blue * colorSupplier.getBlue(), alpha * colorSupplier.getAlpha(), lightmap, packedOverlay, readAlpha);
    }

    @Override
    public void method_22919(class_4587.class_4665 pose, class_777 quad, float red, float green, float blue, float alpha, int packedLight, int packedOverlay) {
        parent.method_22919(pose, quad, red * colorSupplier.getRed(), green * colorSupplier.getGreen(), blue * colorSupplier.getBlue(), alpha * colorSupplier.getAlpha(), packedLight, packedOverlay);
    }

    @Override
    public void method_23919(float x, float y, float z, int color, float u, float v, int packedOverlay, int packedLight, float normalX, float normalY, float normalZ) {
        parent.method_23919(x, y, z, colorSupplier.applyColors(color), u, v, packedOverlay, packedLight, normalX, normalY, normalZ);
    }

    @Override
    public class_4588 method_1336(int r, int g, int b, int a) {
        return parent.method_22915(r * colorSupplier.getRed(), g * colorSupplier.getGreen(), b * colorSupplier.getBlue(), a * colorSupplier.getAlpha());
    }

    @Override
    public class_4588 method_22915(float red, float green, float blue, float alpha) {
        return parent.method_22915(red * colorSupplier.getRed(), green * colorSupplier.getGreen(), blue * colorSupplier.getBlue(), alpha * colorSupplier.getAlpha());
    }

    @Override
    public class_4588 method_39415(int color) {
        return parent.method_39415(colorSupplier.applyColors(color));
    }
}
