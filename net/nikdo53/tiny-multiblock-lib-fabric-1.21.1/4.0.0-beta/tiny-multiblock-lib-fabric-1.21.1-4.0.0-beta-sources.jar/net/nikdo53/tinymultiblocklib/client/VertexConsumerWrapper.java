package net.nikdo53.tinymultiblocklib.client;

import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_777;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public abstract class VertexConsumerWrapper implements class_4588{
    protected final class_4588 parent;

    public VertexConsumerWrapper(class_4588 parent) {
        this.parent = parent;
    }

    @Override
    public class_4588 method_60831(class_4587.class_4665 pose, float normalX, float normalY, float normalZ) {
        parent.method_60831(pose, normalX, normalY, normalZ);
        return this;

    }

    @Override
    public class_4588 method_22918(Matrix4f pose, float x, float y, float z) {
        parent.method_22918(pose, x, y, z);
        return this;
    }

    @Override
    public class_4588 method_56824(class_4587.class_4665 pose, float x, float y, float z) {
        parent.method_56824(pose, x, y, z);
        return this;
    }

    @Override
    public class_4588 method_61032(class_4587.class_4665 pose, Vector3f pos) {
        parent.method_61032(pose, pos);
        return this;
    }

    @Override
    public class_4588 method_60830(Vector3f pos) {
        parent.method_60830(pos);
        return this;
    }

    @Override
    public void method_22920(class_4587.class_4665 pose, class_777 quad, float[] brightness, float red, float green, float blue, float alpha, int[] lightmap, int packedOverlay, boolean readAlpha) {
        parent.method_22920(pose, quad, brightness, red, green, blue, alpha, lightmap, packedOverlay, readAlpha);
    }

    @Override
    public void method_22919(class_4587.class_4665 pose, class_777 quad, float red, float green, float blue, float alpha, int packedLight, int packedOverlay) {
        parent.method_22919(pose, quad, red, green, blue, alpha, packedLight, packedOverlay);
    }

    @Override
    public class_4588 method_22922(int packedOverlay) {
        parent.method_22922(packedOverlay);
        return this;

    }

    @Override
    public class_4588 method_60803(int packedLight) {
        parent.method_60803(packedLight);
        return this;
    }

    @Override
    public class_4588 method_60832(int alpha) {
        parent.method_60832(alpha);
        return this;

    }

    @Override
    public class_4588 method_39415(int color) {
        parent.method_39415(color);
        return this;

    }

    @Override
    public class_4588 method_22915(float red, float green, float blue, float alpha) {
        parent.method_22915(red, green, blue, alpha);
        return this;
    }

    @Override
    public void method_23919(float x, float y, float z, int color, float u, float v, int packedOverlay, int packedLight, float normalX, float normalY, float normalZ) {
        parent.method_23919(x, y, z, color,  u, v, packedOverlay, packedLight, normalX, normalY, normalZ);
    }

    @Override
    public class_4588 method_22912(float x, float y, float z) {
        this.parent.method_22912(x, y, z);
        return this;
    }

    @Override
    public class_4588 method_1336(int r, int g, int b, int a) {
        this.parent.method_1336(r, g, b, a);
        return this;
    }

    @Override
    public class_4588 method_22913(float u, float v) {
        this.parent.method_22913(u, v);
        return this;
    }

    @Override
    public class_4588 method_60796(int u, int v) {
        this.parent.method_60796(u, v);
        return this;
    }

    @Override
    public class_4588 method_22921(int u, int v) {
        this.parent.method_22921(u, v);
        return this;
    }

    @Override
    public class_4588 method_22914(float x, float y, float z) {
        this.parent.method_22914(x, y, z);
        return this;
    }


}
