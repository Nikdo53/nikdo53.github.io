package net.nikdo53.tinymultiblocklib.compat.carryon;

import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import tschipp.carryon.common.carry.CarryOnData;
import tschipp.carryon.common.carry.CarryOnDataManager;

public class CarryOnPreviewHelper {

    public static boolean isValidMultiblock(class_1657 player){
        CarryOnData carry = CarryOnDataManager.getCarryData(player);
        if (carry.isCarrying(CarryOnData.CarryType.BLOCK)){
           return IMultiBlock.isMultiblock(carry.getBlock());
        };
        return false;
    }

    public static class_1792 getMultiblockItem(class_1657 player){
        CarryOnData carry = CarryOnDataManager.getCarryData(player);
        return carry.getBlock().method_26204().method_8389();
    }
}
