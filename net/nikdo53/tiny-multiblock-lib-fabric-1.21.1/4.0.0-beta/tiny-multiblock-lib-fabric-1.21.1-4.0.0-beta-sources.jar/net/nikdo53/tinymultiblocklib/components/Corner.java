package net.nikdo53.tinymultiblocklib.components;

import net.minecraft.class_2350;

/**
 * Contains all corners of a cube
 */
public enum Corner {
    FORWARD_LOWER_LEFT(class_2350.field_11039, class_2350.field_11033, class_2350.field_11035),
    FORWARD_LOWER_RIGHT(class_2350.field_11034, class_2350.field_11033, class_2350.field_11035),
    FORWARD_UPPER_LEFT(class_2350.field_11039, class_2350.field_11036, class_2350.field_11035),
    FORWARD_UPPER_RIGHT(class_2350.field_11034, class_2350.field_11036, class_2350.field_11035),

    BACK_LOWER_LEFT(class_2350.field_11039, class_2350.field_11033, class_2350.field_11043),
    BACK_LOWER_RIGHT(class_2350.field_11034, class_2350.field_11033, class_2350.field_11043),
    BACK_UPPER_LEFT(class_2350.field_11039, class_2350.field_11036, class_2350.field_11043),
    BACK_UPPER_RIGHT(class_2350.field_11034, class_2350.field_11036, class_2350.field_11043);

    public final class_2350 x;
    public final class_2350 y;
    public final class_2350 z;

    Corner(class_2350 xDirection, class_2350 yDirection, class_2350 zDirection){
        this.x = xDirection;
        this.y = yDirection;
        this.z = zDirection;
    }

}
