package net.nikdo53.tinymultiblocklib.components;

import net.minecraft.class_2680;
import net.minecraft.class_2769;

public final class PropertyWrapper<T extends Comparable<T>> {
    public final class_2769<T> property;
    public T value;

    public PropertyWrapper(class_2769<T> property) {
        this.property = property;
        this.value = null;
    }

    public PropertyWrapper(class_2769<T> property, T value) {
        this.property = property;
        this.value = value;
    }

    public static <T extends Comparable<T>> PropertyWrapper<?> addProperty(class_2769<T> property){
        return new PropertyWrapper<>(property);
    }

    public class_2680 applyTo(class_2680 state) {
        return state.method_47968(property, value);
    }

    public void captureValue(class_2680 state) {
        this.value = state.method_11654(property);
    }

}