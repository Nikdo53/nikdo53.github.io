package net.nikdo53.tinymultiblocklib.components;

import net.minecraft.class_4587;

public enum RenderOffsetType {
    NONE(0f, 1f, 0f),
    OFFSET(0.001f, 1f, 0f),
    SCALED(0.001f, 1.002f, 0f),
    CROSS(0.001f, 1f, 0.001f);

    public final float offset;
    public final float scale;
    public final float xOffset;

    RenderOffsetType(float offset, float scale, float xOffset){
        this.offset = offset;
        this.scale = scale;
        this.xOffset = xOffset;
    }

    public void applyTransforms(class_4587 poseStack){
        if (this.equals(NONE)) return;

        poseStack.method_46416(-offset, -offset, -offset);
        poseStack.method_46416(-xOffset, 0f, 0f);
        poseStack.method_22905(scale, scale, scale);
    }
}
