package net.nikdo53.tinymultiblocklib.data;

import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.nikdo53.tinymultiblocklib.Constants;

public class TMBLTags {
    public static class BlockTags {

    }

    public static class ItemTags {
        public static final class_6862<class_1792> SHOW_PREVIEW = tag("show_preview");


        private static class_6862<class_1792> tag(String name) {
            return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(Constants.MOD_ID, name));
        }
    }
}
