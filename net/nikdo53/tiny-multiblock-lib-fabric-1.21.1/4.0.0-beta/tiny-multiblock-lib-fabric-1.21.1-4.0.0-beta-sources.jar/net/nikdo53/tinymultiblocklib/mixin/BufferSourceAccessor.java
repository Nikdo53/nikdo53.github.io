package net.nikdo53.tinymultiblocklib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.HashMap;
import java.util.Map;
import java.util.SequencedMap;
import net.minecraft.class_1921;
import net.minecraft.class_4597;
import net.minecraft.class_9799;

@Mixin(class_4597.class_4598.class)
public interface BufferSourceAccessor {

    @Accessor(value = "fixedBuffers")
    SequencedMap<class_1921, class_9799> getFixedBuffers();

    @Accessor(value = "sharedBuffer")
    class_9799 getSharedBuffer();

}
