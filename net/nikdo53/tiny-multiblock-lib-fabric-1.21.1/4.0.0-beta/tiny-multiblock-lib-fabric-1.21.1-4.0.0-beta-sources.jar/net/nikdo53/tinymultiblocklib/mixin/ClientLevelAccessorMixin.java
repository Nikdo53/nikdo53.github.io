package net.nikdo53.tinymultiblocklib.mixin;

import net.minecraft.class_634;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_638.class)
public interface ClientLevelAccessorMixin {

    @Accessor(value = "connection")
    class_634 getConnection();

}
