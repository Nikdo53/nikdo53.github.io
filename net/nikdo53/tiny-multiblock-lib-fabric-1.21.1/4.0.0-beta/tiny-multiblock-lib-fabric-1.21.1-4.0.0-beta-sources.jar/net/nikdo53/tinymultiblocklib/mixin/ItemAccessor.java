package net.nikdo53.tinymultiblocklib.mixin;


import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1792.class)
public interface ItemAccessor {
    @Invoker(value = "getPlayerPOVHitResult")
    @NotNull
    static class_3965 getPlayerPOVHitResult(class_1937 level, class_1657 player, class_3959.class_242 fluidMode) {
        throw new AssertionError();
    }

}
