package net.nikdo53.tinymultiblocklib.mixin;

import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1937.class)
public interface LevelAccessorMixin {

    @Accessor(value = "isClientSide")
    @Mutable
    void tmbl$setClientSide(boolean clientSided);
}
