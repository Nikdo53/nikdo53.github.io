package net.nikdo53.tinymultiblocklib.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_638;
import net.minecraft.class_761;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import net.nikdo53.tinymultiblocklib.block.shape.MultiblockShape;
import net.nikdo53.tinymultiblocklib.block.shape.ShapeDataKey;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_761.class)
public class LevelRendererMixin {
    @WrapOperation(method = "renderHitOutline", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/LevelRenderer;renderShape(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/world/phys/shapes/VoxelShape;DDDFFFF)V")
    )
    private void tryRenderMultiblockOutline(
            class_4587 poseStack, class_4588 consumer, class_265 shape, double x, double y, double z, float red, float green, float blue, float alpha, Operation<Void> original,
            @Local(argsOnly = true) class_2680 state, @Local(argsOnly = true) class_2338 pos
    ) {
        if (state.method_26204() instanceof IMultiBlock multiBlock) {
            if (!tinyMultiblockLib$actuallyRenderTheOutline(poseStack, consumer, x, y, z, red, green, blue, alpha, original, state, pos, multiBlock))
                return;
        }

        original.call(poseStack, consumer, shape, x, y, z, red, green, blue, alpha);

    }

    @Unique
    //returns true if the original outline should be rendered too
    private static boolean tinyMultiblockLib$actuallyRenderTheOutline(class_4587 poseStack, class_4588 consumer, double x, double y, double z, float red, float green, float blue, float alpha, Operation<Void> original, class_2680 state, class_2338 pos, IMultiBlock multiBlock) {
        class_638 level = class_310.method_1551().field_1687;
        assert level != null;

        MultiblockShape multiblockShape = multiBlock.getFullBlockShape(level, pos, state);
        class_2338 offset = multiblockShape.getOffset(pos).method_35830(-1);
        MultiblockShape.Entry entry = multiblockShape.getEntry(offset);

        class_265 jointVoxelShape = multiblockShape.getJointVoxelShape(level, state);
        if (jointVoxelShape.method_1110()) return true;

        original.call(poseStack, consumer, jointVoxelShape.method_1096(offset.method_10263(), offset.method_10264(), offset.method_10260()), x, y, z, red, green, blue, alpha);
        if (entry == null) return false;
        return entry.getDataOrDefault(ShapeDataKey.STANDALONE_VOXEL_SHAPE, false);
    }

}
