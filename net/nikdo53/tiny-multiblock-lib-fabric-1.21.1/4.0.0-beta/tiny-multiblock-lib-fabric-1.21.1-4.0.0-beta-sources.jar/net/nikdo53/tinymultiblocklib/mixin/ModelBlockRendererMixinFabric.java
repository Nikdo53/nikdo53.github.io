package net.nikdo53.tinymultiblocklib.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_777;
import net.minecraft.class_778;
import net.nikdo53.tinymultiblocklib.client.RenderUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;

@Mixin(class_778.class)
public class ModelBlockRendererMixinFabric {
    
    @WrapOperation(method = "renderModel", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/block/ModelBlockRenderer;renderQuadList(Lcom/mojang/blaze3d/vertex/PoseStack$Pose;Lcom/mojang/blaze3d/vertex/VertexConsumer;FFFLjava/util/List;II)V",
            ordinal = 0)
    )
    private static void renderQuadListCheckSidesWrap(class_4587.class_4665 pose, class_4588 consumer, float red, float green, float blue,
                                                     List<class_777> quads, int packedLight, int packedOverlay, Operation<Void> original,
                                                     @Local class_2350 direction
    ) {
        RenderUtils.CheckSidesContext context = RenderUtils.CHECK_SIDES_CONTEXT;
        if (context == null){
            original.call(pose, consumer, red, green, blue, quads, packedLight, packedOverlay);
            return;
        }

        if (class_2248.method_9607(context.state(), context.level(), context.pos(), direction, context.pos().method_10093(direction))) {
            original.call(pose, consumer, red, green, blue, quads, packedLight, packedOverlay);
        }
    }

}
