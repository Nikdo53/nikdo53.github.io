package net.nikdo53.tinymultiblocklib.mixin;

import net.minecraft.class_1921;
import net.minecraft.class_293;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1921.class)
public interface RenderTypeAccessor {

     @Accessor
     class_293 getFormat();

     @Accessor
     class_293.class_5596 getMode();

}
