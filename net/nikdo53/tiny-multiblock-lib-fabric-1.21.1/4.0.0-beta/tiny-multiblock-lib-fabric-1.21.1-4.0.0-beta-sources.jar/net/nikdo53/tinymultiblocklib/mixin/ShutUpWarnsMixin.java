package net.nikdo53.tinymultiblocklib.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2792;
import net.minecraft.class_3218;
import net.minecraft.class_3244;
import net.minecraft.class_5629;
import net.minecraft.class_7633;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import net.nikdo53.tinymultiblocklib.blockentities.IMultiBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_3244.class)
public abstract class ShutUpWarnsMixin implements class_5629, class_7633, class_2792 {

    /**
     * Minecraft loves spamming errors when the player interacts with a VoxelShape larger than 1 block, this shuts it up
     * */
    @ModifyVariable(method = "handleUseItemOn", at = @At(value = "STORE"), ordinal = 1)
    public class_243 useAllower(class_243 vec3, @Local class_3218 level, @Local class_2338 pos) {
        if(level.method_8320(pos).method_26204() instanceof IMultiBlock){
            return new class_243(0, 0 , 0);
        }
        return vec3;
    }

}
