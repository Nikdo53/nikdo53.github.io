package net.nikdo53.tinymultiblocklib.mixin.carryon;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import tschipp.carryon.common.carry.PickupHandler;

import java.util.function.BiFunction;

@Mixin(PickupHandler.class)
public class PickupHandlerMixin {

    @Inject(method = "tryPickUpBlock", at = @At(value = "INVOKE", target = "Ltschipp/carryon/common/carry/CarryOnDataManager;getCarryData(Lnet/minecraft/world/entity/player/Player;)Ltschipp/carryon/common/carry/CarryOnData;", shift = At.Shift.AFTER), remap = false, require = 0)
    private static void tryPickUpBlock(class_3222 player, class_2338 pos, class_1937 level, BiFunction<class_2680, class_2338, Boolean> pickupCallback, CallbackInfoReturnable<Boolean> cir, @Local(argsOnly = true) LocalRef<class_2338> posLocalRef) {
        if (IMultiBlock.isMultiblock(level, pos)) {
            posLocalRef.set(IMultiBlock.getCenter(level, pos));
        }
    }

}
