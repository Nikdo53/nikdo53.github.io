package net.nikdo53.tinymultiblocklib.platform;

import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import net.nikdo53.tinymultiblocklib.platform.services.IUtils;

import java.util.Optional;

public class FabricUtils implements IUtils {
    public static final FabricUtils INSTANCE = new FabricUtils();

    @Override
    public Optional<class_2960> locFromRenderType(class_1921 renderType) {
        if (renderType instanceof class_1921.class_4687 compositeState)
            if (compositeState.method_35784().field_21406 instanceof class_4668.class_4683 textureStateShard){
                return textureStateShard.method_23564();
            }
        return Optional.empty();
    }
}
