package net.nikdo53.tinymultiblocklib.platform.services;

import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.nikdo53.tinymultiblocklib.client.IOnBlockPreviewEvent;
import net.nikdo53.tinymultiblocklib.components.BlockLive;
import net.nikdo53.tinymultiblocklib.components.PreviewMode;

import java.util.Set;

public interface IEventPoster {

    IOnBlockPreviewEvent onBlockPreviewPre(PreviewMode previewMode, boolean isCancelled, BlockLive center, Set<BlockLive> blockLiveSet);

    void onBlockPreviewPost(PreviewMode previewMode, BlockLive center, Set<BlockLive> blockLiveSet, class_4587 poseStack, float partialTicks, class_4597.class_4598 bufferSource);

}
