package net.nikdo53.tinymultiblocklib.platform.services;

import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_4970;

public interface IRegistrationUtils {
    <T extends class_2586> Supplier<class_2591<T>> registerBlockEntity(String name, BiFunction<class_2338, class_2680, T> function, Set<class_2248> blocks);

    <T extends class_2248> Supplier<T> registerBlockWithItem(String name, Function<class_4970.class_2251, ? extends T> func, Supplier<class_4970.class_2251> properties) ;

    <T extends class_2248> Supplier<class_1792> registerBlockItem(String name, Supplier<T> block);

    <T extends class_2586> void addSupportedBEBlock(Supplier<class_2591<T>> blockEntityType, class_2248 block);}
