package net.nikdo53.tinymultiblocklib.platform.services;

import java.util.Optional;
import net.minecraft.class_1921;
import net.minecraft.class_2960;

public interface IUtils {

    Optional<class_2960> locFromRenderType(class_1921 renderType);
}
