package net.nikdo53.tinymultiblocklib.test;

import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2697;
import net.minecraft.class_2700;
import net.minecraft.class_3726;
import net.nikdo53.tinymultiblocklib.block.AbstractStructureMultiBlock;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import net.nikdo53.tinymultiblocklib.block.IPreviewableMultiblock;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class DiamondStructureBlock extends AbstractStructureMultiBlock implements IPreviewableMultiblock {
    public static final class_265 SHAPE = class_259.method_1081(0, 0, -1, 2, 2, 1);

    public DiamondStructureBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    public class_2464 getMultiblockRenderShape(class_2680 state, boolean isCenter) {
        return isCenter ? class_2464.field_11458 : class_2464.field_11455;
    }

    @Override
    public List<class_2338> makeFullBlockShape(@NotNull class_1937 level, @NotNull class_2338 center, @NotNull class_2680 state, @Nullable class_2586 blockEntity, @Nullable class_2350 direction) {
        return IMultiBlock.posStreamToList(class_2338.method_20437(center, center.method_10084().method_10095().method_10078()));
    }

    public static class_2700 getBlockPattern() {
        return class_2697.method_11701()
                .method_11702("xx",
                        "xx")
                .method_11702("xx",
                        "xx")
                .method_11700('x', blockInWorld -> blockInWorld.method_11681().method_27852(class_2246.field_10201))
                .method_11704();
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return voxelShapeHelper(state, level, pos, SHAPE);
    }
}
