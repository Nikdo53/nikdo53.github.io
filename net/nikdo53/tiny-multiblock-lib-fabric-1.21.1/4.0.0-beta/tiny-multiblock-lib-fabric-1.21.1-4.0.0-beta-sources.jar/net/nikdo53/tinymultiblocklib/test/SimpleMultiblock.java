package net.nikdo53.tinymultiblocklib.test;

import net.minecraft.class_2350;
import net.nikdo53.tinymultiblocklib.block.*;
import net.nikdo53.tinymultiblocklib.block.logic.MultiblockLogic;
import net.nikdo53.tinymultiblocklib.block.shape.MultiblockShape;
import net.nikdo53.tinymultiblocklib.block.shape.ShapeContext;
import net.nikdo53.tinymultiblocklib.block.shape.ShapeDataKey;
import org.jetbrains.annotations.Nullable;

import java.util.function.UnaryOperator;

public class SimpleMultiblock extends BaseMultiblock implements IPreviewableMultiblock {
    public SimpleMultiblock(class_2251 properties) {
        super(properties);
    }

    @Override
    public @Nullable DirectionContext makeDirectional() {
        return DirectionContext.allAxis();
    }

    @Override
    public void makeMultiblockShape(MultiblockShape.Builder builder, ShapeContext context) {
        class_2350 direction = context.getDirection();
        builder.pushDirectionalOperation(direction);

        builder.toSymbolBuilder(class_2350.field_11043)
                .nextAisle(" x",
                           "xc")
                .nextAisle("  ",
                           " x")
                .where('x', UnaryOperator.identity())
        ;
    }

}
