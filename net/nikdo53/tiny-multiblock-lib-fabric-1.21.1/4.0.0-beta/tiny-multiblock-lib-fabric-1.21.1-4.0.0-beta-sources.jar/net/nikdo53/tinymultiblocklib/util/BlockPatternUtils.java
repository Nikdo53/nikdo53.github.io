package net.nikdo53.tinymultiblocklib.util;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2694;
import net.minecraft.class_2700;
import net.nikdo53.tinymultiblocklib.Constants;
import net.nikdo53.tinymultiblocklib.block.BaseMultiblock;
import net.nikdo53.tinymultiblocklib.components.Corner;

public class BlockPatternUtils {

    public static boolean findAndPlace(class_2700 blockPattern, class_1937 level, class_2338 pos, class_2680 stateToPlace, class_2338 placementOffset, Corner corner){
        class_2700.class_2702 blockPatternMatch = blockPattern.method_11708(level, pos);
        if (blockPatternMatch == null) return false;

       // Direction.WEST, Direction.DOWN, Direction.SOUTH
        class_2338 center = BlockPatternUtils.getCorner(blockPatternMatch, corner);
        level.method_8652(center.method_10081(placementOffset), stateToPlace.method_47968(BaseMultiblock.CENTER, true), 3);

        return true;
    }

    public static class_2338 getBottomNorthWest(class_2700.class_2702 match) {
        int width = match.method_35302();
        int height = match.method_35303();
        int depth = match.method_35304();

        class_2338 result = null;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                for (int z = 0; z < depth; z++) {

                    class_2694 biw = match.method_11717(x, y, z);
                    class_2338 worldPos = biw.method_11683();

                    if (result == null){
                        result =  worldPos;
                        continue;
                    }

                    if (worldPos.method_10263() < result.method_10263() || worldPos.method_10264() < result.method_10264() || worldPos.method_10260() < result.method_10260()) {
                        result = worldPos;
                    }
                }
            }
        }

        return result;
    }

    public static class_2338 getCorner(class_2700.class_2702 match, Corner corner){
        return getCorner(match, corner.x, corner.y, corner.z);
    }

    public static class_2338 getCorner(class_2700.class_2702 match, class_2350 xAxis, class_2350 yAxis, class_2350 zAxis) {
        class_2338 result = getBottomNorthWest(match);
        int width = match.method_35302();
        int height = match.method_35303();
        int depth = match.method_35304();

        if (xAxis.method_10166() != class_2350.class_2351.field_11048 || yAxis.method_10166() != class_2350.class_2351.field_11052 || zAxis.method_10166() != class_2350.class_2351.field_11051) {
            Constants.LOGGER.error("Tried getting BlockPattern corner for an invalid direction");
            return result;
        }

        if (xAxis == class_2350.field_11034) result = result.method_10089(width - 1);
        if (yAxis == class_2350.field_11036)  result = result.method_10086(height - 1);
        if (zAxis == class_2350.field_11035)  result = result.method_10077(depth - 1);

        return result;
    }




}
