package net.nikdo53.tinymultiblocklib.util;

import net.minecraft.class_156;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.world.phys.shapes.*;

import java.util.List;

// Credit to XFactHD from the neoforge discord
public class VoxelShapeUtils {
    private static final int[] DIR_ROT_X_2D_DATA = class_156.method_654(new int[6], arr ->
    {
        arr[class_2350.field_11033.ordinal()] = 2;
        arr[class_2350.field_11036.ordinal()] = 0;
        arr[class_2350.field_11043.ordinal()] = 3;
        arr[class_2350.field_11035.ordinal()] = 1;
        arr[class_2350.field_11039.ordinal()] = -1;
        arr[class_2350.field_11034.ordinal()] = -1;
    });
    private static final int[] DIR_ROT_Z_2D_DATA = class_156.method_654(new int[6], arr ->
    {
        arr[class_2350.field_11033.ordinal()] = 2;
        arr[class_2350.field_11036.ordinal()] = 0;
        arr[class_2350.field_11043.ordinal()] = -1;
        arr[class_2350.field_11035.ordinal()] = -1;
        arr[class_2350.field_11039.ordinal()] = 3;
        arr[class_2350.field_11034.ordinal()] = 1;
    });

    public static class_265 rotateAll(class_2350 to, class_265 shape){
        if (to == class_2350.field_11043)
            return shape;
        if (isY(to)){
            return rotateShapeAroundX(class_2350.field_11043, to, shape);
        } else
            return rotateShapeAroundY(class_2350.field_11043, to, shape);
    }

    public static class_265 rotateShapeAroundY(class_2350 from, class_2350 to, class_265 shape)
    {
        return rotateShapeUnoptimizedAroundY(from, to, shape).method_1097();
    }

    public static class_265 rotateShapeUnoptimizedAroundY(class_2350 from, class_2350 to, class_265 shape)
    {
        if (isY(from) || isY(to))
        {
            throw new IllegalArgumentException("Invalid Direction!");
        }
        if (from == to)
        {
            return shape;
        }

        List<class_238> sourceBoxes = shape.method_1090();
        class_265 rotatedShape = class_259.method_1073();
        int times = (to.method_10161() - from.method_10161() + 4) % 4;
        for (class_238 box : sourceBoxes)
        {
            for (int i = 0; i < times; i++)
            {
                box = new class_238(1 - box.field_1324, box.field_1322, box.field_1323, 1 - box.field_1321, box.field_1325, box.field_1320);
            }
            rotatedShape = orUnoptimized(rotatedShape, class_259.method_1078(box));
        }

        return rotatedShape;
    }

    public static class_265 rotateShapeAroundX(class_2350 from, class_2350 to, class_265 shape)
    {
        return rotateShapeUnoptimizedAroundX(from, to, shape).method_1097();
    }

    public static class_265 rotateShapeUnoptimizedAroundX(class_2350 from, class_2350 to, class_265 shape)
    {
        if (isX(from) || isX(to))
        {
            throw new IllegalArgumentException("Invalid Direction!");
        }
        if (from == to)
        {
            return shape;
        }

        List<class_238> sourceBoxes = shape.method_1090();
        class_265 rotatedShape = class_259.method_1073();
        int times = (DIR_ROT_X_2D_DATA[to.ordinal()] - DIR_ROT_X_2D_DATA[from.ordinal()] + 4) % 4;
        for (class_238 box : sourceBoxes)
        {
            for (int i = 0; i < times; i++)
            {
                box = new class_238(box.field_1323, 1 - box.field_1324, box.field_1322, box.field_1320, 1 - box.field_1321, box.field_1325);
            }
            rotatedShape = orUnoptimized(rotatedShape, class_259.method_1078(box));
        }

        return rotatedShape;
    }

    public static class_265 rotateShapeAroundZ(class_2350 from, class_2350 to, class_265 shape)
    {
        return rotateShapeUnoptimizedAroundZ(from, to, shape).method_1097();
    }

    public static class_265 rotateShapeUnoptimizedAroundZ(class_2350 from, class_2350 to, class_265 shape)
    {
        if (isZ(from) || isZ(to))
        {
            throw new IllegalArgumentException("Invalid Direction!");
        }
        if (from == to)
        {
            return shape;
        }

        List<class_238> sourceBoxes = shape.method_1090();
        class_265 rotatedShape = class_259.method_1073();
        int times = (DIR_ROT_Z_2D_DATA[to.ordinal()] - DIR_ROT_Z_2D_DATA[from.ordinal()] + 4) % 4;
        for (class_238 box : sourceBoxes)
        {
            for (int i = 0; i < times; i++)
            {
                //noinspection SuspiciousNameCombination
                box = new class_238(box.field_1322, 1 - box.field_1320, box.field_1321, box.field_1325, 1 - box.field_1323, box.field_1324);
            }
            rotatedShape = orUnoptimized(rotatedShape, class_259.method_1078(box));
        }

        return rotatedShape;
    }


    private static class_265 orUnoptimized(class_265 first, class_265 second)
    {
        return class_259.method_1082(first, second, class_247.field_1366);
    }

    private static boolean isX(class_2350 dir) {
        return dir.method_10166() == class_2350.class_2351.field_11048;
    }

    private static boolean isY(class_2350 dir) {
        return dir.method_10166() == class_2350.class_2351.field_11052;
    }

    private static boolean isZ(class_2350 dir) {
        return dir.method_10166() == class_2350.class_2351.field_11051;
    }

}
