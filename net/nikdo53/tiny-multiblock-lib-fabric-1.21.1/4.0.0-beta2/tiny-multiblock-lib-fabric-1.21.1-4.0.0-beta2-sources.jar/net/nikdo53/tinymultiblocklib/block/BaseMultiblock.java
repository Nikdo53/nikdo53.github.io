package net.nikdo53.tinymultiblocklib.block;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.world.level.*;
import net.nikdo53.tinymultiblocklib.CommonRegistration;
import net.nikdo53.tinymultiblocklib.block.shape.MultiblockShape;
import net.nikdo53.tinymultiblocklib.block.shape.ShapeDataKey;
import net.nikdo53.tinymultiblocklib.blockentities.AbstractMultiBlockEntity;
import net.nikdo53.tinymultiblocklib.components.SharedStatePropertiesBuilder;
import net.nikdo53.tinymultiblocklib.block.shape.ShapeContext;
import net.nikdo53.tinymultiblocklib.platform.Services;
import org.jetbrains.annotations.Nullable;

public abstract class BaseMultiblock extends class_2248 implements IMovableMultiblock {
    /**
     * The BlockState of the multiblocks center block, ideally you should forward all logic to this block
     * <p>
     * Note that even though it's called "CENTER", it isn't necessarily the actual center.
     * The center is just where the block would be placed if it were just a single block
     * @see #isCenter(BlockState)
     * @see #getCenter(BlockGetter, BlockPos)
     * */
    public static final class_2746 CENTER = class_2746.method_11825("center");
    private final SharedStatePropertiesBuilder SHARED_STATE_BUILDER = new SharedStatePropertiesBuilder();
    protected @Nullable ShapeContext.Properties shapeProperties = null;

    public BaseMultiblock(class_2251 properties) {
        super(properties);
        if (getDirectionProperty() != null){
            this.method_9590(this.method_9595().method_11664().method_11657(CENTER, true).method_11657(getDirectionProperty(), class_2350.field_11043));
        } else {
            this.method_9590(this.method_9595().method_11664().method_11657(CENTER, true));
        }

        if (!hasCustomBE())
            addToValidBEBlocks();
    }

    @Override
    public ShapeContext.@Nullable Properties getShapeProperties() {
        return shapeProperties;
    }

    @Override
    public void setShapeProperties(ShapeContext.Properties properties) {
        this.shapeProperties = properties;
    }

    @Override
    public SharedStatePropertiesBuilder getSharedStatePropertiesBuilder() {
        return SHARED_STATE_BUILDER;
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        return getStateForPlacementHelper(context);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return getMultiblockRenderShape(state, IMultiBlock.isCenter(state));
    }

    /**
     * If your block is a JSON model, return {@link class_2464#field_11458}
     * <p>
     * If your block has a BlockEntity renderer, return {@link class_2464#field_11455} for that specific block and  {@link class_2464#field_11455} everywhere else
     * */
    public class_2464 getMultiblockRenderShape(class_2680 state, boolean isCenter){
        return class_2464.field_11458;
    };

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(CENTER);
        if (getDirectionProperty() != null) builder.method_11667(getDirectionProperty());
    }

    @Override
    public void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        super.method_9615(state, level, pos, oldState, movedByPiston);

        onPlaceHelper(state, level, pos, oldState);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        return updateShapeHelper(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        return canSurviveHelper(state, level, pos);
    }

    @Override
    public class_2680 method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        preventCreativeDrops(player, level, pos);
        return super.method_9576(level, pos, state, player);
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        if (getDirectionProperty() != null) {
            class_2350 currentDirection = state.method_11654(getDirectionProperty());
            return state.method_11657(getDirectionProperty(), rotation.method_10503(currentDirection));
        }
        return super.method_9598(state, rotation);
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        if (getDirectionProperty() != null) {
            class_2350 currentDirection = state.method_11654(getDirectionProperty());
            return state.method_11657(getDirectionProperty(), mirror.method_10345(currentDirection).method_10503(currentDirection));
        }
        return super.method_9569(state, mirror);
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        MultiblockShape fullBlockShape = getFullBlockShape(level, pos, state);
        class_2338 offset = IMultiBlock.getOffset(level, pos);
        MultiblockShape.Entry entry = fullBlockShape.getShape().get(offset);

        if (entry != null && entry.hasData(ShapeDataKey.VOXEL_SHAPE)){
            return entry.getData(ShapeDataKey.VOXEL_SHAPE);
        }
        return super.method_9530(state, level, pos, context);
    }

    /**
     * Remember to override {@link #hasCustomBE()} when overriding, so the block doesn't get added to valid blocks for no reason
     * */
    @Override
    public @Nullable AbstractMultiBlockEntity method_10123(class_2338 pos, class_2680 state) {
        return CommonRegistration.BlockEntities.SIMPLE_MULTIBLOCK_ENTITY.get().method_11032(pos, state);
    }

    public boolean hasCustomBE(){
        return false;
    }

    protected void addToValidBEBlocks(){
        CommonRegistration.BlockEntities.VALID_BLOCKS_SIMPLE.add(this);
        Services.PLATFORM.getRegistration().addSupportedBEBlock(CommonRegistration.BlockEntities.SIMPLE_MULTIBLOCK_ENTITY, this);
    }

}
