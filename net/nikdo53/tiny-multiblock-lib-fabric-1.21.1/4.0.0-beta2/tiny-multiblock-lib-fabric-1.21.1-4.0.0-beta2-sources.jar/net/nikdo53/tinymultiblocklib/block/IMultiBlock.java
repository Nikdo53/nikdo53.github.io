package net.nikdo53.tinymultiblocklib.block;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_4538;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.*;
import net.nikdo53.tinymultiblocklib.block.logic.MultiblockBehaviour;
import net.nikdo53.tinymultiblocklib.block.logic.MultiblockLogic;
import net.nikdo53.tinymultiblocklib.blockentities.IMultiBlockEntity;
import net.nikdo53.tinymultiblocklib.components.BlockLive;
import net.nikdo53.tinymultiblocklib.components.IBlockPosOffsetEnum;
import net.nikdo53.tinymultiblocklib.block.shape.MultiblockShape;
import net.nikdo53.tinymultiblocklib.block.shape.ShapeContext;
import net.nikdo53.tinymultiblocklib.util.TMBLUtils;
import org.apache.commons.lang3.function.TriFunction;
import org.jetbrains.annotations.ApiStatus;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Stream;

import static net.nikdo53.tinymultiblocklib.block.BaseMultiblock.CENTER;

public interface IMultiBlock extends IMBStateSharer, MultiblockBehaviour, class_2343 {

    /** Builds the multiblocks shape along with each parts properties. Center is added automatically but can be overridden
     * <p>
     * Should only be used for overriding
     * @param builder The builder to add the shape to, .build gets called automatically
     * @param context The context of the shape, all getters should be included in the top of the method.
     * @see #getFullBlockShape(class_1922, class_2338, class_2680)
     * @see #getFullBlockShapeNoCache(class_1937, class_2586, class_2338, class_2680)
     * */
    void makeMultiblockShape(MultiblockShape.Builder builder, ShapeContext context);

    @ApiStatus.Internal
    default MultiblockLogic getDefaultCenterLogic(ShapeContext context){
        return MultiblockLogic.EMPTY;
    }

    @ApiStatus.Internal
    @Nullable ShapeContext.Properties getShapeProperties();

    @ApiStatus.Internal
    void setShapeProperties(ShapeContext.Properties properties);


    /**
     * Mojangs BetweenClosed methods return a mutable BlockPos, which breaks everything.
     * Use this helper method to convert them safely
     * */
    static List<class_2338> posStreamToList(Stream<class_2338> posStream){
        return new ArrayList<>(posStream.map(class_2338::method_10062).toList());
    }

    /**
     * Returns the multiblocks DirectionProperty.
     * <p>
     * Only used for multiblocks that can be rotated, otherwise returns null
     * <p>
     * Use {@link #makeDirectional()} instead.
     * */
    default @Nullable class_2753 getDirectionProperty(){
        DirectionContext directionContext = makeDirectional();
        return directionContext != null ? directionContext.property() : null; // null if block doesn't have directions
    }

    /**
     * Returns the multiblocks DirectionProperty and extractor function. Automatically registers the block state property, no additional setup necessary.
     * <p>
     * Only used for multiblocks that can be rotated, otherwise returns null
     * */
    default @Nullable DirectionContext makeDirectional(){
        return null; // null if block doesn't have directions
    }

    /**
     * Context for directional multiblocks.
     * @param property The DirectionProperty of the multiblock
     * @param directionExtractor The function to extract the direction from a block place context, returns null if the block cannot be placed
     * */
    record DirectionContext(class_2753 property, Function<class_1750, class_2350> directionExtractor){
        public static DirectionContext horizontal(){
            return new DirectionContext(class_2383.field_11177, class_1838::method_8042);
        }

        public static DirectionContext allAxis(){
            return new DirectionContext(class_2741.field_12525, class_1838::method_8038);
        }

    }

    default class_2350 getDirection(class_2680 state){
        if (getDirectionProperty() != null){
            return state.method_11654(getDirectionProperty());
        }
        return class_2350.field_11043;
    }

    default MultiblockShape getFullBlockShapeNoCache(@Nullable class_1937 level, @Nullable class_2586 blockEntity, class_2338 center, class_2680 state){
        if (blockEntity == null && level != null){
            blockEntity = level.method_8321(center);
        }

        ShapeContext context = new ShapeContext(level, center, state, blockEntity, this);

        MultiblockShape.Builder builder = new MultiblockShape.Builder(center, getDefaultCenterLogic(context));
        makeMultiblockShape(builder, context);

        ShapeContext.Properties properties = context.getProperties();
        if (getShapeProperties() == null){
            setShapeProperties(properties);
        } else if (!getShapeProperties().equals(properties)){
            throw new IllegalStateException("Shape properties changed unexpectedly, please include any getters from the context at the top of the makeMultiblockShape method.");
        }


        return builder.build();
    }


    default MultiblockShape getFullBlockShape(class_1922 level, class_2338 pos, class_2680 state){
        class_2338 center = getCenter(level, pos);
        class_2586 blockEntity = level.method_8321(center);
        class_1937 betterLevel = level instanceof class_1937 ? (class_1937) level : null;

        assert betterLevel != null;
        if (!(blockEntity instanceof IMultiBlockEntity mbEntity)){
            return getFullBlockShapeNoCache(betterLevel, blockEntity ,center, state);
        }

        if (mbEntity.getFullBlockShapeCache().getShape().isEmpty()){
            return getAndUpdateShapeCache(state, mbEntity, betterLevel, blockEntity, center);
        }

        return mbEntity.getFullBlockShapeCache();
    }

    private MultiblockShape getAndUpdateShapeCache(class_2680 state, IMultiBlockEntity mbEntity, class_1937 betterLevel, class_2586 blockEntity, class_2338 center) {
        MultiblockShape blockPosList = getFullBlockShapeNoCache(betterLevel, blockEntity, center, state);

        mbEntity.setFullBlockShapeCache(blockPosList);
        return blockPosList;
    }

    static List<class_2338> getFullShape(class_1922 level, class_2338 pos){
        class_2680 state = level.method_8320(pos);

        if (state.method_26204() instanceof IMultiBlock multiBlock){
            return multiBlock.getFullBlockShape(level, pos, state).getGlobalPositions().stream().toList();
        }

        return List.of(pos);
    }

    static void invalidateCaches(class_1922 level, class_2338 pos){
        if (level.method_8321(getCenter(level, pos)) instanceof IMultiBlockEntity blockEntity){
            blockEntity.invalidateCaches();
        }
    }

    /**
     * Changes the BlockState for each Block in this multiblock.
     * Works like GetStateForPlacement does in regular blocks
     * @see IBlockPosOffsetEnum#fromOffset(Class, class_2338, class_2350, Enum)
     * @deprecated : use the shape builder instead.
     * */
    @Deprecated
    default class_2680 getStateForEachBlock(class_2680 state, class_2338 pos, class_2338 centerOffset, class_1937 level, @Nullable class_2350 direction){
        return state;
    }

    default void onPlaceHelper(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState) {
        verifyValidBlockEntity(level, pos);
        boolean isPlaced = IMultiBlockEntity.isPlaced(level, pos);

        if (isPlaced) shareBlockStates(level, pos, state);

        if (isCenter(state)) {
            if (!isPlaced) place(level, pos, state);
        }
    }

    /**
     * Places the multiblock, sets its BlockStates and BlockEntity center
     * */
    default void place(class_1937 level, class_2338 centerPos, class_2680 stateOriginal){
        prepareForPlace(getFullBlockShape(level, centerPos, stateOriginal), level, centerPos, stateOriginal).forEach(blockLike -> {
            int flags = 66;

            class_2680 stateNew = blockLike.state;
            class_2338 posNew = blockLike.pos;

            // Don't replace identical blocks
            if (!level.method_8320(posNew).equals(stateNew)) {
                level.method_8652(posNew, stateNew, flags);
            }

            if(level.method_8321(posNew) instanceof IMultiBlockEntity entity && !entity.getCenter().equals(centerPos)) {
                entity.setCenter(centerPos);
                entity.getBlockEntity().method_5431();
            }
        });
    }
    /**
     * Prepares all blocks to be Placed
     * */
    default List<BlockLive> prepareForPlace(MultiblockShape shape, class_1937 level, class_2338 centerPos, class_2680 stateOriginal){
        List<BlockLive> list = new ArrayList<>();

        shape.getShape().forEach((posNew, entry) -> {
            posNew = posNew.method_10062().method_10081(centerPos);

            class_2680 stateNew = stateOriginal.method_11657(BaseMultiblock.CENTER, centerPos.equals(posNew));
            stateNew = getStateForEachBlock(stateNew, posNew, posNew.method_10059(centerPos), level, getDirection(stateOriginal));
            stateNew = entry.stateModifier().apply(stateNew);

            list.add(new BlockLive(posNew, stateNew));
        });

        return list;
    }


    default @Nullable class_2680 getStateForPlacementHelper(class_1750 context) {
        DirectionContext directionContext = makeDirectional();
        class_2350 direction = directionContext == null ? context.method_8042() : directionContext.directionExtractor().apply(context);
        if (direction == null)
            return null;
        return getStateForPlacementHelper(context, direction);
    }

    /**
     * Helper for {@link class_2248#method_9605(class_1750)}
     * @param direction The direction the block will have when placed, ignored when {@link #getDirectionProperty()} is null
     * */
    default @Nullable class_2680 getStateForPlacementHelper(class_1750 context, class_2350 direction) {
        class_4538 level = context.method_8045();
        class_2338 pos = context.method_8037();
        class_2680 state = self().method_9564().method_11657(BaseMultiblock.CENTER, true);

        if (getDirectionProperty() != null){
            state = state.method_11657(getDirectionProperty(), direction);
        }

        return canPlace(level, pos, state, context.method_8036(), true) ? state : null;
    }

    default boolean canPlace(class_4538 level, class_2338 center, class_2680 state, @Nullable class_1297 player, boolean ignoreEntities) {
        MultiblockShape shape = getFullBlockShape(level, center, state);
        return shape.getGlobalPositions().stream().allMatch(pos -> canPlaceBlock(pos, level, center, state, player, ignoreEntities, shape));
    }

    default boolean canPlaceBlock(class_2338 pos, class_4538 level, class_2338 center, class_2680 state, @Nullable class_1297 player, boolean ignoreEntities, MultiblockShape shape) {
        return canReplaceBlock(level, pos, level.method_8320(pos), shape)
                && extraSurviveRequirements(level, pos, state, pos.method_10059(center), shape)
                && (entityUnobstructed(level, pos, state, player, shape) || ignoreEntities)
                && pos.method_10264() < level.method_31600() && pos.method_10264() > level.method_31607();
    }

    default void destroy(class_2338 center, class_1936 level, class_2680 state, boolean dropBlock){
        if (level.method_8608()) return;
        Set<class_2338> blocks = getFullBlockShape(level, center, state).getGlobalPositions();

        if (level.method_8320(center).method_27852(state.method_26204())) {
            level.method_22352(center, dropBlock);
        }

        blocks.forEach(pos ->{
            if (pos.equals(center)) return;

            class_2680 blockState = level.method_8320(pos);
            if (blockState.method_27852(state.method_26204())) {
                level.method_22352(pos, dropBlock);
            }
        });
    }

    default boolean allBlocksPresent(class_4538 level, class_2338 pos, class_2680 state){
        if (level.method_8608()) return true;
        class_2338 center = getCenter(level, pos);

        boolean ret = getFullBlockShape(level, center, state).getGlobalPositions().stream().allMatch(blockPos -> level.method_8320(blockPos).method_27852(self()));

        boolean isMultiblock = isMultiblock(level, pos);
        if (ret && level.method_8321(pos) instanceof IMultiBlockEntity entity && !entity.isPlaced() && isMultiblock) {
            getFullBlockShape(level, center, state).getGlobalPositions().forEach(blockPos -> IMultiBlockEntity.setPlaced(level, blockPos, true));
        }

        return ret;
    }

    /**
     * Helper for Block.updateShape()
     * <p>
     * Destroys the multiblock if canSurvive returns false
     * */
    default class_2680 updateShapeHelper(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos){
        if (!(level.method_8321(pos) instanceof IMultiBlockEntity entity)) return class_2246.field_10124.method_9564();

        boolean canSurvive = state.method_26184(level, pos);

        if (!canSurvive){
            destroy(entity.getCenter(), level, state, true);
            return class_2246.field_10124.method_9564();
        }

        return state;
    }

    /**
     * Helper for Block.canSurvive()
     * */
    default boolean canSurviveHelper(class_2680 state, class_4538 level, class_2338 pos){
        if (level.method_8321(pos) instanceof IMultiBlockEntity entity){
            //survive logic
            MultiblockShape shape = getFullBlockShape(level, pos, state);
            boolean extraSurvive = shape.getGlobalPositions().stream().allMatch(blockPos -> extraSurviveRequirements(level, blockPos, state, entity.getOffset(), shape));
            return (allBlocksPresent(level, pos, state) || !entity.isPlaced()) && extraSurvive;
        } else {
            //placement logic
            return canPlace(level, pos, state, null, false);
        }
    }

    /**
     * Should be added into {@link class_2248#method_9556(class_1937, class_1657, class_2338, class_2680, class_2586, class_1799)}
     * */
    default void preventCreativeDrops(class_1657 player, class_1937 level, class_2338 pos){
        if (player.method_7337() && level.method_8321(pos) instanceof IMultiBlockEntity entity) {
            destroy(entity.getCenter(), level, level.method_8320(pos), false);
        }
    }
    /**
     * Returns the center BlockPos of the multiblock
     * */
    static class_2338 getCenter(class_1922 level, class_2338 pos){
        if (level.method_8321(pos) instanceof IMultiBlockEntity entity){
            return entity.getCenter();
        }
        return pos;
    }

    /**
     * Returns the offset BlockPos from center of the multiblock
     * */
    static class_2338 getOffset(class_1922 level, class_2338 pos){
        if (level.method_8321(pos) instanceof IMultiBlockEntity entity){
            return entity.getOffset();
        }
        return new class_2338(0,0,0);
    }
    
    static boolean isCenter(class_2680 state){
        return state.method_11654(CENTER);
    }

    static boolean isMultiblock(class_2680 state){
        return state.method_26204() instanceof IMultiBlock;
    }

    static boolean isMultiblock(class_1922 level, class_2338 pos){
        return isMultiblock(level.method_8320(pos));
    }

    default class_265 voxelShapeHelper(class_2680 state, class_1922 level, class_2338 pos, class_265 shape){
        return voxelShapeHelper(state,level,pos,shape, 0, 0, 0);
    }

    default class_265 voxelShapeHelper(class_2680 state, class_1922 level, class_2338 pos, class_265 shape, float xOffset, float yOffset, float zOffset){
        return voxelShapeHelper(state,level,pos,shape, xOffset, yOffset, zOffset, false);
    }

    /**
     * Offsets each Blocks VoxelShape to the center, allowing for VoxelShapes larger than 1 block
     * @param hasDirectionOffsets Larger directional multiblocks may have their center in a different point for every rotation, this offsets the VoxelShapes accordingly
     * */
    default class_265 voxelShapeHelper(class_2680 state, class_1922 level, class_2338 pos, class_265 shape, float xOffset, float yOffset, float zOffset, boolean hasDirectionOffsets){
        if (level.method_8321(pos) instanceof IMultiBlockEntity entity) {
            double x = (-entity.getOffset().method_10263()) + xOffset;
            double y = (-entity.getOffset().method_10264()) + yOffset;
            double z = (-entity.getOffset().method_10260()) + zOffset;

            if (getDirectionProperty() != null && hasDirectionOffsets) {
                switch (state.method_11654(getDirectionProperty())) {
                    case field_11034 -> x += 1;
                    case field_11043 -> {
                        x += 1;
                        z -= 1;
                    }
                    case field_11039 -> z -= 1;
                }
            }
            TriFunction<Double, Double, Double, class_265> memoize = TMBLUtils.memoize(shape::method_1096);
            return memoize.apply(x, y, z);
        }
        return shape;
    }

    static boolean isSameMultiblock(class_1937 level, class_2680 state1, class_2680 state2, class_2338 center, class_2338 posNew){
        return state1.method_26204().equals(state2.method_26204()) && level.method_8321(posNew) instanceof IMultiBlockEntity entity && entity.getCenter().equals(center);
    }

    private class_2248 self(){
        if (this instanceof class_2248 block){
            return block;
        } else {
            throw new RuntimeException(this.getClass().getSimpleName() + " is not implemented on a Block");
        }
    }

    static void verifyValidBlockEntity(class_1937 level, class_2338 pos){
        class_2586 blockEntity = level.method_8321(pos);

        if (blockEntity != null){
            if (!(blockEntity instanceof IMultiBlockEntity)){
                throw new IllegalStateException(blockEntity.getClass().getSimpleName() + " does not implement IMultiBlockEntity!");
            }
        }

    }

}
