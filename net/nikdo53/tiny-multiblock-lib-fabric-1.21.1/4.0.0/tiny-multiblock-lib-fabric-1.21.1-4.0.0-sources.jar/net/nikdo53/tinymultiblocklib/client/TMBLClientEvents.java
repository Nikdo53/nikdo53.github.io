package net.nikdo53.tinymultiblocklib.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_310;
import net.minecraft.class_9779;
import net.nikdo53.tinymultiblocklib.client.ghost.GhostRenderer;

public class TMBLClientEvents {
    public static void init() {
        WorldRenderEvents.AFTER_ENTITIES.register(TMBLClientEvents::renderLevelStageEvent);
        ClientTickEvents.END_CLIENT_TICK.register(TMBLClientEvents::clientTick);
    }

    private static void renderLevelStageEvent(WorldRenderContext event) {
        MultiblockPreviewRenderer.tryRenderMultiblockPreviews(
                class_9779.field_51956.method_60637(true),
                event.camera(),
                event.matrixStack()
        );

        GhostRenderer.renderAll(
                class_9779.field_51956.method_60637(false),
                event.camera(),
                event.matrixStack()
        );
    }

    public static void clientTick(class_310 minecraft){
        CommonClientEvents.onClientTick();
    }
}
