package net.nikdo53.tinymultiblocklib.components;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4538;
import net.minecraft.class_7871;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class BlockLive {
    public class_2338 pos;
    public class_2680 state;

    public BlockLive(class_2338 pos, class_2680 state) {
        this.pos = pos;
        this.state = state;
    }

    public BlockLive(class_1922 level, class_2338 pos) {
        this(pos, level.method_8320(pos));
    }

    public BlockLive fromLevel(class_1922 level, class_2338 pos) {
        BlockLive blockLive = new BlockLive(level, pos);
        if (level.method_8321(pos) != null) {
           return blockLive.addBlockEntity(level.method_8321(pos));
        }
        return blockLive;
    }

    public void move(class_1937 level, class_2338 offset){
        class_2338 posNew = pos.method_10081(offset);
        level.method_8501(posNew, state);
    }

    public static class_7871<class_2248> getBlockGetter(@Nullable class_4538 level) {
       return level != null ? level.method_45448(class_7924.field_41254) : class_7923.field_41175.method_46771();
    }

    public BlockLive.Live addBlockEntity(class_2586 entity){
        return new BlockLive.Live(pos, state, entity);
    }

    public BlockLive.Live replaceBlockEntity(class_2586 entity){
        return new BlockLive.Live(pos, state, entity);
    }

    public @Nullable class_2586 getBlockEntity(){
        return null;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof BlockLive blockLive) {
            return blockLive.pos.equals(pos) && blockLive.state.equals(state);
        }
        return false;
    }

    public static class Tag extends BlockLive{
        public @NotNull class_2487 blockEntityTag;

        /**
         * A Blocklike that saves a block entity tag. Can be saved and moved around. Entity cannot be rendered in a preview
         */
        public Tag(class_2338 pos, class_2680 state, @NotNull class_2586 blockEntity) {
            super(pos, state);


            this.blockEntityTag = blockEntity.method_38243(blockEntity.method_10997().method_30349());
        }

        public Tag(class_2338 pos, class_2680 state, @NotNull class_2487 tag) {
            super(pos, state);
            this.blockEntityTag = tag;
        }

        public Tag(class_1922 level, class_2338 pos) {
            this(pos, level.method_8320(pos), Objects.requireNonNull(level.method_8321(pos)));
        }

        @Override
        public void move(class_1937 level, class_2338 offset) {
            super.move(level, offset);

            class_2338 posNew = pos.method_10081(offset);

            class_2586 blockEntity = class_2586.method_11005(posNew, state, blockEntityTag, level.method_30349());
            if (blockEntity != null)
                level.method_8438(blockEntity);
        }

        @Override
        public Live addBlockEntity(class_2586 entity) {
            throw new RuntimeException("Adding BlockEntity to Tag is not supported! Use replaceBlockEntity instead.");
        }

    }

    /**
     * A Blocklike with a live block entity which can be rendered
     */
    public static class Live extends BlockLive{
        public final class_2586 blockEntity;

        public Live(class_2338 pos, class_2680 state, @NotNull class_2586 blockEntity) {
            super(pos, state);
            this.blockEntity = blockEntity;
        }

        public Live(class_1922 level, class_2338 pos) {
            this(pos, level.method_8320(pos), Objects.requireNonNull(level.method_8321(pos)));
        }

        public static BlockLive optionalBE(class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity) {
            if (blockEntity != null) {
                return new Live(pos, state, blockEntity);
            }
            return new BlockLive(pos, state);
        }

        @Override
        public @Nullable class_2586 getBlockEntity() {
            return blockEntity;
        }

        @Override
        public void move(class_1937 level, class_2338 offset) {
            throw new RuntimeException("Moving Live BlockEntity is not supported!");
        }

        @Override
        public Live addBlockEntity(class_2586 entity) {
            return this;
        }
    }

}
