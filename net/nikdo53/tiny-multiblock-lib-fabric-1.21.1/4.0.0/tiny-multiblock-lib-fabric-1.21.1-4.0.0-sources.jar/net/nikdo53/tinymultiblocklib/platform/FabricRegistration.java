package net.nikdo53.tinymultiblocklib.platform;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.nikdo53.tinymultiblocklib.Constants;
import net.nikdo53.tinymultiblocklib.platform.services.IRegistrationUtils;
import net.nikdo53.tinymultiblocklib.test.TestBlockItem;

import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public class FabricRegistration implements IRegistrationUtils {
    public static final FabricRegistration INSTANCE = new FabricRegistration();

    @Override
    public <T extends class_2586> Supplier<class_2591<T>> registerBlockEntity(String name, BiFunction<class_2338, class_2680, T> function, Set<class_2248> blocks) {
        class_2591<T> registered = class_2378.method_10226(class_7923.field_41181, name, class_2591.class_2592.method_20528(function::apply, blocks.toArray(new class_2248[0])).method_11034(null));
        return () -> registered;
    }

    @Override
    public <T extends class_2248> Supplier<T> registerBlock(String name, Function<class_4970.class_2251, ? extends T> func, Supplier<class_4970.class_2251> properties) {
        T register = class_2378.method_10230(class_7923.field_41175, Constants.loc(name), func.apply(properties.get()));
        return () -> register;
    }

    @Override
    public <T extends class_1792> Supplier<T> registerItem(String name, Function<class_1792.class_1793, T> func, UnaryOperator<class_1792.class_1793> properties) {
        class_1792.class_1793 props = new class_1792.class_1793();
        props = properties.apply(props);
        T register = class_2378.method_10230(class_7923.field_41178, Constants.loc(name), func.apply(props));
        return () -> register;
    }

    @Override
    public  <T extends class_2586> void addSupportedBEBlock(Supplier<class_2591<T>> blockEntityType, class_2248 block){
        blockEntityType.get().addSupportedBlock(block);
    }
}
