package net.nikdo53.tinymultiblocklib.client.ghost;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;

public class GhostBlockEntityRenderer extends GhostRenderer<GhostBlockEntityRenderer>{
    BlockEntity blockEntity;
    protected int packedOverlay = OverlayTexture.NO_OVERLAY;

    public GhostBlockEntityRenderer(BlockPos pos, int ticksRemaining, BlockEntity blockEntity) {
        super(pos, ticksRemaining);
        this.blockEntity = blockEntity;
    }

    @Override
    protected void render(float partialTick, CameraRenderState camera, ClientLevel level, PoseStack poseStack) {
        var entityRender = Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);

        if (entityRender != null) {
            BlockEntityRenderState renderState = entityRender.createRenderState();
            entityRender.extractRenderState(blockEntity, renderState, partialTick, camera.pos, null);

            entityRender.submit(renderState, poseStack, submitNodeCollector, camera);
        }
    }


    public GhostBlockEntityRenderer setOverlay(int packedOverlay){
        this.packedOverlay = packedOverlay;
        return this;
    }
}
