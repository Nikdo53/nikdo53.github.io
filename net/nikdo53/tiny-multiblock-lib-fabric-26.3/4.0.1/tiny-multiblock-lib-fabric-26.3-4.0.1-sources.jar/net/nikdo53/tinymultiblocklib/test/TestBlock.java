package net.nikdo53.tinymultiblocklib.test;

import com.mojang.math.Axis;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.nikdo53.tinymultiblocklib.block.AbstractMultiBlock;
import net.nikdo53.tinymultiblocklib.block.IExpandingMultiblock;
import net.nikdo53.tinymultiblocklib.block.IMultiBlock;
import net.nikdo53.tinymultiblocklib.block.IPreviewableMultiblock;
import net.nikdo53.tinymultiblocklib.client.ghost.GhostBlockRenderer;
import net.nikdo53.tinymultiblocklib.components.SharedStatePropertiesBuilder;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.List;

public class TestBlock extends AbstractMultiBlock implements IPreviewableMultiblock, IExpandingMultiblock {
    public TestBlock(Properties properties) {
        super(properties);
    }
    public static final VoxelShape SHAPE = makeShape();

    @Override
    public @Nullable EnumProperty<Direction> getDirectionProperty() {
        return HorizontalDirectionalBlock.FACING;
    }

    @Override
    public void createSharedBlockStates(SharedStatePropertiesBuilder builder) {
        super.createSharedBlockStates(builder);
        builder.add(BlockStateProperties.AGE_3);
    }

    @Override
    public List<BlockPos> makeFullBlockShape(@NonNull Level level, @NonNull BlockPos center, @NonNull BlockState state, @Nullable BlockEntity blockEntity, @Nullable Direction direction) {
        int size = 1;

        List<BlockPos> list = IMultiBlock.posStreamToList(
                BlockPos.betweenClosedStream(center.relative(Direction.NORTH, size).relative(Direction.EAST, size), center.above(size))
        );
        list.add(center.north(3).above());
        return list;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(BlockStateProperties.AGE_3);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        int value = state.getValue(BlockStateProperties.AGE_3) + 1;
        if (value > 3) {
            value = 0;
        }

        new GhostBlockRenderer(pos.above(), 100, Blocks.GRASS_BLOCK.defaultBlockState())
                .enableDistanceFade(10, 5)
                .transform(poseStack -> poseStack.rotateDegrees(Axis.XP,45))
                .addToRenderList();

        Direction direction = state.getValue(HorizontalDirectionalBlock.FACING);

        moveMultiblock(level, pos, state, direction);

        return InteractionResult.SUCCESS;
    }

    @Override
    public RenderShape getMultiblockRenderShape(BlockState state, boolean isCenter) {
        return RenderShape.MODEL;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.block();
       // return voxelShapeHelper(state, level, posEither, SHAPE, 0 , 0, 0, true);
    }

    public static VoxelShape makeShape(){
        VoxelShape shape = Shapes.empty();
        shape = Shapes.join(shape, Shapes.box(-1, 0, 0, 1, 2, 2), BooleanOp.OR);
        shape = Shapes.join(shape, Shapes.box(-1.5, 0.75, 0.75, 1.5, 1.25, 1.25), BooleanOp.OR);
        shape = Shapes.join(shape, Shapes.box(-1, 0.75, 0.75, 2, 1.25, 1.25), BooleanOp.OR);
        shape = Shapes.join(shape, Shapes.box(-2, 0.75, 0.75, 1, 1.25, 1.25), BooleanOp.OR);
        shape = Shapes.join(shape, Shapes.box(-1.5, 0.75, 0.75, 1.5, 1.25, 1.25), BooleanOp.OR);
        shape = Shapes.join(shape, Shapes.box(-1.5, 1.5, 0.75, 1.5, 2, 1.25), BooleanOp.OR);
        shape = Shapes.join(shape, Shapes.box(-1.5, 0, 0.75, 1.5, 0.5, 1.25), BooleanOp.OR);
        shape = Shapes.join(shape, Shapes.box(-1.5, 0.75, 1.5, 1.5, 1.25, 2), BooleanOp.OR);
        shape = Shapes.join(shape, Shapes.box(-1.5, 0.75, 0, 1.5, 1.25, 0.5), BooleanOp.OR);

        return shape;
    }
}
